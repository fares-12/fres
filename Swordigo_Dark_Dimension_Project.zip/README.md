# SWORDIGO: DARK DIMENSION

لعبة أكشن ومنصات ثنائية الأبعاد (فانتازيا مظلمة) لأندرويد، مبنية بـ Godot 4.3، بتحكم لمس أفقي.
2D dark-fantasy action platformer for Android (Godot 4.3, landscape, touch controls, offline).

> **تنبيه:** لم يُبنَ ملف APK داخل بيئة التطوير (لا يوجد Godot ولا Android SDK ولا إنترنت). الـ APK يُبنى تلقائيًا في السحابة (GitHub Actions) كما يلي. راجع `TEST_REPORT.md`.

## الحصول على APK من الهاتف فقط (بدون حاسوب)
1. افتح **github.com** في متصفح الهاتف وأنشئ حسابًا مجانيًا (يُفضّل وضع "Desktop site").
2. **New repository** ← اسم مثل `dark-dimension` ← Create repository.
3. **Add file ← Upload files** ← اختر `Swordigo_Dark_Dimension_Project.zip` كما هو (لا تفكّه) ← Commit changes.
4. **Add file ← Create new file** ← في خانة الاسم اكتب بالضبط: `.github/workflows/build-apk.yml`
   ثم الصق كامل محتوى الملف `build-apk.yml` المرفق، ثم Commit changes.
5. افتح تبويب **Actions** ← **Build Android APK** ← **Run workflow** (يبدأ وحده غالبًا). المدة 10–20 دقيقة.
6. عند النجاح (علامة خضراء): من الصفحة الرئيسية للمستودع افتح **Releases** ← نزّل `Swordigo_Dark_Dimension.apk`.
   (بديل: داخل تشغيل Actions ← Artifacts ← `Swordigo_Dark_Dimension_APK` وهو ملف ZIP يحوي الـ APK، فُكّه من تطبيق الملفات.)
7. ثبّت الـ APK. إن طلب الهاتف: اسمح بالتثبيت من هذا المصدر (Install unknown apps) للمتصفح/الملفات.
إن فشل البناء (علامة حمراء) افتح الخطوة الحمراء وأرسل لي نصّ الخطأ لأصلحه.

## التحكم
يسار/يمين (أسفل اليسار) • قفز • سيف • سحر (أسفل اليمين) • زر تفاعل يظهر عند الاقتراب من مزار/صندوق/لوح/باب/بوابة • زر إيقاف أعلى اليمين.
من الإعدادات: مستوى الصوت (عام/موسيقى/مؤثرات)، حجم وشفافية الأزرار. للحاسوب (اختبار): الأسهم/WASD، Space قفز، J سيف، K سحر، E تفاعل.

## الحفظ
عند تفعيل **مزار** (Shrine) تُحفظ المرحلة والموضع والصحة والقدرات والمفاتيح والأبواب. زر Continue يُعطَّل إن لم يوجد حفظ سليم. الحفظ التالف يُنقل إلى `save_damaged.json` ولا يُحذف.

## فتح المشروع وإعادة البناء
افتح المجلد في Godot 4.3 ← Project ← Export ← Android. لإعادة توليد الأصول: `python3 tools/build_data.py && python3 tools/gen_sprites.py && python3 tools/gen_audio.py`.
تحقق ساكن: `python3 tools/validate_project.py` • اختبارات Godot: `godot --headless -s res://tests/run_tests.gd`.

ملاحظة: ملف `docs/STORY_BIBLE_SPOILERS.md` يحوي حرق القصة؛ لا تفتحه إن أردت المفاجأة.
