#!/usr/bin/env python3
"""Builds data/chunks.json, data/zones.json and data/lore.json.
Chunks are 14 rows tall (ground = rows 11..13, standing row = 10)."""
import json, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

class Ch:
    def __init__(s, w):
        s.w = w
        s.g = [[' '] * w for _ in range(14)]
        for r in (11, 12, 13):
            s.g[r] = ['#'] * w
    def gap(s, c, n):
        for r in (11, 12, 13):
            for i in range(n):
                s.g[r][c + i] = ' '
    def put(s, r, c, ch, n=1):
        for i in range(n):
            s.g[r][c + i] = ch
        return s
    def fill(s, r0, r1, c0, c1, ch):
        for r in range(r0, r1 + 1):
            for c in range(c0, c1 + 1):
                s.g[r][c] = ch
        return s
    def rows(s):
        return [''.join(r) for r in s.g]

CH = {}

c = Ch(16); c.put(10, 3, 'P'); c.put(10, 1, 't'); c.put(10, 14, 't'); c.put(9, 8, 'o', 3); CH['start'] = c

c = Ch(20); c.put(10, 6, 'g'); c.put(10, 14, 'g'); c.put(9, 9, 'o', 2); c.put(10, 18, 't'); CH['flat1'] = c

c = Ch(18); c.gap(7, 3); c.put(8, 7, 'o', 3); c.put(5, 12, 'b'); CH['gap3'] = c

c = Ch(22); c.gap(8, 4); c.put(9, 9, '=', 2); c.put(8, 9, 'o', 2); c.put(10, 3, 'g'); c.put(10, 17, 'g'); CH['gap4_plat'] = c

c = Ch(24)
c.put(8, 4, '=', 3); c.put(6, 9, '=', 3); c.put(4, 14, '=', 3); c.put(6, 19, '=', 3)
c.put(3, 15, 'c'); c.put(7, 10, 'o'); c.put(5, 4 + 10, 'o'); c.put(5, 20, 'o'); c.put(10, 12, 'g')
CH['steps_up'] = c

c = Ch(20); c.put(10, 6, '^', 2); c.put(10, 12, '^', 3); c.put(8, 6, 'o', 2); c.put(8, 12, 'o', 3); c.put(5, 9, 'b'); CH['spikes_run'] = c

c = Ch(24); c.put(10, 4, 'g'); c.put(10, 19, 'a'); c.put(8, 8, '=', 4); c.put(7, 9, 'o', 2); c.put(10, 22, 't'); CH['archer_hall'] = c

c = Ch(26); c.gap(4, 18)
c.put(9, 6, '=', 2); c.put(8, 11, '=', 2); c.put(9, 16, '=', 2); c.put(9, 20, '=', 2)
c.put(8, 6, 'o', 2); c.put(7, 11, 'o', 2); c.put(8, 16, 'o', 2); c.put(5, 9, 'b'); c.put(4, 15, 'b')
CH['pit_platforms'] = c

c = Ch(22); c.fill(8, 10, 9, 10, '#'); c.put(7, 9, 'o', 2); c.put(10, 15, 'g'); c.put(10, 19, 'a'); c.put(10, 3, 't'); CH['wall_climb'] = c

c = Ch(20)
c.put(8, 3, '=', 3); c.put(6, 8, '=', 3); c.put(4, 13, '=', 3); c.put(2, 8, '=', 3)
c.put(1, 9, 'c'); c.put(7, 4, 'o'); c.put(5, 9, 'o'); c.put(3, 14, 'o'); c.put(10, 10, 'g'); c.put(10, 17, 'm')
CH['tower'] = c

c = Ch(22)
c.fill(8, 8, 11, 19, '#'); c.fill(8, 10, 19, 19, '#'); c.fill(9, 10, 11, 11, 'X'); c.put(7, 14, 'o', 3)
c.put(10, 15, 'c'); c.put(10, 13, 'o'); c.put(10, 17, 'o'); c.put(9, 14, 'o'); c.put(9, 16, 'o')
c.put(10, 6, 'M'); c.put(10, 2, 'g'); c.put(10, 9, 'g'); c.put(10, 21, 't')
CH['cracked_vault'] = c

c = Ch(22)
c.put(8, 4, '=', 3); c.put(6, 9, '=', 3); c.put(4, 14, '=', 4); c.put(3, 16, 'K')
c.put(10, 18, 'a'); c.put(3, 10, 'b'); c.put(7, 5, 'o'); c.put(5, 10, 'o'); c.put(10, 1, 't')
CH['key_nook'] = c

c = Ch(14); c.fill(3, 10, 7, 7, 'D'); c.put(10, 3, 'L'); c.put(10, 5, 't'); c.put(10, 9, 't'); CH['door_hall'] = c

c = Ch(16); c.put(10, 6, 'S'); c.put(10, 4, 't'); c.put(10, 8, 't'); c.put(10, 11, 'L'); c.put(10, 13, 'h'); c.put(10, 14, 'm'); CH['shrine_rest'] = c

c = Ch(24)
c.fill(4, 6, 6, 8, '#'); c.fill(3, 5, 15, 17, '#')
c.put(10, 3, 'y'); c.put(10, 20, 'y'); c.put(7, 10, 'b'); c.put(8, 19, 'b'); c.put(9, 12, 'b'); c.put(10, 12, 'g'); c.put(9, 4, 'o', 3)
CH['bat_cave'] = c

c = Ch(24)
c.fill(10, 10, 4, 19, '#'); c.fill(9, 9, 7, 16, '#'); c.fill(8, 8, 10, 13, '#')
c.put(7, 11, 'a'); c.put(8, 8, 'g'); c.put(9, 14, 'o'); c.put(6, 10, 'o', 4); c.put(10, 2, 'g'); c.put(10, 22, 't')
CH['hill_fort'] = c

c = Ch(32)
c.put(8, 5, '=', 4); c.put(8, 23, '=', 4); c.put(10, 22, 'B'); c.put(10, 16, 'U'); c.put(10, 2, 't'); c.put(10, 29, 't')
CH['arena_boss'] = c

c = Ch(36)
c.put(8, 5, '=', 4); c.put(8, 27, '=', 4); c.put(5, 16, '=', 4); c.put(10, 26, 'B'); c.put(10, 2, 't'); c.put(10, 33, 't')
CH['arena_final'] = c

c = Ch(16); c.put(10, 11, 'E'); c.put(10, 9, 't'); c.put(10, 14, 't'); c.put(10, 4, 'S'); c.put(10, 7, 'h'); CH['exit_hall'] = c

c = Ch(22); c.fill(6, 10, 9, 10, '#'); c.put(5, 9, 'o', 2); c.put(10, 16, 'a'); c.put(10, 4, 'g'); c.put(4, 14, 'b'); CH['wall5'] = c

chunks = {k: v.rows() for k, v in CH.items()}

ZONES = {
 "1": dict(name="Whisperwood", sub="Where the dusk never ends", theme=1, music="z1", gravity=1.0, ambient="#a79bd0",
           cave=False, enemy_tint="#ffffff", hp_mult=1.0, dmg=1, key_name="Dusk Key", light="#ffd9a0",
           boss="", ability="",
           chunks=["start","flat1","gap3","steps_up","cracked_vault","archer_hall","spikes_run","shrine_rest","key_nook","pit_platforms","hill_fort","door_hall","exit_hall"],
           tablets=["z1_a","z1_b"]),
 "2": dict(name="Sunken Ruins", sub="Bells beneath the water", theme=2, music="z2", gravity=1.0, ambient="#98b0d8",
           cave=False, enemy_tint="#b8d8ff", hp_mult=1.0, dmg=1, key_name="Tide Key", light="#9fd8ff",
           boss="colossus", ability="double_jump",
           chunks=["start","flat1","bat_cave","gap4_plat","steps_up","cracked_vault","shrine_rest","tower","spikes_run","archer_hall","key_nook","door_hall","shrine_rest","arena_boss","exit_hall"],
           tablets=["z2_a","z2_b","z2_c"]),
 "3": dict(name="Hollow Depths", sub="Tunnels dug for the frightened", theme=3, music="z3", gravity=1.0, ambient="#8a7a88",
           cave=True, enemy_tint="#ffd8b0", hp_mult=1.2, dmg=1, key_name="Root Key", light="#7fe8d8",
           boss="", ability="",
           chunks=["start","bat_cave","flat1","pit_platforms","wall_climb","archer_hall","cracked_vault","tower","shrine_rest","spikes_run","key_nook","hill_fort","door_hall","exit_hall"],
           tablets=["z3_a","z3_b","z3_c"]),
 "4": dict(name="Prism Rift", sub="Laws bend where the Seal bleeds", theme=4, music="z4", gravity=0.7, ambient="#c090e8",
           cave=False, enemy_tint="#f0c8ff", hp_mult=1.3, dmg=1, key_name="Prism Key", light="#ff9cf0",
           boss="weaver", ability="ember",
           chunks=["start","pit_platforms","wall5","gap4_plat","tower","steps_up","archer_hall","shrine_rest","key_nook","bat_cave","cracked_vault","door_hall","shrine_rest","arena_boss","exit_hall"],
           tablets=["z4_a","z4_b","z4_c"]),
 "5": dict(name="Ashen Bastion", sub="A fortress that burned its own banners", theme=5, music="z5", gravity=1.0, ambient="#b09090",
           cave=False, enemy_tint="#ffb8a0", hp_mult=1.5, dmg=2, key_name="Ash Key", light="#ff9a50",
           boss="", ability="",
           chunks=["start","hill_fort","spikes_run","wall5","archer_hall","pit_platforms","bat_cave","shrine_rest","key_nook","tower","cracked_vault","gap4_plat","door_hall","exit_hall"],
           tablets=["z5_a","z5_b","z5_c"]),
 "6": dict(name="Eternal Spire", sub="The last moment", theme=6, music="z6", gravity=1.0, ambient="#a8a8d8",
           cave=False, enemy_tint="#e8e8ff", hp_mult=1.7, dmg=2, key_name="Spire Key", light="#e8e0ff",
           boss="regent", ability="",
           chunks=["start","wall5","pit_platforms","spikes_run","archer_hall","hill_fort","shrine_rest","key_nook","bat_cave","tower","door_hall","shrine_rest","arena_final"],
           tablets=["z6_a","z6_b","z6_c"]),
}

LORE = {
 "intro": [
   "The Seal of Eternity cracked at dusk.",
   "When a seal breaks, darkness is not the only thing to fear.",
   "Something woke you. A small, stubborn flame stirs in your chest.\n\nWalk toward the cracks."
 ],
 "hint_crack": {"title": "Hollow Stone", "text": "The wall rings hollow. Stone like this answers to sorcery, not steel. Strike it with the spark from your hand."},
 "tablets": {
  "z1_a": {"title": "Moss-Covered Stone", "text": "The trees stopped growing the day the sky stopped moving. Dusk has lasted longer than any of us can count."},
  "z1_b": {"title": "Lantern-Maker's Note", "text": "We made light for every house in Vael. We never learned to make enough hours."},
  "z2_a": {"title": "Drowned Plaque", "text": "The court sank first. The queen's bells still ring beneath the water, one note at a time, never finishing the song."},
  "z2_b": {"title": "Oath of the Order", "text": "We swear silence. The Lantern is not a weapon and not a relic. It is a promise, and promises must be carried."},
  "z2_c": {"title": "Scratched Warning", "text": "The Warden of the water-gate obeys one order only: nothing passes. Nobody remembers who gave it."},
  "z3_a": {"title": "Tunnel Marking", "text": "These passages were dug to hide the children when the Fading came. It found them anyway. It always did."},
  "z3_b": {"title": "A Mother's Scratch", "text": "It does not age. It does not sleep. It does not hunger. Is that a gift, or a sentence?"},
  "z3_c": {"title": "Cracked Slate", "text": "The Seal took one moment and made it a world. Do not ask what the moment was."},
  "z4_a": {"title": "Floating Rune", "text": "Here the laws bend because the Seal bleeds. Past and future leak through the cracks and call themselves places."},
  "z4_b": {"title": "Weaver's Ledger", "text": "I stitched hours together to keep his grief warm. Every stitch is a day he refused to let end."},
  "z4_c": {"title": "Shard of Glass", "text": "The thread you carry is older than the Seal. That is why the rift knows your footsteps."},
  "z5_a": {"title": "Burnt Banner", "text": "The king's guard burned their banners so the dark could not read them. The ash still falls."},
  "z5_b": {"title": "Guard's Last Letter", "text": "Orrin would not rule, would not eat, would not sleep. He sat beside a small bed and counted breaths that never came."},
  "z5_c": {"title": "Sealed Order", "text": "Whoever bears the flame must never be told. Let the flame believe it chose its own path."},
  "z6_a": {"title": "Spire Inscription", "text": "The Spire is the last moment. Climb it and you will stand where the world stopped."},
  "z6_b": {"title": "Seal-Law", "text": "What is held cannot heal. What is kept cannot live."},
  "z6_c": {"title": "Cradle Song", "text": "Sleep, small light, the morning waits. Sleep, small light, I will not let go."}
 },
 "abilities": {
  "double_jump": {"title": "GALE SIGIL", "text": "The wind remembers you.\nTap JUMP again in mid-air to leap a second time."},
  "ember": {"title": "EMBER SIGIL", "text": "Your spark burns brighter.\nMagic bolts now strike harder and pierce through enemies."}
 },
 "bosses": {
  "colossus": {"name": "THE ROOTBOUND WARDEN", "intro": "Nothing passes the water-gate.", "outro": "The Warden crumbles. \"I kept the gate... as I was told. Who told me?\""},
  "weaver": {"name": "THE RIFT WEAVER", "intro": "Another thread comes to be cut.", "outro": "The Weaver unravels. \"The pattern was never meant to hold you...\""},
  "regent": {"name": "THE HOLLOW REGENT", "intro": "You walk like her. Turn back. I cannot lose her twice.", "outro": ""}
 },
 "ending": [
   "The Regent's armor fell like autumn leaves. Beneath it, an old man holding nothing, in a room with a small, empty bed.",
   "\"She would have hated this place,\" he whispered. \"She wanted to see a morning.\"",
   "The flame in your chest answered. For the first time it did not feel like a borrowed light.",
   "The Seal opened. Dawn crossed the Spire, the forests, the water, the long-forgotten halls. Every Husk lay down in the sun and was still.",
   "A lantern was never meant to end the dusk. It was meant to carry one small light until someone was brave enough to let it go.\n\nYou walked out into the first morning in a hundred years.",
   "Far to the east, another bell began to ring..."
 ],
 "credits": "SWORDIGO: DARK DIMENSION\n\nAn original fantasy adventure.\n\nDesign, code, pixel art, music and sound:\ngenerated for this project.\nAll assets are original and procedurally created.\n\nEngine: Godot 4.3 (MIT License)\n\nThank you for playing."
}

def main():
    os.makedirs(os.path.join(ROOT, "data"), exist_ok=True)
    for name, obj in (("chunks", chunks), ("zones", ZONES), ("lore", LORE)):
        with open(os.path.join(ROOT, "data", name + ".json"), "w") as f:
            json.dump(obj, f, indent=1)
    print("data written:", len(chunks), "chunks,", len(ZONES), "zones")

if __name__ == "__main__":
    main()
