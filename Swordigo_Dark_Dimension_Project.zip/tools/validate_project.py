#!/usr/bin/env python3
"""Static project validation (no Godot needed): data integrity, references, GDScript hygiene, level reachability."""
import os, re, sys, json, wave, glob
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
errors, warns = [], []
def err(m): errors.append(m)
def warn(m): warns.append(m)
def rd(p): return open(os.path.join(ROOT, p), encoding="utf-8").read()
def exists(res): return os.path.exists(os.path.join(ROOT, res.replace("res://", "")))

# ---- JSON data
chunks = json.loads(rd("data/chunks.json")); zones = json.loads(rd("data/zones.json")); lore = json.loads(rd("data/lore.json"))
atlas = json.loads(rd("data/atlas.json")); sheets = json.loads(rd("data/sprites.json"))
VALID = set(" #=^oaghmbcSKDXPEBLMUty")
for n, rows in chunks.items():
    if len(rows) != 14: err(f"chunk {n}: {len(rows)} rows (need 14)")
    if len({len(r) for r in rows}) != 1: err(f"chunk {n}: ragged rows")
    for r in rows:
        for ch in r:
            if ch not in VALID: err(f"chunk {n}: invalid char {ch!r}")
    if any(r[0] != '#' and i in (11,12,13) and not n.startswith("gap") and n != "pit_platforms" for i, r in enumerate(rows)):
        err(f"chunk {n}: ground not continuous at left edge")
    for i in (11, 12, 13):
        if rows[i][0] != '#' or rows[i][-1] != '#': err(f"chunk {n}: ground edge gap row {i}")
for z, cfg in zones.items():
    for need in ("name", "theme", "music", "ambient", "chunks", "tablets", "gravity", "hp_mult", "dmg", "key_name"):
        if need not in cfg: err(f"zone {z}: missing {need}")
    for c in cfg["chunks"]:
        if c not in chunks: err(f"zone {z}: unknown chunk {c}")
    seq = cfg["chunks"]
    cnt = lambda ch: sum(chunks[c][r].count(ch) for c in seq for r in range(14))
    if cnt('P') != 1: err(f"zone {z}: needs exactly one P (has {cnt('P')})")
    if cnt('K') < 1 or cnt('D') < 1: err(f"zone {z}: needs key and door")
    if seq.index("key_nook") > seq.index("door_hall"): err(f"zone {z}: key after door")
    if int(z) < 6 and cnt('E') != 1: err(f"zone {z}: needs exit portal")
    if cnt('L') > len(cfg["tablets"]): err(f"zone {z}: {cnt('L')} tablets but {len(cfg['tablets'])} texts")
    for t in cfg["tablets"]:
        if t not in lore["tablets"]: err(f"zone {z}: tablet text {t} missing")
    if cfg.get("boss"):
        if cfg["boss"] not in lore["bosses"]: err(f"zone {z}: boss lore missing")
        if cfg["boss"] not in sheets: err(f"zone {z}: boss sheet missing")
        if not any(c.startswith("arena") for c in seq): err(f"zone {z}: boss without arena")
    if cfg.get("ability") and cfg["ability"] not in lore["abilities"]: err(f"zone {z}: ability lore missing")
    if not exists(f"res://assets/audio/music/{cfg['music']}.wav"): err(f"zone {z}: music missing")
    for i in range(3):
        if not exists(f"res://assets/backgrounds/bg_z{cfg['theme']}_{i}.png"): err(f"zone {z}: background {i} missing")
    for t in ("top","top2","fill","fill2","plat","crack","decor1","decor2","decor3"):
        if f"t{cfg['theme']}_{t}" not in atlas: err(f"atlas missing t{cfg['theme']}_{t}")

# ---- scripts
gd = sorted(glob.glob(os.path.join(ROOT, "**/*.gd"), recursive=True))
audio_sfx = {os.path.basename(p)[:-4] for p in glob.glob(os.path.join(ROOT, "assets/audio/sfx/*.wav"))}
audio_mus = {os.path.basename(p)[:-4] for p in glob.glob(os.path.join(ROOT, "assets/audio/music/*.wav"))}
func_defs = {}
for p in gd:
    rel = os.path.relpath(p, ROOT); s = open(p, encoding="utf-8").read()
    if "\t" in s: err(f"{rel}: contains tab characters")
    for i, line in enumerate(s.split("\n"), 1):
        if line.strip() and (len(line) - len(line.lstrip(" "))) % 4 != 0 and not line.lstrip().startswith(("#", ")", "]", "}")):
            # continuation lines of multi-line literals may be offset; flag softly
            warn(f"{rel}:{i}: indent not multiple of 4")
        if re.search(r"\b(TODO|FIXME)\b", line): err(f"{rel}:{i}: TODO/FIXME left")
    code = re.sub(r'"(?:\\.|[^"\\])*"', '""', s); code = re.sub(r"#.*", "", code)
    for a, b in ("()", "[]", "{}"):
        if code.count(a) != code.count(b): err(f"{rel}: unbalanced {a}{b} ({code.count(a)} vs {code.count(b)})")
    for m in re.finditer(r'(?:preload|load)\("(res://[^"]+)"\)', s):
        if not exists(m.group(1)): err(f"{rel}: missing resource {m.group(1)}")
    for m in re.finditer(r'Sprites\.tex\("([^"%]+)"\)', s):
        if m.group(1) not in atlas: err(f"{rel}: unknown atlas sprite {m.group(1)}")
    for m in re.finditer(r'Sprites\.frames\("([^"]+)"\)', s):
        if m.group(1) not in sheets: err(f"{rel}: unknown sheet {m.group(1)}")
    for m in re.finditer(r'Audio\.play(?:_at)?\("([^"]+)"', s):
        if m.group(1) not in audio_sfx: err(f"{rel}: unknown sfx {m.group(1)}")
    for m in re.finditer(r'Audio\.(?:play_music|play_zone_music)\("([^"]+)"', s):
        if m.group(1) not in audio_mus: err(f"{rel}: unknown music {m.group(1)}")
    func_defs[rel] = set(re.findall(r"^func (\w+)", s, re.M))
for m in re.finditer(r'atlas_frames\("(\w+)", (\d+)', "".join(open(p).read() for p in gd)):
    for i in range(int(m.group(2))):
        if f"{m.group(1)}_{i}" not in atlas: err(f"atlas_frames: {m.group(1)}_{i} missing")
# cross-script API calls into Game / world / Audio
allsrc = "".join(open(p, encoding="utf-8").read() for p in gd)
def api(obj, file, extra=()):
    defs = func_defs[file]
    src = open(os.path.join(ROOT, file)).read()
    props = set(re.findall(r"^var (\w+)", src, re.M)) | set(re.findall(r"^const (\w+)", src, re.M)) | set(re.findall(r"^signal (\w+)", src, re.M))
    for m in re.finditer(rf"\b{obj}\.(\w+)\(", allsrc):
        if m.group(1) not in defs and m.group(1) not in extra: err(f"{obj}.{m.group(1)}() called but not defined in {file}")
    for m in re.finditer(rf"\b{obj}\.(\w+)\b(?!\()", allsrc):
        if m.group(1) not in defs and m.group(1) not in props and m.group(1) not in extra: err(f"{obj}.{m.group(1)} used but not defined in {file}")
api("Game", "scripts/game.gd", extra=("hp","max_hp","mana","max_mana","coins"))
api("Audio", "scripts/audio.gd")
api("Sprites", "scripts/sprites.gd")
# world api (Game.world.xxx)
wdefs = func_defs["scripts/world/world.gd"]
wsrc = open(os.path.join(ROOT, "scripts/world/world.gd")).read()
wprops = set(re.findall(r"^var (\w+)", wsrc, re.M))
for m in re.finditer(r"Game\.world\.(\w+)(\()?", allsrc):
    if m.group(1) not in wdefs and m.group(1) not in wprops: err(f"Game.world.{m.group(1)} not defined in world.gd")

# scenes
for sc in glob.glob(os.path.join(ROOT, "scenes/*.tscn")):
    for m in re.finditer(r'path="(res://[^"]+)"', open(sc).read()):
        if not exists(m.group(1)): err(f"{os.path.basename(sc)}: missing {m.group(1)}")
proj = rd("project.godot")
for m in re.finditer(r'"\*?(res://[^"]+)"', proj):
    if not exists(m.group(1)): err(f"project.godot: missing {m.group(1)}")

# ---- reachability (approximate platforming model) -------------------------------------------
def build_grid(seq):
    rows = [[] for _ in range(18)]
    def wall():
        for r in range(18): rows[r] += ['#', '#']
    wall()
    for n in seq:
        ch = chunks[n]; w = len(ch[0])
        for r in range(18):
            line = ' ' * w if r < 4 else ch[r - 4]
            rows[r] += list(line)
    wall()
    return rows
def reach(zone_id, double):
    g = build_grid(zones[zone_id]["chunks"]); H, W = 18, len(g[0])
    def solid(c, r): return 0 <= c < W and 0 <= r < H and g[r][c] in "#="
    def hard(c, r): return 0 <= c < W and 0 <= r < H and g[r][c] == "#"
    def stand(c, r): return 0 <= r < H and not hard(c, r) and g[r][c] != "D" and solid(c, r + 1)
    start = [(c, r) for r in range(H) for c in range(W) if g[r][c] == 'P'][0]
    goal = [(c, r) for r in range(H) for c in range(W) if g[r][c] in "EB"]
    goal = goal[0] if goal else None
    seen = {start}; q = [start]
    up = 6 if double else 3; dxh = 7 if double else 5
    while q:
        c, r = q.pop()
        for c2 in range(c - dxh - 2, c + dxh + 3):
            for r2 in range(r - up, r + 12):
                if (c2, r2) in seen or not (0 <= c2 < W and 0 <= r2 < H): continue
                if not stand(c2, r2) or hard(c2, r2): continue
                dx, dy = abs(c2 - c), r - r2
                if dy > 0 and dx > dxh - 1 and not double: continue
                if dy < 0 and dx > dxh + 1: continue
                if dx > dxh + (2 if dy < 0 else 0): continue
                # wall blocking: walking path at feet row must not be hard-blocked for walks
                lo, hi = min(c, c2), max(c, c2)
                if dy <= 0 and r2 == r and any(hard(x, r) for x in range(lo + 1, hi)): continue
                if dy > 0 and any(hard(x, r2 + 0) and hard(x, r2 + 1) is False for x in ()): pass
                # headroom: wall taller than jump height between
                if any(hard(x, rr) for x in range(lo + 1, hi) for rr in range(r - up, r)) and dy < up - 1 and dx > 1 and False: continue
                seen.add((c2, r2)); q.append((c2, r2))
    return start, goal, seen
for z in zones:
    need_dj = int(z) >= 4
    s, goal, seen = reach(z, need_dj)
    if goal and not any(abs(c - goal[0]) <= 1 and abs(r - goal[1]) <= 1 for c, r in seen): err(f"zone {z}: goal not reachable ({'double' if need_dj else 'single'} jump model)")
    if not need_dj:
        pass
for z in ("1", "2", "3"):
    s, goal, seen = reach(z, False)
    if goal and not any(abs(c - goal[0]) <= 1 and abs(r - goal[1]) <= 1 for c, r in seen): err(f"zone {z}: not reachable without double jump")

# ---- audio sanity
for p in glob.glob(os.path.join(ROOT, "assets/audio/**/*.wav"), recursive=True):
    try:
        w = wave.open(p); assert w.getnframes() > 100
    except Exception as e: err(f"audio {os.path.relpath(p, ROOT)}: {e}")

print(f"GDScript files: {len(gd)} | chunks: {len(chunks)} | zones: {len(zones)} | atlas sprites: {len(atlas)}")
for w in warns[:15]: print("WARN", w)
if len(warns) > 15: print(f"... {len(warns)-15} more warnings")
for e in errors: print("ERROR", e)
print("RESULT:", "FAILED (%d errors)" % len(errors) if errors else "OK")
sys.exit(1 if errors else 0)
