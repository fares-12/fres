#!/usr/bin/env python3
"""Checks every generated WAV: format, duration, peak/RMS (not silent), clipping, loop-seam click."""
import os, sys, wave
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bad = 0
for sub, lo, hi in (("sfx", 0.04, 3.0), ("music", 12.0, 60.0)):
    d = os.path.join(ROOT, "assets/audio", sub)
    for f in sorted(os.listdir(d)):
        w = wave.open(os.path.join(d, f)); n = w.getnframes(); sr = w.getframerate()
        x = np.frombuffer(w.readframes(n), dtype="<i2").astype(float) / 32768
        dur = n / sr; peak = np.max(np.abs(x)); rms = np.sqrt(np.mean(x ** 2))
        seam = abs(x[0] - x[-1])
        issues = []
        if w.getnchannels() != 1 or w.getsampwidth() != 2: issues.append("format")
        if not lo <= dur <= hi: issues.append("duration")
        if peak < 0.2 or rms < 0.01: issues.append("too quiet")
        if peak > 0.99: issues.append("clipping")
        if sub == "music" and seam > 0.02: issues.append("loop seam %.3f" % seam)
        if sub == "sfx" and (abs(x[0]) > 0.02 or abs(x[-1]) > 0.02): issues.append("edge click")
        if sub == "sfx" and peak > 0.85: issues.append("loud")
        bad += bool(issues)
        print("%-6s %-16s %5.2fs %6.1fKB peak=%.2f rms=%.3f %s" % (sub, f, dur, os.path.getsize(os.path.join(d, f)) / 1024, peak, rms, issues or "OK"))
print("PROBLEMS:", bad); sys.exit(1 if bad else 0)
