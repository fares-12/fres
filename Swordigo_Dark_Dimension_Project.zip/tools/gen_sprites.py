#!/usr/bin/env python3
"""Procedural pixel-art generator (original art). Writes character sheets,
the world atlas and parallax backgrounds."""
import os, json, math, random
import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def P(*a):
    p = os.path.join(ROOT, *a)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    return p
def C(h, a=255):
    h = h.lstrip('#')
    return (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), a)
def new(w, h):
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    return im, ImageDraw.Draw(im)
def outline(im, col=(14, 8, 24, 255)):
    a = np.array(im)
    al = a[:, :, 3] > 0
    pad = np.pad(al, 1)
    dil = pad[:-2, 1:-1] | pad[2:, 1:-1] | pad[1:-1, :-2] | pad[1:-1, 2:]
    a[dil & ~al] = col
    return Image.fromarray(a)
def sheet(frames, fw, fh):
    out = Image.new("RGBA", (fw * len(frames), fh), (0, 0, 0, 0))
    for i, f in enumerate(frames):
        out.paste(f, (i * fw, 0))
    return out
def ln(d, p0, p1, col, w=1):
    d.line([(round(p0[0]), round(p0[1])), (round(p1[0]), round(p1[1]))], fill=col, width=w)

# ---------------------------------------------------------------- hero
H = dict(cloak=C("2f4a8a"), cloak_d=C("1f3263"), cloak_l=C("5278d0"), scarf=C("d0453a"), scarf_d=C("92281f"),
         skin=C("f0cba4"), boot=C("3b2a26"), blade=C("eaf3ff"), hilt=C("e0b83a"), eye=C("fff1b8"), glow=C("7fe9ff"))

def hero_frame(bob=0, lf=0, lb=0, lift_f=0, lift_b=0, hand=(21, 21), sword=70, cape=0, glow=0, scarf_w=0):
    im, d = new(32, 32)
    top = 5 + bob
    def leg(cx, lift, col):
        y0, y1 = 22 + bob, 29 - lift
        d.rectangle([cx - 1, y0, cx + 1, y1], fill=col)
        d.rectangle([cx - 1, y1 - 1, cx + 2, y1], fill=H['boot'])
    leg(12 + lb, lift_b, H['cloak_d'])
    d.polygon([(10, 13 + bob), (10, 24 + bob), (5 - cape, 26 + bob), (6 - cape, 16 + bob)], fill=H['cloak_d'])
    d.rectangle([10, 13 + bob, 19, 22 + bob], fill=H['cloak'])
    d.rectangle([10, 13 + bob, 12, 22 + bob], fill=H['cloak_d'])
    d.line([(10, 19 + bob), (19, 19 + bob)], fill=H['hilt'])
    leg(16 + lf, lift_f, H['cloak'])
    d.rectangle([10, top, 19, top + 7], fill=H['cloak'])
    d.rectangle([9, top + 1, 10, top + 6], fill=H['cloak_d'])
    d.point((10, top - 1), fill=H['cloak_d'])
    d.rectangle([15, top + 2, 19, top + 6], fill=H['skin'])
    d.point((17, top + 3), fill=H['eye']); d.point((18, top + 3), fill=H['eye'])
    d.rectangle([10, 12 + bob, 19, 13 + bob], fill=H['scarf'])
    d.polygon([(10, 12 + bob), (4 - scarf_w, 14 + bob + scarf_w), (6, 16 + bob), (10, 14 + bob)], fill=H['scarf_d'])
    sx, sy = 17, 15 + bob
    hx, hy = hand[0], hand[1] + bob
    ln(d, (sx, sy), (hx, hy), H['cloak_l'], 2)
    d.point((hx, hy), fill=H['skin'])
    if sword is not None:
        a = math.radians(sword)
        ex, ey = hx + math.cos(a) * 11, hy + math.sin(a) * 11
        ln(d, (hx, hy), (ex, ey), H['blade'], 2)
        px, py = -math.sin(a) * 2, math.cos(a) * 2
        gx, gy = hx + math.cos(a) * 2, hy + math.sin(a) * 2
        ln(d, (gx - px, gy - py), (gx + px, gy + py), H['hilt'], 1)
    if glow:
        r = 1 + glow
        d.ellipse([hx - r + 2, hy - r, hx + r + 2, hy + r], fill=H['glow'])
        d.point((hx + 2, hy), fill=(255, 255, 255, 255))
    return outline(im)

def hero_frames():
    F = []
    for b, hd in [(0, (21, 21)), (0, (21, 21)), (1, (21, 22)), (1, (21, 22))]:
        F.append(hero_frame(bob=b, hand=hd, sword=70, scarf_w=b))
    sw = [(3, -3, 0, 2), (2, -2, 0, 0), (0, 0, 0, 0), (-3, 3, 2, 0), (-2, 2, 0, 0), (0, 0, 0, 0)]
    bobs = [0, 1, 0, 0, 1, 0]
    for i, (lf, lb, lif, lib) in enumerate(sw):
        F.append(hero_frame(bob=bobs[i], lf=lf, lb=lb, lift_f=lif, lift_b=lib, hand=(21, 20), sword=55, cape=2, scarf_w=2))
    F.append(hero_frame(lf=3, lb=-2, lift_f=3, lift_b=2, hand=(21, 13), sword=-45, cape=2, scarf_w=2))   # jump 10
    F.append(hero_frame(lf=3, lb=-3, lift_f=1, lift_b=1, hand=(21, 12), sword=-75, cape=3, scarf_w=3))   # fall 11
    F.append(hero_frame(hand=(13, 10), sword=-150))                  # attack 12
    F.append(hero_frame(hand=(22, 13), sword=-40, lf=2))
    F.append(hero_frame(hand=(25, 17), sword=0, lf=3, lb=-1))
    F.append(hero_frame(hand=(23, 21), sword=40, lf=2))
    F.append(hero_frame(hand=(22, 16), sword=None, glow=0))          # cast 16
    F.append(hero_frame(hand=(24, 16), sword=None, glow=1))
    F.append(hero_frame(hand=(24, 16), sword=None, glow=2))
    F.append(hero_frame(bob=1, hand=(14, 14), sword=120, lf=-2, lb=2, cape=3))   # hurt 19
    base = hero_frame(bob=0, hand=(14, 20), sword=100)
    rot = base.transpose(Image.ROTATE_270)
    bb = rot.getbbox()
    dead = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    dead.paste(rot.crop(bb), (max(0, (32 - (bb[2] - bb[0])) // 2), 31 - (bb[3] - bb[1])))
    F.append(dead)                                                   # dead 20
    return F

HERO_ANIMS = {"idle": [0, 4, 5, True], "run": [4, 6, 12, True], "jump": [10, 1, 1, False], "fall": [11, 1, 1, False],
              "attack": [12, 4, 13, False], "cast": [16, 3, 11, False], "hurt": [19, 1, 1, False], "dead": [20, 1, 1, False]}

# ---------------------------------------------------------------- enemies
def husk_frame(bob=0, lf=0, lb=0, arm=(20, 18), wang=40, lunge=0, open_jaw=0):
    im, d = new(32, 32)
    cloth, cl_d, arm_c, bone, eye = C("6b6478"), C("453f55"), C("8a7560"), C("e4dccb"), C("ff8a2a")
    x0 = 9 + lunge
    d.rectangle([x0 + 2 + lb, 22 + bob, x0 + 4 + lb, 29], fill=cl_d)
    d.rectangle([x0 + 7 + lf, 22 + bob, x0 + 9 + lf, 29], fill=cloth)
    d.rectangle([x0 + 1 + lb, 28, x0 + 5 + lb, 29], fill=C("2c2733"))
    d.rectangle([x0 + 6 + lf, 28, x0 + 10 + lf, 29], fill=C("2c2733"))
    d.rectangle([x0, 13 + bob, x0 + 10, 23 + bob], fill=cloth)
    d.rectangle([x0, 13 + bob, x0 + 3, 23 + bob], fill=cl_d)
    d.rectangle([x0 + 1, 15 + bob, x0 + 9, 18 + bob], fill=arm_c)
    d.line([(x0, 23 + bob), (x0 + 10, 23 + bob)], fill=C("2c2733"))
    d.point((x0 + 2, 24 + bob), fill=cl_d); d.point((x0 + 6, 25 + bob), fill=cl_d)
    d.rectangle([x0 + 2, 5 + bob, x0 + 9, 12 + bob], fill=bone)
    d.rectangle([x0 + 2, 5 + bob, x0 + 3, 12 + bob], fill=C("b8ae98"))
    d.rectangle([x0 + 6, 7 + bob, x0 + 8, 8 + bob], fill=eye)
    d.rectangle([x0 + 6, 10 + bob + open_jaw, x0 + 9, 11 + bob + open_jaw], fill=C("3a2a30"))
    hx, hy = arm[0] + lunge, arm[1] + bob
    ln(d, (x0 + 8, 16 + bob), (hx, hy), arm_c, 2)
    a = math.radians(wang)
    ln(d, (hx, hy), (hx + math.cos(a) * 11, hy + math.sin(a) * 11), C("9aa3ad"), 2)
    ln(d, (hx - 1, hy), (hx + 1, hy), C("5a4630"), 1)
    return outline(im)

def husk_frames():
    F = [husk_frame(bob=0), husk_frame(bob=1)]
    for lf, lb in [(2, -2), (0, 0), (-2, 2), (0, 0)]:
        F.append(husk_frame(lf=lf, lb=lb, bob=1 if lf == 0 else 0))
    F.append(husk_frame(arm=(15, 9), wang=-120, open_jaw=1))
    F.append(husk_frame(arm=(24, 16), wang=-10, lunge=2, lf=2, open_jaw=1))
    F.append(husk_frame(arm=(25, 20), wang=30, lunge=3, lf=3, lb=-2, open_jaw=1))
    F.append(husk_frame(bob=1, arm=(14, 16), wang=110, lunge=-1, open_jaw=1))
    b = husk_frame(bob=0)
    rot = b.transpose(Image.ROTATE_270); bb = rot.getbbox()
    dead = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    dead.paste(rot.crop(bb), (max(0, (32 - (bb[2] - bb[0])) // 2), 31 - (bb[3] - bb[1])))
    F.append(dead)
    return F
HUSK_ANIMS = {"idle": [0, 2, 3, True], "walk": [2, 4, 7, True], "attack": [6, 3, 6, False], "hurt": [9, 1, 1, False], "dead": [10, 1, 1, False]}

def archer_frame(bob=0, draw=0, hurt=False):
    im, d = new(32, 32)
    robe, robe_d, hood, eye = C("4b3a78"), C("2d2250"), C("352a5c"), C("ff5a8a")
    d.polygon([(10, 14 + bob), (21, 14 + bob), (23, 29), (8, 29)], fill=robe)
    d.polygon([(10, 14 + bob), (13, 14 + bob), (12, 29), (8, 29)], fill=robe_d)
    for x in (9, 13, 17, 21):
        d.polygon([(x, 28), (x + 2, 28), (x + 1, 31)], fill=robe_d)
    d.rectangle([11, 5 + bob, 20, 14 + bob], fill=hood)
    d.polygon([(11, 5 + bob), (15, 2 + bob), (20, 5 + bob)], fill=hood)
    d.rectangle([15, 8 + bob, 20, 12 + bob], fill=C("120d22"))
    d.point((17, 9 + bob), fill=eye); d.point((19, 9 + bob), fill=eye)
    bx = 22 - draw
    ln(d, (bx + 3, 8 + bob), (bx + 3, 22 + bob), C("c9a063"), 2)
    ln(d, (bx + 3, 8 + bob), (bx - draw, 15 + bob), C("e8e0c8"), 1)
    ln(d, (bx + 3, 22 + bob), (bx - draw, 15 + bob), C("e8e0c8"), 1)
    ln(d, (14, 16 + bob), (bx + 1, 15 + bob), C("4b3a78"), 2)
    if draw:
        ln(d, (bx - draw, 15 + bob), (bx + 7, 15 + bob), C("e0e0e0"), 1)
    return outline(im)

def archer_frames():
    F = [archer_frame(0), archer_frame(1), archer_frame(0, 2), archer_frame(0, 3), archer_frame(0, 0), archer_frame(1, 0)]
    F.append(archer_frame(bob=1))
    b = archer_frame(1)
    rot = b.transpose(Image.ROTATE_270); bb = rot.getbbox()
    dead = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
    dead.paste(rot.crop(bb), (max(0, (32 - (bb[2] - bb[0])) // 2), 31 - (bb[3] - bb[1])))
    F.append(dead)
    return F
ARCHER_ANIMS = {"idle": [0, 2, 3, True], "aim": [2, 2, 4, False], "shoot": [4, 2, 8, False], "hurt": [6, 1, 1, False], "dead": [7, 1, 1, False]}

def bat_frame(flap=0, hurt=False):
    im, d = new(24, 24)
    wing, wing_d, body, eye = C("5a3a7c"), C("3a2456"), C("2a1c40"), C("ff4a5a")
    wy = [-6, -2, 3, 0][flap % 4]
    d.polygon([(11, 11), (2, 11 + wy), (0, 15 + wy // 2), (5, 13), (7, 16), (11, 14)], fill=wing)
    d.polygon([(13, 11), (22, 11 + wy), (23, 15 + wy // 2), (18, 13), (16, 16), (13, 14)], fill=wing_d)
    d.ellipse([9, 9, 15, 17], fill=body)
    d.polygon([(9, 9), (9, 6), (11, 9)], fill=body); d.polygon([(15, 9), (15, 6), (13, 9)], fill=body)
    d.point((11, 12), fill=eye); d.point((13, 12), fill=eye)
    return outline(im)

def bat_frames():
    F = [bat_frame(i) for i in range(4)]
    F.append(bat_frame(3))
    b = bat_frame(1).rotate(180)
    F.append(b)
    return F
BAT_ANIMS = {"fly": [0, 4, 12, True], "hurt": [4, 1, 1, False], "dead": [5, 1, 1, False]}

# ---------------------------------------------------------------- bosses (64x64)
def boss_colossus(pose=0):
    im, d = new(64, 64)
    st, st_d, st_l, moss, core = C("6c7a78"), C("3d4947"), C("93a3a0"), C("4f8a3f"), C("8dff7a")
    arm_up = 8 if pose == 1 else 0
    d.rectangle([16, 50, 27, 63], fill=st_d); d.rectangle([36, 50, 47, 63], fill=st_d)
    d.rectangle([10, 22, 53, 52], fill=st)
    d.rectangle([10, 22, 20, 52], fill=st_d); d.rectangle([44, 22, 53, 30], fill=st_l)
    d.polygon([(14, 12), (50, 12), (53, 24), (10, 24)], fill=st)
    d.rectangle([22, 6, 42, 20], fill=st_l); d.rectangle([22, 6, 28, 20], fill=st)
    d.rectangle([26, 11, 30, 13], fill=core); d.rectangle([35, 11, 39, 13], fill=core)
    d.ellipse([27, 30, 37, 40], fill=core)
    d.ellipse([29, 32, 35, 38], fill=C("e8ffd8"))
    d.rectangle([2, 24 - arm_up, 11, 46 - arm_up], fill=st); d.rectangle([52, 24 - arm_up, 61, 46 - arm_up], fill=st)
    d.rectangle([0, 44 - arm_up, 13, 54 - arm_up], fill=st_l); d.rectangle([50, 44 - arm_up, 63, 54 - arm_up], fill=st_l)
    for (x, y, w) in [(12, 20, 10), (30, 8, 10), (46, 22, 8), (20, 48, 6)]:
        d.rectangle([x, y, x + w, y + 2], fill=moss)
    rnd = random.Random(5)
    for _ in range(40):
        d.point((rnd.randint(10, 53), rnd.randint(22, 52)), fill=rnd.choice([st_d, st_l]))
    return outline(im)

def boss_weaver(pose=0):
    im, d = new(64, 64)
    robe, robe_d, mask, glow, thread = C("5a2a8a"), C("32184f"), C("ece6ff"), C("ff7af0"), C("d8a8ff")
    sway = 2 if pose == 1 else 0
    d.polygon([(24, 22), (40, 22), (50, 52 + sway), (32, 58), (14, 52 - sway)], fill=robe)
    d.polygon([(24, 22), (30, 22), (26, 58), (14, 52)], fill=robe_d)
    for i in range(6):
        x = 12 + i * 8
        ln(d, (x, 52), (x - 2 + sway, 62), thread, 1)
    d.ellipse([22, 6, 42, 28], fill=C("2a1546"))
    d.ellipse([25, 9, 39, 25], fill=mask)
    d.rectangle([28, 15, 30, 17], fill=glow); d.rectangle([34, 15, 36, 17], fill=glow)
    d.line([(29, 21), (35, 21)], fill=C("32184f"))
    for k, (ax, ay) in enumerate([(8, 24), (4, 34), (56, 24), (60, 34), (10, 44), (54, 44)]):
        ex, ey = ax - (3 if pose and ax < 32 else 0), ay - (4 if pose else 0)
        ln(d, (24 if ax < 32 else 40, 28 + k % 2 * 4), (ex, ey), robe_d, 2)
        d.ellipse([ex - 2, ey - 2, ex + 2, ey + 2], fill=glow)
    d.polygon([(32, 0), (35, 6), (29, 6)], fill=glow)
    return outline(im)

def boss_regent(pose=0):
    im, d = new(64, 64)
    ar, ar_d, ar_l, cape, glow = C("3b3652"), C("201c32"), C("6a6590"), C("5a1d4a"), C("b86bff")
    d.polygon([(14, 20), (50, 20), (62, 62), (2, 62)], fill=cape)
    d.polygon([(14, 20), (24, 20), (14, 62), (2, 62)], fill=C("3a1030"))
    d.rectangle([22, 48, 30, 63], fill=ar_d); d.rectangle([34, 48, 42, 63], fill=ar_d)
    d.rectangle([18, 22, 46, 50], fill=ar); d.rectangle([18, 22, 26, 50], fill=ar_d)
    d.rectangle([14, 20, 24, 28], fill=ar_l); d.rectangle([40, 20, 50, 28], fill=ar_l)
    d.ellipse([27, 31, 38, 44], fill=C("0c0816")); d.ellipse([29, 34, 36, 42], fill=glow)
    d.rectangle([24, 4, 40, 20], fill=ar_l); d.rectangle([24, 4, 29, 20], fill=ar)
    d.rectangle([27, 10, 31, 12], fill=glow); d.rectangle([34, 10, 38, 12], fill=glow)
    for x in (24, 29, 34, 39):
        d.polygon([(x, 4), (x + 2, -1 if x != 29 else -3), (x + 4, 4)], fill=C("e0b83a"))
    up = 10 if pose == 1 else 0
    d.rectangle([48, 26 - up, 53, 44 - up], fill=ar)
    ln(d, (52, 26 - up), (60, 0 + (10 if pose == 1 else 20)), C("e8f0ff"), 3)
    d.rectangle([49, 25 - up, 57, 28 - up], fill=C("e0b83a"))
    d.rectangle([10, 28, 17, 44], fill=ar)
    return outline(im)

def boss_frames(fn):
    F = [fn(0), fn(1), fn(1), fn(0)]
    b = fn(0)
    rot = b.transpose(Image.ROTATE_270); bb = rot.getbbox()
    dead = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    dead.paste(rot.crop(bb), (max(0, (64 - (bb[2] - bb[0])) // 2), 63 - (bb[3] - bb[1])))
    F.append(dead)
    return F
BOSS_ANIMS = {"idle": [0, 2, 3, True], "attack": [1, 2, 4, False], "hurt": [3, 1, 1, False], "dead": [4, 1, 1, False]}

# ---------------------------------------------------------------- palettes / tiles
PAL = {
 1: dict(dark=C("1f2a1f"), mid=C("33492f"), light=C("4f7340"), accent=C("6fae4a"), acc_d=C("3e7a35"), kind="soil"),
 2: dict(dark=C("22283a"), mid=C("3a4560"), light=C("5d6c93"), accent=C("4f8a6a"), acc_d=C("2f5f4a"), kind="brick"),
 3: dict(dark=C("221915"), mid=C("3d2d24"), light=C("5c4536"), accent=C("5a7a68"), acc_d=C("3a5a4a"), kind="rock"),
 4: dict(dark=C("261640"), mid=C("48267a"), light=C("7a46b8"), accent=C("c46af0"), acc_d=C("8a3ab8"), kind="crystal"),
 5: dict(dark=C("231c20"), mid=C("42343a"), light=C("6b5058"), accent=C("a8503a"), acc_d=C("6a2f26"), kind="brick"),
 6: dict(dark=C("1c1c2e"), mid=C("39395a"), light=C("6a6a98"), accent=C("d8c070"), acc_d=C("9a8640"), kind="marble"),
}

def tile_fill(z, v):
    p = PAL[z]; rnd = random.Random(z * 100 + v)
    im, d = new(16, 16)
    d.rectangle([0, 0, 15, 15], fill=p['mid'])
    k = p['kind']
    if k in ('brick', 'marble'):
        for y in (0, 8):
            d.line([(0, y), (15, y)], fill=p['dark'])
        xs = (0, 8) if v == 0 else (4, 12)
        for x in xs:
            d.line([(x, 1), (x, 7)], fill=p['dark'])
        for x in [(x + 4) % 16 for x in xs]:
            d.line([(x, 9), (x, 15)], fill=p['dark'])
        d.line([(1, 1), (6, 1)], fill=p['light'])
    elif k == 'crystal':
        for i in range(3):
            x = rnd.randint(0, 12)
            ln(d, (x, 0), (x + 3, 15), p['light'], 1)
    for _ in range(22):
        im.putpixel((rnd.randint(0, 15), rnd.randint(0, 15)), rnd.choice([p['dark'], p['light'], p['mid']]))
    return im

def tile_top(z, v):
    p = PAL[z]; rnd = random.Random(z * 100 + v + 50)
    im = tile_fill(z, v); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 3], fill=p['accent'])
    d.line([(0, 0), (15, 0)], fill=p['light'] if z in (2, 3, 5) else p['accent'])
    for x in range(16):
        h = rnd.choice([3, 4, 4, 5, 6])
        d.line([(x, 3), (x, h)], fill=p['accent'] if rnd.random() < .6 else p['acc_d'])
    for _ in range(4):
        im.putpixel((rnd.randint(0, 15), rnd.randint(1, 3)), p['light'])
    d.line([(0, 6), (15, 6)], fill=p['dark'])
    return im

def tile_plat(z):
    p = PAL[z]
    im, d = new(16, 16)
    d.rectangle([0, 0, 15, 5], fill=p['light'])
    d.line([(0, 0), (15, 0)], fill=p['accent'])
    d.line([(0, 5), (15, 5)], fill=p['dark'])
    for x in (3, 8, 13):
        d.line([(x, 1), (x, 4)], fill=p['mid'])
    d.rectangle([0, 6, 1, 8], fill=p['dark']); d.rectangle([14, 6, 15, 8], fill=p['dark'])
    return outline(im, p['dark']) if False else im

def tile_crack(z):
    p = PAL[z]
    im = tile_fill(z, 1); d = ImageDraw.Draw(im)
    d.rectangle([0, 0, 15, 15], outline=p['light'])
    pts = [(8, 0), (6, 4), (9, 7), (5, 10), (8, 15)]
    d.line(pts, fill=C("0d0a14"), width=1)
    d.line([(9, 7), (14, 9)], fill=C("0d0a14"))
    d.point((3, 3), fill=p['accent']); d.point((12, 12), fill=p['accent'])
    d.rectangle([2, 2, 3, 3], fill=p['accent'])
    return im

def d_blades(z, v):
    p = PAL[z]; im, d = new(16, 16); rnd = random.Random(z * 7 + v)
    for i in range(5):
        x = 3 + i * 2 + rnd.randint(0, 1)
        ln(d, (x, 15), (x + rnd.randint(-2, 2), 15 - rnd.randint(4, 9)), p['accent'] if i % 2 else p['acc_d'], 1)
    return im
def d_cap(z, v):
    im, d = new(16, 16)
    cols = [(C("d0453a"), C("f2e8d8")), (C("5adcc8"), C("e8fff8")), (C("c46af0"), C("f0d8ff")), (C("e0903a"), C("f8e8c8")), (C("d8c070"), C("fff8d8")), (C("d0453a"), C("f2e8d8"))]
    cap, stem = cols[(z + v) % len(cols)]
    d.rectangle([7, 9, 8, 15], fill=stem); d.ellipse([3, 4, 12, 10], fill=cap); d.point((6, 6), fill=stem); d.point((9, 7), fill=stem)
    return im
def d_rock(z, v):
    p = PAL[z]; im, d = new(16, 16)
    d.polygon([(2, 15), (4, 9), (9, 7), (13, 10), (14, 15)], fill=p['light'])
    d.polygon([(2, 15), (4, 9), (7, 9), (6, 15)], fill=p['mid'])
    return im
def d_crystal(z, v):
    im, d = new(16, 16)
    col = [C("5adcc8"), C("5adcc8"), C("7fe8d8"), C("ff7af0"), C("ff9a50"), C("e8e0ff")][z - 1]
    d.polygon([(7, 15), (5, 6), (8, 1), (11, 6), (10, 15)], fill=col)
    d.polygon([(7, 15), (5, 6), (8, 1), (8, 15)], fill=C("ffffff", 90))
    d.polygon([(2, 15), (3, 10), (5, 15)], fill=col)
    return im
def d_pillar(z, v):
    p = PAL[z]; im, d = new(16, 16)
    d.rectangle([5, 4, 10, 15], fill=p['light']); d.rectangle([5, 4, 6, 15], fill=p['mid'])
    d.rectangle([3, 2, 12, 4], fill=p['light']); d.polygon([(5, 4), (10, 4), (8, 9), (7, 7)], fill=C("00000000", 0))
    return im
def d_skull(z, v):
    im, d = new(16, 16)
    d.ellipse([4, 8, 11, 14], fill=C("e4dccb")); d.point((6, 11), fill=C("201820")); d.point((9, 11), fill=C("201820"))
    d.rectangle([3, 14, 12, 15], fill=C("b8ae98"))
    return im
def d_candle(z, v):
    im, d = new(16, 16)
    d.rectangle([6, 8, 9, 15], fill=C("f2e8d8")); d.polygon([(7, 8), (8, 4), (9, 8)], fill=C("ffd36a"))
    return im
def d_ember(z, v):
    p = PAL[z]; im, d = new(16, 16)
    d.polygon([(2, 15), (5, 11), (10, 11), (14, 15)], fill=p['mid'])
    for x, y in [(6, 10), (9, 9), (11, 12), (4, 13)]:
        d.point((x, y), fill=C("ff9a50"))
    return im

DECOR = {1: (d_blades, d_cap, d_rock), 2: (d_pillar, d_blades, d_rock), 3: (d_rock, d_cap, d_skull),
         4: (d_crystal, d_rock, d_crystal), 5: (d_ember, d_skull, d_rock), 6: (d_candle, d_pillar, d_crystal)}

# ---------------------------------------------------------------- props
def p_spikes():
    im, d = new(16, 16)
    for x in (0, 4, 8, 12):
        d.polygon([(x, 15), (x + 2, 6), (x + 4, 15)], fill=C("b8c4d8"))
        d.polygon([(x, 15), (x + 2, 6), (x + 2, 15)], fill=C("7c889c"))
    d.line([(0, 15), (15, 15)], fill=C("3a3548"))
    return outline(im)
def p_door():
    im, d = new(16, 16)
    d.rectangle([0, 0, 15, 15], fill=C("5a3a24")); d.rectangle([0, 0, 2, 15], fill=C("3e2616")); d.rectangle([13, 0, 15, 15], fill=C("3e2616"))
    d.line([(8, 0), (8, 15)], fill=C("2c1a0e")); d.rectangle([0, 3, 15, 4], fill=C("8a8f9a")); d.rectangle([0, 11, 15, 12], fill=C("8a8f9a"))
    d.ellipse([5, 6, 10, 9], fill=C("e0b83a"))
    return im
def p_shrine(on):
    im, d = new(16, 32)
    d.rectangle([2, 22, 13, 31], fill=C("4a4f66")); d.rectangle([4, 14, 11, 22], fill=C("6a708c")); d.rectangle([2, 22, 4, 31], fill=C("343850"))
    d.rectangle([3, 12, 12, 14], fill=C("8a90ac"))
    col = C("7fe9ff") if on else C("4a5068")
    d.ellipse([4, 3, 11, 11], fill=col)
    if on:
        d.ellipse([6, 5, 9, 8], fill=C("ffffff"))
        for x, y in [(2, 6), (13, 4), (1, 10), (14, 9)]:
            d.point((x, y), fill=C("bff6ff"))
    return outline(im)
def p_chest(open_):
    im, d = new(16, 16)
    d.rectangle([1, 7, 14, 15], fill=C("7a4a26")); d.rectangle([1, 7, 14, 9], fill=C("9a6232"))
    d.rectangle([1, 12, 14, 12], fill=C("5a3418")); d.rectangle([7, 8, 8, 12], fill=C("e0b83a"))
    if open_:
        d.rectangle([1, 7, 14, 15], fill=C("2a1608")); d.rectangle([2, 8, 13, 10], fill=C("ffd36a"))
        d.polygon([(1, 7), (14, 7), (13, 2), (2, 2)], fill=C("9a6232"))
    else:
        d.polygon([(1, 7), (14, 7), (13, 4), (2, 4)], fill=C("9a6232"))
    return outline(im)
def p_key():
    im, d = new(16, 16)
    d.ellipse([2, 3, 8, 9], outline=C("ffd36a"), width=2); d.line([(7, 8), (13, 14)], fill=C("ffd36a"), width=2); d.line([(11, 12), (13, 10)], fill=C("ffd36a"))
    return outline(im)
def p_coin(f):
    im, d = new(16, 16)
    w = [4, 3, 1, 3][f]
    d.ellipse([8 - w, 4, 8 + w, 12], fill=C("ffd36a")); d.ellipse([8 - w + 1, 5, 8 + w - 1, 11], fill=C("ffae2a")) if w > 2 else None
    if w > 2:
        d.point((8, 8), fill=C("fff0b0"))
    return outline(im)
def p_heart():
    im, d = new(16, 16)
    d.polygon([(8, 14), (2, 8), (2, 5), (4, 3), (6, 3), (8, 5), (10, 3), (12, 3), (14, 5), (14, 8)], fill=C("e8344a"))
    d.point((5, 5), fill=C("ffb0b8")); d.point((4, 6), fill=C("ffb0b8"))
    return outline(im)
def p_mana():
    im, d = new(16, 16)
    d.polygon([(8, 1), (13, 8), (8, 15), (3, 8)], fill=C("3aa8ff")); d.polygon([(8, 1), (3, 8), (8, 15)], fill=C("1f6ad0"))
    d.point((9, 5), fill=C("d8f0ff"))
    return outline(im)
def p_sigil(col):
    im, d = new(16, 16)
    d.ellipse([2, 2, 13, 13], fill=col); d.ellipse([5, 5, 10, 10], fill=C("ffffff"))
    d.polygon([(8, 0), (9, 3), (7, 3)], fill=col)
    return outline(im)
def p_pedestal():
    im, d = new(16, 16)
    d.rectangle([2, 8, 13, 15], fill=C("6a708c")); d.rectangle([4, 5, 11, 8], fill=C("8a90ac")); d.rectangle([2, 8, 4, 15], fill=C("4a4f66"))
    return outline(im)
def p_tablet():
    im, d = new(16, 24)
    d.polygon([(3, 23), (3, 5), (8, 1), (13, 5), (13, 23)], fill=C("767c94")); d.polygon([(3, 23), (3, 5), (8, 1), (6, 23)], fill=C("585e76"))
    for y in (8, 12, 16):
        d.line([(5, y), (11, y)], fill=C("3a3e54"))
    d.point((8, 5), fill=C("7fe9ff"))
    return outline(im)
def p_portal(f):
    im, d = new(32, 48)
    for i, (rx, ry, col) in enumerate([(14, 22, C("3a1a6a")), (11, 18, C("6a3ab8")), (8, 14, C("a06af0")), (5, 9, C("e0c8ff"))]):
        d.ellipse([16 - rx, 24 - ry, 16 + rx, 24 + ry], fill=col)
    for k in range(6):
        a = f * 0.5 + k * math.pi / 3
        x, y = 16 + math.cos(a) * 9, 24 + math.sin(a) * 15
        d.rectangle([round(x), round(y), round(x) + 1, round(y) + 1], fill=C("ffffff"))
    return im
def p_torch(f):
    im, d = new(8, 16)
    d.rectangle([3, 7, 4, 15], fill=C("5a3a24")); d.rectangle([2, 6, 5, 7], fill=C("8a8f9a"))
    h = [5, 6, 4][f]
    d.polygon([(2, 6), (4 - (f == 1), 6 - h), (6, 6)], fill=C("ff8a2a")); d.polygon([(3, 6), (4, 6 - h + 2), (5, 6)], fill=C("ffe08a"))
    return im
def p_bolt(f):
    im, d = new(16, 16)
    r = [3, 4, 3][f]
    d.polygon([(0, 8), (5, 6 - f % 2), (5, 10 + f % 2)], fill=C("2a7ad0", 180))
    d.ellipse([8 - r + 2, 8 - r, 8 + r + 2, 8 + r], fill=C("5adcff")); d.ellipse([8 - r + 4, 8 - r + 2, 8 + r, 8 + r - 2], fill=C("ffffff"))
    return im
def p_slash(f):
    im, d = new(32, 32)
    cols = [C("ffffff", 120), C("ffffff", 220), C("bff6ff", 150)]
    R = [10, 13, 15][f]
    box = [16 - R, 16 - R, 16 + R, 16 + R]
    a0, a1 = [(-90, -30), (-60, 40), (-20, 70)][f]
    d.arc(box, a0, a1, fill=cols[f], width=3)
    d.arc([box[0] + 2, box[1] + 2, box[2] - 2, box[3] - 2], a0, a1, fill=C("ffffff", 200), width=1)
    return im
def p_arrow():
    im, d = new(12, 5)
    d.line([(0, 2), (10, 2)], fill=C("e0d0a0")); d.polygon([(8, 0), (11, 2), (8, 4)], fill=C("c0c8d8")); d.point((0, 1), fill=C("ff5a8a")); d.point((0, 3), fill=C("ff5a8a"))
    return im
def p_orb(col):
    im, d = new(12, 12)
    d.ellipse([1, 1, 10, 10], fill=col); d.ellipse([3, 3, 8, 8], fill=C("ffffff", 230))
    return im
def p_rock():
    im, d = new(12, 12)
    d.polygon([(1, 8), (3, 2), (8, 1), (11, 6), (9, 11), (3, 11)], fill=C("7a8886")); d.polygon([(1, 8), (3, 2), (6, 3), (5, 11), (3, 11)], fill=C("4a5654"))
    return outline(im)
def p_icon_heart():
    return p_heart()
def p_gate():
    im, d = new(16, 16)
    d.rectangle([0, 0, 15, 15], fill=C("2a1a3a")); d.rectangle([6, 0, 9, 15], fill=C("6a3ab8")); d.line([(0, 8), (15, 8)], fill=C("a06af0"))
    return im

# ---------------------------------------------------------------- atlas
def build_atlas():
    items = []
    def add(name, im): items.append((name, im))
    for z in range(1, 7):
        add(f"t{z}_top", tile_top(z, 0)); add(f"t{z}_top2", tile_top(z, 1))
        add(f"t{z}_fill", tile_fill(z, 0)); add(f"t{z}_fill2", tile_fill(z, 1))
        add(f"t{z}_plat", tile_plat(z)); add(f"t{z}_crack", tile_crack(z))
        for i, fn in enumerate(DECOR[z]):
            add(f"t{z}_decor{i + 1}", fn(z, i))
    add("spikes", p_spikes()); add("door", p_door()); add("gate", p_gate())
    add("shrine_off", p_shrine(False)); add("shrine_on", p_shrine(True))
    add("chest", p_chest(False)); add("chest_open", p_chest(True))
    add("key", p_key()); add("heart", p_heart()); add("mana", p_mana())
    add("sigil_double_jump", p_sigil(C("7fffa0"))); add("sigil_ember", p_sigil(C("ff9a50"))); add("pedestal", p_pedestal())
    add("tablet", p_tablet())
    for f in range(4):
        add(f"coin_{f}", p_coin(f)); add(f"portal_{f}", p_portal(f))
    for f in range(3):
        add(f"torch_{f}", p_torch(f)); add(f"bolt_{f}", p_bolt(f)); add(f"slash_{f}", p_slash(f))
    add("arrow", p_arrow()); add("orb", p_orb(C("d85af0"))); add("orb_red", p_orb(C("ff5a5a"))); add("rock", p_rock())
    add("icon_heart", p_icon_heart()); add("icon_mana", p_mana()); add("icon_key", p_key()); add("icon_coin", p_coin(0))
    W = 512
    x = y = rowh = 0
    pos = {}
    for name, im in sorted(items, key=lambda t: -t[1].size[1]):
        w, h = im.size
        if x + w > W:
            x = 0; y += rowh + 1; rowh = 0
        pos[name] = [x, y, w, h]
        x += w + 1; rowh = max(rowh, h)
    H_ = y + rowh + 1
    atlas = Image.new("RGBA", (W, H_), (0, 0, 0, 0))
    for name, im in items:
        atlas.paste(im, tuple(pos[name][:2]))
    atlas.save(P("assets/sprites/atlas.png"))
    json.dump(pos, open(P("data/atlas.json"), "w"))
    print("atlas", atlas.size, len(pos), "sprites")

# ---------------------------------------------------------------- backgrounds
BG = {
 1: dict(top="#1d1233", bot="#a85a5a", far="#2b1d3f", near="#150f22", style="pines"),
 2: dict(top="#0e1a33", bot="#3d6a8a", far="#1d3350", near="#0e1a2b", style="ruins"),
 3: dict(top="#0d0a0c", bot="#2a1e1a", far="#1c1412", near="#0c0808", style="cave"),
 4: dict(top="#1a0a3a", bot="#c04aa8", far="#3a1a6a", near="#1c0c38", style="floating"),
 5: dict(top="#1a0c10", bot="#7a3020", far="#2e1418", near="#14080b", style="castle"),
 6: dict(top="#0a0a1a", bot="#6a5a8a", far="#26264a", near="#101028", style="spire"),
}
def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def bg_sky(z):
    cfg = BG[z]; top, bot = C(cfg['top'])[:3], C(cfg['bot'])[:3]
    im = Image.new("RGBA", (256, 144), (0, 0, 0, 255)); d = ImageDraw.Draw(im)
    for y in range(144):
        t = (y / 143) ** 1.3
        d.line([(0, y), (255, y)], fill=lerp(top, bot, t) + (255,))
    rnd = random.Random(z)
    for _ in range(50 if z != 5 else 20):
        x, y = rnd.randint(0, 255), rnd.randint(0, 70)
        im.putpixel((x, y), (255, 255, 255, 255) if rnd.random() < .5 else (200, 200, 255, 255))
    if z in (1, 2, 6):
        cx, cy, r = 190, 40, 14
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=(240, 230, 210, 255) if z != 1 else (255, 190, 130, 255))
        d.ellipse([cx - r + 5, cy - r - 1, cx + r + 5, cy + r - 1], fill=lerp(top, bot, (cy / 143) ** 1.3) + (255,))
    if z == 4:
        for i in range(5):
            y = 20 + i * 18
            d.line([(0, y), (255, y + 10)], fill=(200, 100, 255, 70), width=2)
    if z == 5:
        d.ellipse([170, 18, 214, 62], fill=(120, 40, 30, 255))
    return im

def bg_silhouette(z, layer):
    cfg = BG[z]; col = C(cfg['far'] if layer == 1 else cfg['near'])
    im, d = new(256, 144)
    rnd = random.Random(z * 10 + layer)
    base = 144
    style = cfg['style']
    n = 14 if layer == 1 else 8
    for i in range(n):
        x = int(i * 256 / n + rnd.randint(-6, 6))
        for off in (-256, 0, 256):
            xx = x + off
            if style == "pines":
                h = rnd.randint(40, 70) if layer == 1 else rnd.randint(60, 100)
                w = 10 if layer == 1 else 16
                for k in range(4):
                    d.polygon([(xx - w + k * 2, base - h * (k + 1) / 4 + 6), (xx, base - h * (k + 1) / 4 - h / 5), (xx + w - k * 2, base - h * (k + 1) / 4 + 6)], fill=col)
                d.rectangle([xx - 2, base - 14, xx + 2, base], fill=col)
            elif style == "ruins":
                h = rnd.randint(35, 80); w = rnd.choice([6, 8, 10])
                d.rectangle([xx - w, base - h, xx + w, base], fill=col)
                if rnd.random() < .5:
                    d.polygon([(xx - w, base - h), (xx, base - h - 8), (xx + w, base - h)], fill=col)
                if rnd.random() < .4:
                    d.arc([xx, base - h - 10, xx + 30, base - h + 20], 180, 360, fill=col, width=4)
            elif style == "cave":
                h = rnd.randint(20, 60)
                d.polygon([(xx - 8, 0), (xx, h), (xx + 8, 0)], fill=col)
                h2 = rnd.randint(20, 50)
                d.polygon([(xx + 12, base), (xx + 18, base - h2), (xx + 26, base)], fill=col)
            elif style == "floating":
                w = rnd.randint(14, 28); y = rnd.randint(30, 100)
                d.polygon([(xx - w, y), (xx + w, y), (xx + w // 2, y + 12), (xx, y + 22), (xx - w // 2, y + 12)], fill=col)
                d.polygon([(xx, y - 14), (xx + 4, y), (xx - 4, y)], fill=col)
            elif style == "castle":
                h = rnd.randint(40, 90); w = rnd.choice([10, 14])
                d.rectangle([xx - w, base - h, xx + w, base], fill=col)
                for m in range(-w, w, 6):
                    d.rectangle([xx + m, base - h - 5, xx + m + 3, base - h], fill=col)
                if rnd.random() < .5:
                    d.polygon([(xx - w, base - h - 5), (xx, base - h - 26), (xx + w, base - h - 5)], fill=col)
            else:
                h = rnd.randint(60, 130); w = rnd.choice([5, 7])
                d.polygon([(xx - w, base), (xx - 2, base - h), (xx, base - h - 14), (xx + 2, base - h), (xx + w, base)], fill=col)
                d.ellipse([xx - 12, base - h * 0.6, xx + 12, base - h * 0.6 + 4], outline=col)
    d.rectangle([0, 138, 255, 143], fill=col)
    return im

def build_backgrounds():
    for z in range(1, 7):
        bg_sky(z).save(P(f"assets/backgrounds/bg_z{z}_0.png"))
        bg_silhouette(z, 1).save(P(f"assets/backgrounds/bg_z{z}_1.png"))
        bg_silhouette(z, 2).save(P(f"assets/backgrounds/bg_z{z}_2.png"))
    print("backgrounds ok")

def build_icon():
    im = Image.new("RGBA", (48, 48), (20, 10, 40, 255)); d = ImageDraw.Draw(im)
    for y in range(48):
        d.line([(0, y), (47, y)], fill=lerp((24, 12, 52), (120, 50, 90), y / 47) + (255,))
    d.ellipse([10, 10, 38, 38], fill=(255, 190, 120, 255)); d.ellipse([16, 8, 44, 36], fill=lerp((24, 12, 52), (120, 50, 90), .4) + (255,))
    d.polygon([(0, 48), (0, 36), (10, 30), (20, 38), (30, 28), (48, 40), (48, 48)], fill=(14, 8, 24, 255))
    ln(d, (14, 40), (34, 12), (234, 243, 255, 255), 2); ln(d, (30, 20), (38, 24), (224, 184, 58, 255), 2)
    d.ellipse([10, 36, 16, 42], fill=(127, 233, 255, 255))
    im = im.resize((192, 192), Image.NEAREST)
    im.save(P("icon.png"))
    im.resize((432, 432), Image.NEAREST).save(P("assets/sprites/icon_432.png"))

def build_characters():
    sheets = {}
    def put(name, frames, fw, fh, anims):
        sheet(frames, fw, fh).save(P(f"assets/sprites/{name}.png"))
        sheets[name] = {"file": f"res://assets/sprites/{name}.png", "fw": fw, "fh": fh,
                        "anims": {k: {"start": v[0], "count": v[1], "fps": v[2], "loop": v[3]} for k, v in anims.items()}}
    put("hero", hero_frames(), 32, 32, HERO_ANIMS)
    put("husk", husk_frames(), 32, 32, HUSK_ANIMS)
    put("archer", archer_frames(), 32, 32, ARCHER_ANIMS)
    put("bat", bat_frames(), 24, 24, BAT_ANIMS)
    put("colossus", boss_frames(boss_colossus), 64, 64, BOSS_ANIMS)
    put("weaver", boss_frames(boss_weaver), 64, 64, BOSS_ANIMS)
    put("regent", boss_frames(boss_regent), 64, 64, BOSS_ANIMS)
    json.dump(sheets, open(P("data/sprites.json"), "w"), indent=1)
    print("characters ok")

if __name__ == "__main__":
    build_characters(); build_atlas(); build_backgrounds(); build_icon()
