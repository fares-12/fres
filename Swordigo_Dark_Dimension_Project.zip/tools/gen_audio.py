#!/usr/bin/env python3
"""Procedural audio (original). 22.05 kHz mono 16-bit WAV."""
import os, wave, random
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SR = 22050
def out(path, x):
    p = os.path.join(ROOT, path); os.makedirs(os.path.dirname(p), exist_ok=True)
    x = np.clip(x, -1, 1)
    with wave.open(p, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32000).astype('<i2').tobytes())
def tt(d): return np.arange(int(d * SR)) / SR
def osc(f, t, kind="sin"):
    ph = (f * t) % 1.0 if np.isscalar(f) else (np.cumsum(f) / SR) % 1.0
    if kind == "sin": return np.sin(2 * np.pi * ph)
    if kind == "sq": return np.sign(np.sin(2 * np.pi * ph)) * 0.6
    if kind == "tri": return 2 * np.abs(2 * ph - 1) - 1
    return 2 * ph - 1
def sweep(f0, f1, d, kind="sin", dec=None):
    t = tt(d); f = np.linspace(f0, f1, len(t))
    e = np.exp(-t / (dec or d / 2.5)) * np.minimum(1, t / 0.004)
    return osc(f, t, kind) * e
def noise(d, dec=0.1, seed=1):
    r = np.random.RandomState(seed); t = tt(d)
    return (r.rand(len(t)) * 2 - 1) * np.exp(-t / dec)
def lp(x, k):
    y = np.copy(x)
    for i in range(1, len(y)): y[i] = y[i - 1] + k * (x[i] - y[i - 1])
    return y
def cat(*a):
    return np.concatenate(a)
def pad(x, n):
    return np.concatenate([x, np.zeros(max(0, n - len(x)))])
def mixs(*a):
    n = max(len(i) for i in a); return sum(pad(i, n) for i in a)

def build_sfx():
    S = {}
    S["jump"] = sweep(260, 620, .16, "sq", .08) * .35
    S["djump"] = sweep(420, 980, .2, "tri", .1) * .5
    S["land"] = lp(noise(.08, .03, 2), .3) * .6
    S["sword"] = mixs(lp(noise(.16, .05, 3), .7) * .5, sweep(900, 300, .16, "saw", .05) * .15)
    S["hit"] = mixs(noise(.1, .03, 4) * .6, sweep(220, 70, .12, "sin", .05) * .8)
    S["magic"] = mixs(sweep(500, 1500, .3, "sin", .15) * .5, sweep(750, 2200, .3, "tri", .1) * .2)
    S["hurt"] = sweep(380, 90, .28, "saw", .12) * .45
    S["enemy_die"] = mixs(noise(.3, .09, 5) * .5, sweep(300, 50, .3, "sq", .12) * .4)
    S["coin"] = cat(sweep(880, 880, .05, "sq", .05) * .3, sweep(1320, 1320, .12, "sq", .08) * .3)
    S["pickup"] = cat(sweep(523, 523, .07, "tri", .06), sweep(659, 659, .07, "tri", .06), sweep(784, 784, .16, "tri", .1)) * .5
    S["door"] = mixs(lp(noise(.6, .25, 6), .08) * 1.2, sweep(90, 50, .6, "sin", .3) * .8)
    S["save"] = mixs(*[sweep(f, f, 1.0, "sin", .45) * .3 for f in (523, 659, 784, 1047)])
    S["boss_appear"] = mixs(sweep(130, 55, 1.1, "saw", .6) * .5, lp(noise(1.1, .5, 7), .25) * .6, sweep(65, 65, 1.1, "sin", .8) * .6)
    S["boss_attack"] = mixs(sweep(300, 90, .35, "saw", .15) * .45, lp(noise(.3, .1, 10), .5) * .5)
    S["boss_defeat"] = cat(mixs(sweep(200, 40, 1.4, "saw", .6) * .5, lp(noise(1.4, .5, 11), .2) * .8), sweep(40, 40, .3, "sin", .2) * .0)
    S["magic_hit"] = mixs(noise(.12, .04, 12) * .4, sweep(1200, 400, .14, "sin", .06) * .5)
    S["chest"] = cat(noise(.08, .03, 13) * .4, sweep(392, 392, .08, "tri", .08) * .5, sweep(523, 523, .08, "tri", .08) * .5, sweep(659, 659, .08, "tri", .08) * .5, sweep(1047, 1047, .35, "tri", .2) * .5)
    S["zone_enter"] = mixs(cat(sweep(150, 600, .5, "sin", .4), sweep(600, 200, .6, "sin", .3)) * .5, lp(noise(1.1, .5, 14), .1) * .4)
    S["click"] = sweep(700, 500, .05, "sq", .03) * .3
    S["portal"] = cat(sweep(200, 900, .35, "sin", .3), sweep(900, 300, .3, "sin", .2)) * .5
    S["death"] = cat(sweep(400, 60, .8, "saw", .4) * .4)
    S["shot"] = sweep(900, 300, .14, "sq", .06) * .3
    S["break"] = mixs(lp(noise(.4, .12, 8), .4) * .9, sweep(120, 40, .35, "sin", .1) * .7)
    S["boom"] = mixs(lp(noise(.5, .2, 9), .15) * 1.0, sweep(80, 30, .5, "sin", .25))
    for k, v in S.items():
        gain = {"click": .4, "coin": .6, "jump": .6, "djump": .65, "land": .5, "shot": .6, "sword": .7, "hit": .85, "magic_hit": .7}.get(k, 1.0)
        v = v / max(1e-6, np.max(np.abs(v))) * 0.8 * gain
        v[:60] *= np.linspace(0, 1, 60)
        v[-60:] *= np.linspace(1, 0, 60)
        out(f"assets/audio/sfx/{k}.wav", v)
    print("sfx", len(S))

def midi(n): return 440.0 * 2 ** ((n - 69) / 12)
def note(f, d, kind, att, dec, vol):
    t = tt(d); return osc(f, t, kind) * np.minimum(1, t / att) * np.exp(-t / dec) * vol

def music(name, root, mode, prog, bpm, seed, lead="tri", pad_kind="tri", perc=False, wind=0.0, density=0.5, bars=8):
    rnd = random.Random(seed)
    beat = 60.0 / bpm; bar = beat * 4; N = int(bar * bars * SR)
    buf = np.zeros(N + SR * 3)
    def put(x, at):
        i = int(at * SR); buf[i:i + len(x)] += x[:len(buf) - i]
    def deg(d):
        return root + mode[d % 7] + 12 * (d // 7)
    for b in range(bars):
        d0 = prog[b % len(prog)]; t0 = b * bar
        chord = [deg(d0), deg(d0 + 2), deg(d0 + 4)]
        for n in chord:
            put(note(midi(n), bar, pad_kind, .6, 2.2, .10), t0)
        for k in (0, 2):
            put(note(midi(deg(d0) - 12), beat * 1.8, "sin", .01, .5, .35), t0 + k * beat)
        for s in range(8):
            if rnd.random() < density:
                n = chord[(s + b) % 3] + (12 if s % 4 == 3 else 0)
                put(note(midi(n + 12), beat * .5, lead if lead != "mix" else "sq", .005, .14, .11), t0 + s * beat / 2)
        if rnd.random() < .8:
            ls = rnd.choice([0, 1, 2, 3, 4, 5, 6])
            for k in range(rnd.choice([2, 3, 4])):
                ls = max(0, min(13, ls + rnd.choice([-2, -1, 1, 2])))
                put(note(midi(deg(ls) + 12), beat * .9, "tri", .02, .45, .16), t0 + (k * 1.0 + rnd.choice([0, 0.5])) * beat)
        if perc:
            for k in range(4):
                put(sweep(120, 40, .18, "sin", .08) * .55, t0 + k * beat) if k % 2 == 0 else put(noise(.12, .04, k + b) * .25, t0 + k * beat)
            for s in range(8):
                put(noise(.04, .015, s) * .08, t0 + s * beat / 2)
    if wind > 0:
        w = lp(np.random.RandomState(seed).rand(len(buf)) * 2 - 1, .02); w = w / (np.max(np.abs(w)) + 1e-6)
        mod = .5 + .5 * np.sin(np.arange(len(buf)) / SR * 2 * np.pi / (bar * 2))
        buf += w * mod * wind
    # fold tail back for seamless loop
    tail = buf[N:]; buf = buf[:N]; buf[:len(tail)] += tail[:N]
    buf = buf / (np.max(np.abs(buf)) + 1e-6) * 0.7
    buf[:200] *= np.linspace(0, 1, 200); buf[-200:] *= np.linspace(1, 0, 200)
    out(f"assets/audio/music/{name}.wav", buf)

MINOR = [0, 2, 3, 5, 7, 8, 10]; DORIAN = [0, 2, 3, 5, 7, 9, 10]; PHRYG = [0, 1, 3, 5, 7, 8, 10]; LYD = [0, 2, 4, 6, 7, 9, 11]; HM = [0, 2, 3, 5, 7, 8, 11]

def build_music():
    music("menu", 45, MINOR, [0, 5, 3, 4], 66, 1, "tri", "tri", False, .03, .35)
    music("z1", 50, DORIAN, [0, 3, 5, 4], 78, 2, "tri", "tri", False, .05, .5)
    music("z2", 47, MINOR, [0, 2, 5, 3], 70, 3, "tri", "sin", False, .06, .45)
    music("z3", 40, PHRYG, [0, 1, 0, 6], 62, 4, "sin", "sin", False, .09, .3)
    music("z4", 52, LYD, [0, 4, 1, 5], 84, 5, "mix", "tri", False, .03, .6)
    music("z5", 43, HM, [0, 5, 3, 4], 74, 6, "mix", "tri", False, .05, .5)
    music("z6", 48, DORIAN, [0, 4, 5, 3], 76, 7, "tri", "tri", False, .04, .55)
    music("combat", 43, PHRYG, [0, 5, 0, 6], 116, 9, "mix", "saw", True, .02, .75)
    music("boss", 41, PHRYG, [0, 0, 5, 6], 132, 8, "mix", "saw", True, .02, .8)
    print("music 9")

if __name__ == "__main__":
    build_sfx(); build_music()
