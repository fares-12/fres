extends Node
## Sprite helper: atlas textures and SpriteFrames built from generated data.

var atlas: Texture2D
var rects: Dictionary = {}
var sheets: Dictionary = {}
var _tex_cache: Dictionary = {}
var _frames_cache: Dictionary = {}

func _ready() -> void:
    atlas = load("res://assets/sprites/atlas.png")
    rects = _read_json("res://data/atlas.json")
    sheets = _read_json("res://data/sprites.json")

func _read_json(path: String) -> Dictionary:
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        push_error("Missing data file: " + path)
        return {}
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("Bad JSON: " + path)
        return {}
    return parsed

func has_tex(sprite_name: String) -> bool:
    return rects.has(sprite_name)

func tex(sprite_name: String) -> Texture2D:
    if _tex_cache.has(sprite_name):
        return _tex_cache[sprite_name]
    if not rects.has(sprite_name):
        push_warning("Missing atlas sprite: " + sprite_name)
        return null
    var r: Array = rects[sprite_name]
    var t := AtlasTexture.new()
    t.atlas = atlas
    t.region = Rect2(r[0], r[1], r[2], r[3])
    _tex_cache[sprite_name] = t
    return t

func frames(sheet_name: String) -> SpriteFrames:
    if _frames_cache.has(sheet_name):
        return _frames_cache[sheet_name]
    var spec: Dictionary = sheets.get(sheet_name, {})
    var sf := SpriteFrames.new()
    sf.remove_animation("default")
    if spec.is_empty():
        push_error("Unknown sprite sheet: " + sheet_name)
        return sf
    var sheet_tex: Texture2D = load(spec["file"])
    var fw: int = int(spec["fw"])
    var fh: int = int(spec["fh"])
    var anims: Dictionary = spec["anims"]
    for an in anims:
        var a: Dictionary = anims[an]
        sf.add_animation(an)
        sf.set_animation_speed(an, float(a["fps"]))
        sf.set_animation_loop(an, bool(a["loop"]))
        var start: int = int(a["start"])
        for i in range(start, start + int(a["count"])):
            var at := AtlasTexture.new()
            at.atlas = sheet_tex
            at.region = Rect2(i * fw, 0, fw, fh)
            sf.add_frame(an, at)
    _frames_cache[sheet_name] = sf
    return sf

func atlas_frames(prefix: String, count: int, fps: float, loop: bool = true) -> SpriteFrames:
    var key := "%s|%d|%d|%s" % [prefix, count, int(fps), str(loop)]
    if _frames_cache.has(key):
        return _frames_cache[key]
    var sf := SpriteFrames.new()
    sf.remove_animation("default")
    sf.add_animation(prefix)
    sf.set_animation_speed(prefix, fps)
    sf.set_animation_loop(prefix, loop)
    for i in count:
        sf.add_frame(prefix, tex("%s_%d" % [prefix, i]))
    _frames_cache[key] = sf
    return sf
