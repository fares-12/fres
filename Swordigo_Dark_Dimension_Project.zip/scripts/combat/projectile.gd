extends Area2D
## Projectiles: player "bolt" (magic); enemy "arrow", "orb", "rock", "wave", "column"; "warn" marker (visual only).

var kind := "bolt"
var vel := Vector2.ZERO
var dmg := 1
var team := "player"
var life := 3.0
var grav := 0.0
var pierce := false
var ignore_world := false
var delay := 0.0
var launch_vel := Vector2.ZERO
var box := Vector2.ZERO
var radius := 5.0
var _t := 0.0
var _hit: Dictionary = {}
var _ended := false

func setup(k: String, v: Vector2, d: int, tm: String) -> void:
    kind = k
    vel = v
    dmg = d
    team = tm
    match k:
        "bolt":
            life = 1.6
            radius = 5.0
        "arrow":
            life = 2.5
            box = Vector2(10, 4)
        "orb":
            life = 4.0
            radius = 5.0
        "rock":
            life = 3.0
            radius = 6.0
            grav = 600.0
        "wave":
            life = 3.0
            box = Vector2(14, 20)
            ignore_world = true
        "column":
            life = 0.55
            box = Vector2(18, 150)
            ignore_world = true
        "warn":
            life = 0.6

func _ready() -> void:
    if kind == "warn":
        monitoring = false
        monitorable = false
        return
    collision_layer = 8 if team == "player" else 16
    collision_mask = 5 if team == "player" else 3
    var cs := CollisionShape2D.new()
    if box != Vector2.ZERO:
        var rs := RectangleShape2D.new()
        rs.size = box
        cs.shape = rs
        if kind == "wave":
            cs.position = Vector2(0, -10)
        elif kind == "column":
            cs.position = Vector2(0, -75)
    else:
        var cc := CircleShape2D.new()
        cc.radius = radius
        cs.shape = cc
    add_child(cs)
    match kind:
        "bolt":
            var a := AnimatedSprite2D.new()
            a.sprite_frames = Sprites.atlas_frames("bolt", 3, 14.0, true)
            a.flip_h = vel.x < 0.0
            add_child(a)
            a.play("bolt")
            add_child(Game.world.make_light(Color(0.5, 0.85, 1.0), 1.0, 0.8))
        "arrow", "orb", "rock":
            var s := Sprite2D.new()
            s.texture = Sprites.tex("orb" if kind == "orb" else kind)
            add_child(s)
            if kind == "orb":
                add_child(Game.world.make_light(Color(0.9, 0.4, 1.0), 0.8, 0.7))
        _:
            pass
    body_entered.connect(_on_body)
    queue_redraw()

func _draw() -> void:
    if kind == "wave":
        draw_colored_polygon(PackedVector2Array([Vector2(-7, 0), Vector2(0, -20), Vector2(7, 0)]), Color(0.7, 0.3, 1.0, 0.85))
        draw_colored_polygon(PackedVector2Array([Vector2(-3, 0), Vector2(0, -12), Vector2(3, 0)]), Color(1, 0.9, 1, 0.9))
    elif kind == "column":
        draw_rect(Rect2(-9, -150, 18, 150), Color(0.7, 0.3, 1.0, 0.75))
        draw_rect(Rect2(-4, -150, 8, 150), Color(1, 0.9, 1, 0.9))
    elif kind == "warn":
        draw_rect(Rect2(-9, -150, 18, 150), Color(1.0, 0.2, 0.2, 0.18))
        draw_line(Vector2(-9, 0), Vector2(9, 0), Color(1.0, 0.3, 0.3, 0.9), 2.0)

func _physics_process(delta: float) -> void:
    _t += delta
    life -= delta
    if life <= 0.0:
        queue_free()
        return
    if kind == "warn":
        return
    if delay > 0.0:
        delay -= delta
        if delay <= 0.0:
            vel = launch_vel
        return
    vel.y += grav * delta
    position += vel * delta
    if kind == "arrow":
        rotation = vel.angle()
    elif kind == "rock":
        rotation += delta * 6.0
    if team == "enemy" and (kind == "wave" or kind == "column"):
        for b in get_overlapping_bodies():
            if b.is_in_group("player"):
                b.take_damage(dmg, global_position.x)

func _on_body(b: Node) -> void:
    if _ended:
        return
    if team == "player":
        if b.is_in_group("enemy"):
            var iid := b.get_instance_id()
            if _hit.has(iid):
                return
            _hit[iid] = true
            b.take_hit(dmg, global_position, 100.0)
            Audio.play("magic_hit")
            Game.world.spark(global_position, Color(0.5, 0.9, 1.0))
            if not pierce:
                _end()
        elif b.is_in_group("crack"):
            b.hit()
            _end()
        else:
            Game.world.spark(global_position, Color(0.5, 0.9, 1.0))
            _end()
    else:
        if b.is_in_group("player"):
            b.take_damage(dmg, global_position.x)
            if kind != "wave" and kind != "column":
                _end()
        elif not ignore_world:
            if kind == "rock":
                Game.world.spark(global_position, Color(0.7, 0.7, 0.7))
            _end()

func _end() -> void:
    _ended = true
    call_deferred("queue_free")
