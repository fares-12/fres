extends Control
## Multi-touch on-screen controls: LEFT, RIGHT, JUMP, ATTACK, MAGIC, INTERACT (contextual), PAUSE.
## Each finger is tracked by index; sliding between buttons re-targets; releasing stops input immediately.

var btns: Dictionary = {}
var touches: Dictionary = {}     # finger index -> button name
var held: Dictionary = {}
var edge: Dictionary = {}
var interact_visible := false
var interact_label := "USE"
var u := 1.0

func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    resized.connect(_layout)
    Game.settings_changed.connect(_layout)
    _layout()

func _layout() -> void:
    var w := size.x
    var h := size.y
    if h <= 0.0:
        return
    u = (h / 360.0) * float(Game.settings["btn_scale"])
    var m := 14.0 * u
    btns = {
        "left": {"c": Vector2(46 * u + m, h - 46 * u - m), "r": 38 * u},
        "right": {"c": Vector2(134 * u + m, h - 46 * u - m), "r": 38 * u},
        "jump": {"c": Vector2(w - 48 * u - m, h - 58 * u - m), "r": 40 * u},
        "attack": {"c": Vector2(w - 138 * u - m, h - 42 * u - m), "r": 36 * u},
        "magic": {"c": Vector2(w - 124 * u - m, h - 122 * u - m), "r": 30 * u},
        "interact": {"c": Vector2(w - 48 * u - m, h - 148 * u - m), "r": 30 * u},
        "pause": {"c": Vector2(w - 28 * u, 28 * u), "r": 20 * u},
    }
    queue_redraw()

func _button_at(p: Vector2) -> String:
    var best := ""
    var best_score := 9999.0
    for n in btns:
        if n == "interact" and not interact_visible:
            continue
        var b: Dictionary = btns[n]
        var d: float = p.distance_to(b["c"]) / float(b["r"])
        if d <= 1.25 and d < best_score:
            best = n
            best_score = d
    return best

func _rebuild_held() -> void:
    held.clear()
    for idx in touches:
        held[touches[idx]] = true
    queue_redraw()

func _input(e: InputEvent) -> void:
    if not is_visible_in_tree():
        return
    if e is InputEventScreenTouch:
        if e.pressed:
            var n := _button_at(e.position)
            if n != "":
                touches[e.index] = n
                edge[n] = true
                _rebuild_held()
        elif touches.has(e.index):
            touches.erase(e.index)
            _rebuild_held()
    elif e is InputEventScreenDrag:
        var n2 := _button_at(e.position)
        var old: String = touches.get(e.index, "")
        if n2 != old:
            if n2 == "":
                touches.erase(e.index)
            else:
                touches[e.index] = n2
                if n2 != "left" and n2 != "right":
                    edge[n2] = true
            _rebuild_held()

func is_down(n: String) -> bool:
    return held.has(n)

## Returns true once per press (edge) and consumes it.
func pressed(n: String) -> bool:
    if edge.has(n):
        edge.erase(n)
        return true
    return false

func set_interact(on: bool, text: String = "USE") -> void:
    if on != interact_visible or text != interact_label:
        interact_visible = on
        interact_label = text
        if not on:
            for idx in touches.keys():
                if touches[idx] == "interact":
                    touches.erase(idx)
            _rebuild_held()
        queue_redraw()

func clear_all() -> void:
    touches.clear()
    held.clear()
    edge.clear()
    queue_redraw()

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_PAUSED:
        clear_all()

func _draw() -> void:
    var a: float = float(Game.settings["btn_alpha"])
    for n in btns:
        if n == "interact" and not interact_visible:
            continue
        var b: Dictionary = btns[n]
        var c: Vector2 = b["c"]
        var r: float = b["r"]
        var down := held.has(n)
        var base := Color(0.1, 0.08, 0.2, a * (1.3 if down else 1.0))
        var ring := Color(0.8, 0.7, 1.0, minf(1.0, a + 0.3))
        match n:
            "attack":
                base = Color(0.35, 0.12, 0.12, a * (1.3 if down else 1.0))
                ring = Color(1.0, 0.6, 0.5, minf(1.0, a + 0.3))
            "magic":
                base = Color(0.08, 0.2, 0.4, a * (1.3 if down else 1.0))
                ring = Color(0.5, 0.9, 1.0, minf(1.0, a + 0.3))
            "interact":
                base = Color(0.3, 0.25, 0.05, a * (1.3 if down else 1.0))
                ring = Color(1.0, 0.9, 0.5, minf(1.0, a + 0.3))
        draw_circle(c, r, base)
        draw_arc(c, r, 0.0, TAU, 40, ring, 2.0 * u)
        var ic := Color(1, 1, 1, minf(1.0, a + 0.35))
        match n:
            "left":
                draw_colored_polygon(PackedVector2Array([c + Vector2(-16, 0) * u, c + Vector2(8, -16) * u, c + Vector2(8, 16) * u]), ic)
            "right":
                draw_colored_polygon(PackedVector2Array([c + Vector2(16, 0) * u, c + Vector2(-8, -16) * u, c + Vector2(-8, 16) * u]), ic)
            "jump":
                draw_colored_polygon(PackedVector2Array([c + Vector2(0, -18) * u, c + Vector2(-16, 6) * u, c + Vector2(16, 6) * u]), ic)
                draw_rect(Rect2(c + Vector2(-6, 6) * u, Vector2(12, 12) * u), ic)
            "attack":
                draw_line(c + Vector2(-14, 14) * u, c + Vector2(14, -14) * u, ic, 4.0 * u)
                draw_line(c + Vector2(-14, 2) * u, c + Vector2(-2, 14) * u, ic, 3.0 * u)
            "magic":
                var pts := PackedVector2Array()
                for i in 10:
                    var ang := -PI / 2.0 + float(i) * TAU / 10.0
                    var rr := 15.0 * u if i % 2 == 0 else 6.0 * u
                    pts.append(c + Vector2(cos(ang), sin(ang)) * rr)
                draw_colored_polygon(pts, ic)
            "interact":
                var f := ThemeDB.fallback_font
                draw_string(f, c + Vector2(-r * 0.8, 5.0 * u), interact_label, HORIZONTAL_ALIGNMENT_CENTER, r * 1.6, int(13 * u), ic)
            "pause":
                draw_rect(Rect2(c + Vector2(-6, -8) * u, Vector2(4, 16) * u), ic)
                draw_rect(Rect2(c + Vector2(2, -8) * u, Vector2(4, 16) * u), ic)
