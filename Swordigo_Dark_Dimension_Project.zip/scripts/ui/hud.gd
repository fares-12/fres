extends Control
## In-game HUD: hearts, mana, shards, key, abilities, boss bar, toasts, title cards, damage flash.

var toast_text := ""
var toast_t := 0.0
var boss_name := ""
var boss_ratio := 1.0
var flash := 0.0
var title_text := ""
var title_sub := ""
var title_t := 0.0
const MARGIN := 22.0

func _ready() -> void:
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_IGNORE

func toast(t: String) -> void:
    toast_text = t
    toast_t = 2.6

func show_title(t: String, sub: String, dur: float = 3.2) -> void:
    title_text = t
    title_sub = sub
    title_t = dur

func _process(delta: float) -> void:
    toast_t = maxf(0.0, toast_t - delta)
    title_t = maxf(0.0, title_t - delta)
    flash = maxf(0.0, flash - delta * 2.5)
    queue_redraw()

func _draw() -> void:
    if Game.st.is_empty():
        return
    var f := ThemeDB.fallback_font
    var x0 := MARGIN
    var y0 := 12.0
    var heart := Sprites.tex("icon_heart")
    for i in Game.max_hp:
        var col := Color(1, 1, 1, 1) if i < Game.hp else Color(0.15, 0.1, 0.15, 0.8)
        draw_texture(heart, Vector2(x0 + i * 17.0, y0), col)
    var mana_t := Sprites.tex("icon_mana")
    for i in Game.max_mana:
        var col2 := Color(1, 1, 1, 1) if float(i) + 1.0 <= Game.mana else (Color(1, 1, 1, 0.5) if float(i) < Game.mana else Color(0.1, 0.12, 0.2, 0.8))
        draw_texture(mana_t, Vector2(x0 + i * 17.0, y0 + 18.0), col2)
    draw_texture(Sprites.tex("icon_coin"), Vector2(x0, y0 + 38.0))
    draw_string(f, Vector2(x0 + 18.0, y0 + 51.0), str(Game.coins), HORIZONTAL_ALIGNMENT_LEFT, -1, 14, Color(1, 0.9, 0.5))
    var ix := x0 + 70.0
    if Game.has_key(int(Game.st["zone"])):
        draw_texture(Sprites.tex("icon_key"), Vector2(ix, y0 + 38.0))
        ix += 20.0
    if Game.has_ability("double_jump"):
        draw_texture(Sprites.tex("sigil_double_jump"), Vector2(ix, y0 + 38.0))
        ix += 20.0
    if Game.has_ability("ember"):
        draw_texture(Sprites.tex("sigil_ember"), Vector2(ix, y0 + 38.0))
    var w := size.x
    if toast_t > 0.0:
        var a := minf(1.0, toast_t)
        var tw := f.get_string_size(toast_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15).x
        var r := Rect2((w - tw) * 0.5 - 10.0, 56.0, tw + 20.0, 24.0)
        draw_rect(r, Color(0.05, 0.03, 0.12, 0.8 * a))
        draw_string(f, Vector2(r.position.x + 10.0, r.position.y + 17.0), toast_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(1, 1, 1, a))
    if boss_name != "":
        var bw := 260.0
        var bx := (w - bw) * 0.5
        draw_rect(Rect2(bx - 2.0, 14.0, bw + 4.0, 14.0), Color(0.05, 0.0, 0.1, 0.85))
        draw_rect(Rect2(bx, 16.0, bw * clampf(boss_ratio, 0.0, 1.0), 10.0), Color(0.8, 0.15, 0.35, 1.0))
        var nw := f.get_string_size(boss_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 13).x
        draw_string(f, Vector2((w - nw) * 0.5, 40.0), boss_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 13, Color(1, 0.85, 0.9))
    if title_t > 0.0:
        var ta := minf(1.0, title_t) * minf(1.0, (3.2 - title_t) * 2.0 + 0.2)
        ta = clampf(ta, 0.0, 1.0)
        var t1 := f.get_string_size(title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 34).x
        draw_string(f, Vector2((w - t1) * 0.5 + 2.0, 122.0), title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 34, Color(0, 0, 0, ta * 0.7))
        draw_string(f, Vector2((w - t1) * 0.5, 120.0), title_text, HORIZONTAL_ALIGNMENT_LEFT, -1, 34, Color(0.95, 0.9, 1.0, ta))
        var t2 := f.get_string_size(title_sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 16).x
        draw_string(f, Vector2((w - t2) * 0.5, 146.0), title_sub, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(0.8, 0.7, 1.0, ta))
    if flash > 0.0:
        draw_rect(Rect2(Vector2.ZERO, size), Color(1.0, 0.0, 0.05, flash * 0.3))
