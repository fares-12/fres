extends CanvasLayer
## Three-layer parallax background drawn in screen space.

const FACTORS := [0.03, 0.15, 0.35]
var zone := 1
var scroll_x := 0.0
var _layers: Array = []
var _canvas: Control

func _init() -> void:
    layer = -10

func _ready() -> void:
    _canvas = Control.new()
    _canvas.set_anchors_preset(Control.PRESET_FULL_RECT)
    _canvas.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(_canvas)
    _canvas.draw.connect(_on_draw)
    _canvas.resized.connect(_canvas.queue_redraw)
    set_zone(zone)

func set_zone(z: int) -> void:
    zone = z
    _layers.clear()
    for i in 3:
        _layers.append(load("res://assets/backgrounds/bg_z%d_%d.png" % [z, i]))
    if _canvas != null:
        _canvas.queue_redraw()

func set_scroll(x: float) -> void:
    if absf(x - scroll_x) < 0.01:
        return
    scroll_x = x
    if _canvas != null:
        _canvas.queue_redraw()

func _on_draw() -> void:
    var sz: Vector2 = _canvas.size
    if sz.y <= 0.0:
        return
    for i in _layers.size():
        var t: Texture2D = _layers[i]
        if t == null:
            continue
        var sc: float = sz.y / float(t.get_height())
        var tw: float = float(t.get_width()) * sc
        var x: float = -fposmod(scroll_x * FACTORS[i] * sc, tw)
        while x < sz.x:
            _canvas.draw_texture_rect(t, Rect2(floorf(x), 0.0, ceilf(tw) + 1.0, sz.y), false)
            x += tw
