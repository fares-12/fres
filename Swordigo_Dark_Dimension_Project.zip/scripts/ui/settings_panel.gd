extends Control
## Settings: volumes (separate music / sfx buses), touch button size and opacity, reset.

signal closed
const UI = preload("res://scripts/ui/ui_util.gd")
const ROWS := [["Master volume", "master", 0.0, 1.0], ["Music volume", "music", 0.0, 1.0], ["Sound effects", "sfx", 0.0, 1.0],
    ["Touch button size", "btn_scale", 0.7, 1.5], ["Touch button opacity", "btn_alpha", 0.2, 1.0]]
var sliders: Dictionary = {}

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := UI.panel(Vector2(440, 0))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    panel.add_child(box)
    box.add_child(UI.label("SETTINGS", 24, Color(0.85, 0.75, 1.0)))
    for row in ROWS:
        var h := HBoxContainer.new()
        h.add_theme_constant_override("separation", 12)
        var l := UI.label(row[0], 16, Color(1, 1, 1), 0)
        l.custom_minimum_size = Vector2(170, 0)
        h.add_child(l)
        var s := HSlider.new()
        s.min_value = row[2]
        s.max_value = row[3]
        s.step = 0.05
        s.custom_minimum_size = Vector2(220, 30)
        s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
        s.value = float(Game.settings[row[1]])
        s.value_changed.connect(_on_changed.bind(row[1]))
        h.add_child(s)
        sliders[row[1]] = s
        box.add_child(h)
    var btns := HBoxContainer.new()
    btns.alignment = BoxContainer.ALIGNMENT_CENTER
    btns.add_theme_constant_override("separation", 12)
    var reset := UI.button("Reset", 18, Vector2(140, 42))
    reset.pressed.connect(_on_reset)
    var back := UI.button("Back", 18, Vector2(140, 42))
    back.pressed.connect(_on_back)
    btns.add_child(reset)
    btns.add_child(back)
    box.add_child(btns)

func _on_changed(v: float, key: String) -> void:
    Game.settings[key] = v
    Audio.apply_volume()
    Game.settings_changed.emit()

func _on_reset() -> void:
    Game.reset_settings()
    for k in sliders:
        sliders[k].set_value_no_signal(float(Game.settings[k]))
    Audio.apply_volume()

func _on_back() -> void:
    Game.save_settings()
    closed.emit()
    queue_free()
