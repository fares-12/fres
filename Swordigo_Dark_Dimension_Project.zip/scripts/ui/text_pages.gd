extends Control
## Full-screen text pages (intro, ending). Tap anywhere to continue.

var pages: Array = []
var idx := 0
var on_done: Callable
var label: Label
var hint: Label
var _last_tap := 0

func start(p: Array, cb: Callable) -> void:
    pages = p
    on_done = cb
    idx = 0
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP
    var bg := ColorRect.new()
    bg.color = Color(0.01, 0.0, 0.03, 0.95)
    bg.set_anchors_preset(Control.PRESET_FULL_RECT)
    bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(bg)
    label = Label.new()
    label.set_anchors_preset(Control.PRESET_FULL_RECT)
    label.offset_left = 70
    label.offset_right = -70
    label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
    label.add_theme_font_size_override("font_size", 22)
    label.add_theme_color_override("font_color", Color(0.9, 0.86, 1.0))
    label.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(label)
    hint = Label.new()
    hint.text = "tap to continue"
    hint.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    hint.offset_top = -40
    hint.offset_bottom = -12
    hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    hint.add_theme_font_size_override("font_size", 14)
    hint.add_theme_color_override("font_color", Color(0.6, 0.55, 0.8))
    hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hint)
    _last_tap = Time.get_ticks_msec()
    _show_page()

func _show_page() -> void:
    label.text = str(pages[idx])
    label.modulate.a = 0.0
    create_tween().tween_property(label, "modulate:a", 1.0, 0.6)

func _input(e: InputEvent) -> void:
    var tap := false
    if e is InputEventScreenTouch and e.pressed:
        tap = true
    elif e is InputEventMouseButton and e.pressed:
        tap = true
    elif e is InputEventKey and e.pressed and not e.echo:
        tap = true
    if not tap:
        return
    var now := Time.get_ticks_msec()
    if now - _last_tap < 350:
        return
    _last_tap = now
    get_viewport().set_input_as_handled()
    idx += 1
    if idx >= pages.size():
        on_done.call()
    else:
        _show_page()
