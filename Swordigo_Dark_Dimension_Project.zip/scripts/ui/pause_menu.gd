extends Control
## Pause menu: Resume / Settings / Quit to menu.

signal resume
signal settings
signal quit
const UI = preload("res://scripts/ui/ui_util.gd")

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    set_anchors_preset(Control.PRESET_FULL_RECT)
    mouse_filter = Control.MOUSE_FILTER_STOP
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.65)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    add_child(center)
    var panel := UI.panel(Vector2(320, 0))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    panel.add_child(box)
    box.add_child(UI.label("PAUSED", 26, Color(0.85, 0.75, 1.0)))
    var b1 := UI.button("Resume")
    b1.pressed.connect(func(): resume.emit())
    box.add_child(b1)
    var b2 := UI.button("Settings")
    b2.pressed.connect(func(): settings.emit())
    box.add_child(b2)
    var b3 := UI.button("Save & Quit to Menu")
    b3.pressed.connect(func(): quit.emit())
    box.add_child(b3)
