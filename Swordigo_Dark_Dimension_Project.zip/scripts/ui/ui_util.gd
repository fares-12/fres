extends RefCounted
## Small helpers to build touch-friendly UI from code.

static func box(bg: Color, border: Color, radius: int = 6, border_w: int = 2) -> StyleBoxFlat:
    var sb := StyleBoxFlat.new()
    sb.bg_color = bg
    sb.border_color = border
    sb.set_border_width_all(border_w)
    sb.set_corner_radius_all(radius)
    sb.content_margin_left = 12
    sb.content_margin_right = 12
    sb.content_margin_top = 8
    sb.content_margin_bottom = 8
    return sb

static func button(text: String, font_size: int = 20, min_size: Vector2 = Vector2(240, 46)) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = min_size
    b.focus_mode = Control.FOCUS_NONE
    b.add_theme_font_size_override("font_size", font_size)
    b.add_theme_stylebox_override("normal", box(Color(0.12, 0.08, 0.22, 0.92), Color(0.55, 0.4, 0.85)))
    b.add_theme_stylebox_override("hover", box(Color(0.2, 0.12, 0.36, 0.95), Color(0.8, 0.6, 1.0)))
    b.add_theme_stylebox_override("pressed", box(Color(0.32, 0.2, 0.55, 1.0), Color(1.0, 0.9, 1.0)))
    b.add_theme_stylebox_override("disabled", box(Color(0.1, 0.1, 0.12, 0.7), Color(0.3, 0.3, 0.35)))
    b.add_theme_color_override("font_color", Color(0.95, 0.92, 1.0))
    b.add_theme_color_override("font_disabled_color", Color(0.5, 0.5, 0.55))
    b.pressed.connect(func(): Audio.play("click"))
    return b

static func label(text: String, size: int = 18, color: Color = Color(1, 1, 1), align: int = 1) -> Label:
    var l := Label.new()
    l.text = text
    l.horizontal_alignment = align as HorizontalAlignment
    l.add_theme_font_size_override("font_size", size)
    l.add_theme_color_override("font_color", color)
    l.add_theme_color_override("font_outline_color", Color(0.02, 0.0, 0.06, 1))
    l.add_theme_constant_override("outline_size", 4)
    l.mouse_filter = Control.MOUSE_FILTER_IGNORE
    return l

static func panel(min_size: Vector2 = Vector2(0, 0)) -> PanelContainer:
    var p := PanelContainer.new()
    p.custom_minimum_size = min_size
    p.add_theme_stylebox_override("panel", box(Color(0.06, 0.04, 0.12, 0.96), Color(0.5, 0.38, 0.8), 8, 2))
    return p
