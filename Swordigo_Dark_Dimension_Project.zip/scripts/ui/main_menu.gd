extends Node
## Main menu: New Game / Continue / Settings / Credits / Exit.

const UI = preload("res://scripts/ui/ui_util.gd")
const Background = preload("res://scripts/ui/background.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const TextPages = preload("res://scripts/ui/text_pages.gd")

var layer: CanvasLayer
var root: Control
var menu_box: VBoxContainer
var continue_btn: Button
var msg_label: Label
var bg
var overlay: Control = null
var _scroll := 0.0

func _ready() -> void:
    get_tree().paused = false
    bg = Background.new()
    add_child(bg)
    bg.set_zone(1)
    layer = CanvasLayer.new()
    add_child(layer)
    root = Control.new()
    root.set_anchors_preset(Control.PRESET_FULL_RECT)
    layer.add_child(root)
    var title := UI.label("SWORDIGO", 54, Color(0.95, 0.88, 1.0))
    title.set_anchors_preset(Control.PRESET_TOP_WIDE)
    title.offset_top = 14
    root.add_child(title)
    var sub := UI.label("D A R K   D I M E N S I O N", 22, Color(0.75, 0.5, 1.0))
    sub.set_anchors_preset(Control.PRESET_TOP_WIDE)
    sub.offset_top = 78
    root.add_child(sub)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    center.offset_top = 90
    root.add_child(center)
    menu_box = VBoxContainer.new()
    menu_box.add_theme_constant_override("separation", 8)
    center.add_child(menu_box)
    var b_new := UI.button("New Game")
    b_new.pressed.connect(_on_new)
    menu_box.add_child(b_new)
    continue_btn = UI.button("Continue")
    continue_btn.pressed.connect(_on_continue)
    menu_box.add_child(continue_btn)
    var b_set := UI.button("Settings")
    b_set.pressed.connect(_on_settings)
    menu_box.add_child(b_set)
    var b_cred := UI.button("Credits")
    b_cred.pressed.connect(_on_credits)
    menu_box.add_child(b_cred)
    var b_exit := UI.button("Exit")
    b_exit.pressed.connect(func(): get_tree().quit())
    menu_box.add_child(b_exit)
    msg_label = UI.label("", 14, Color(1.0, 0.7, 0.7))
    msg_label.set_anchors_preset(Control.PRESET_BOTTOM_WIDE)
    msg_label.offset_top = -36
    msg_label.offset_bottom = -6
    msg_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    root.add_child(msg_label)
    _refresh()
    Audio.play_zone_music("menu")

func _refresh() -> void:
    var has := Game.peek_save()
    continue_btn.disabled = not has
    msg_label.text = Game.load_message

func _process(delta: float) -> void:
    _scroll += delta * 14.0
    bg.set_scroll(_scroll)

func _close_overlay() -> void:
    if overlay != null and is_instance_valid(overlay):
        overlay.queue_free()
    overlay = null
    root.visible = true
    _refresh()

func _on_new() -> void:
    if Game.peek_save():
        _confirm_new()
    else:
        _start_new()

func _confirm_new() -> void:
    root.visible = false
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    layer.add_child(c)
    overlay = c
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(center)
    var panel := UI.panel(Vector2(440, 0))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 14)
    panel.add_child(box)
    var l := UI.label("Start a new game?\nYour saved progress will be replaced.", 20)
    box.add_child(l)
    var row := HBoxContainer.new()
    row.alignment = BoxContainer.ALIGNMENT_CENTER
    row.add_theme_constant_override("separation", 14)
    var yes := UI.button("Yes, new game", 18, Vector2(180, 44))
    yes.pressed.connect(_start_new)
    var no := UI.button("Cancel", 18, Vector2(140, 44))
    no.pressed.connect(_close_overlay)
    row.add_child(yes)
    row.add_child(no)
    box.add_child(row)

func _start_new() -> void:
    _close_overlay()
    root.visible = false
    Game.new_game()
    var tp := TextPages.new()
    layer.add_child(tp)
    overlay = tp
    tp.start(Game.lore["intro"], func(): Game.go_zone(1, "start"))

func _on_continue() -> void:
    if not Game.continue_game():
        msg_label.text = Game.load_message if Game.load_message != "" else "No saved game found."
        _refresh()

func _on_settings() -> void:
    root.visible = false
    var sp := SettingsPanel.new()
    layer.add_child(sp)
    overlay = sp
    sp.closed.connect(func():
        overlay = null
        root.visible = true)

func _on_credits() -> void:
    root.visible = false
    var c := Control.new()
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    layer.add_child(c)
    overlay = c
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.75)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    c.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(center)
    var panel := UI.panel(Vector2(460, 0))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    panel.add_child(box)
    box.add_child(UI.label(str(Game.lore.get("credits", "")), 16))
    var back := UI.button("Back", 18, Vector2(160, 42))
    back.pressed.connect(_close_overlay)
    var hb := HBoxContainer.new()
    hb.alignment = BoxContainer.ALIGNMENT_CENTER
    hb.add_child(back)
    box.add_child(hb)

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if overlay != null and is_instance_valid(overlay) and overlay is Control and not (overlay is TextPages):
            if overlay.has_method("_on_back"):
                overlay._on_back()
            else:
                _close_overlay()
        elif overlay == null:
            get_tree().quit()
