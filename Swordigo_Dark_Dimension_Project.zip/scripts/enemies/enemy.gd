extends CharacterBody2D
## Regular enemies: "husk" (melee walker), "archer" (ranged), "bat" (erratic flyer).
## States: IDLE, PATROL, CHASE, ATTACK, HURT, DEAD.

const Projectile = preload("res://scripts/combat/projectile.gd")
enum S { IDLE, PATROL, CHASE, ATTACK, HURT, DEAD }

var kind := "husk"
var zone_cfg: Dictionary = {}
var hp := 5.0
var speed := 38.0
var state := S.PATROL
var dir := 1
var st_t := 0.0
var attack_cd := 0.5
var home := Vector2.ZERO
var dmg := 1
var sprite: AnimatedSprite2D
var contact: Area2D
var tint := Color(1, 1, 1)
var _flash := 0.0
var _hit_done := false
var _lose_t := 0.0
var _phase := 0.0
var _shot_done := false

func _ready() -> void:
    add_to_group("enemy")
    collision_layer = 4
    collision_mask = 1
    home = position
    _phase = randf() * 6.0
    dir = 1 if randf() < 0.5 else -1
    var mult := float(zone_cfg.get("hp_mult", 1.0))
    dmg = int(zone_cfg.get("dmg", 1))
    tint = Color(str(zone_cfg.get("enemy_tint", "#ffffff")))
    var cs := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    var csz := Vector2(12, 26)
    var cpos := Vector2(0, -13)
    var sheet := "husk"
    match kind:
        "husk":
            hp = 5.0 * mult
            speed = 38.0
            sheet = "husk"
        "archer":
            hp = 3.0 * mult
            speed = 30.0
            sheet = "archer"
        "bat":
            hp = 2.0 * mult
            speed = 60.0
            sheet = "bat"
            csz = Vector2(12, 10)
            cpos = Vector2(0, 0)
            motion_mode = CharacterBody2D.MOTION_MODE_FLOATING
    rs.size = csz
    cs.shape = rs
    cs.position = cpos
    add_child(cs)
    sprite = AnimatedSprite2D.new()
    sprite.sprite_frames = Sprites.frames(sheet)
    sprite.position = Vector2(0, -15) if kind != "bat" else Vector2(0, 0)
    sprite.modulate = tint
    add_child(sprite)
    sprite.play("fly" if kind == "bat" else "idle")
    contact = Area2D.new()
    contact.collision_layer = 0
    contact.collision_mask = 2
    var cc := CollisionShape2D.new()
    var cr := RectangleShape2D.new()
    cr.size = csz + Vector2(4, 2)
    cc.shape = cr
    cc.position = cpos
    contact.add_child(cc)
    add_child(contact)

func _player():
    var p = Game.world.player
    if p == null or not is_instance_valid(p) or p.dead:
        return null
    return p

func _physics_process(delta: float) -> void:
    if state == S.DEAD:
        return
    st_t += delta
    attack_cd = maxf(0.0, attack_cd - delta)
    _flash = maxf(0.0, _flash - delta)
    sprite.modulate = Color(3, 3, 3) if _flash > 0.0 else tint
    match kind:
        "husk":
            _husk(delta)
        "archer":
            _archer(delta)
        "bat":
            _bat(delta)
    if state != S.HURT:
        for b in contact.get_overlapping_bodies():
            if b.is_in_group("player"):
                b.take_damage(dmg, global_position.x)
    sprite.flip_h = dir < 0

func _floor_ahead(d: int) -> bool:
    return Game.world.is_solid_px(global_position + Vector2(d * 10.0, 4.0))

func _set_state(s: S) -> void:
    state = s
    st_t = 0.0
    _hit_done = false
    _shot_done = false

func _play(a: String) -> void:
    if sprite.animation != a:
        sprite.play(a)

func _gravity_move(delta: float) -> void:
    velocity.y = minf(velocity.y + 900.0 * delta, 420.0)
    move_and_slide()

# ---------------------------------------------------------------- husk
func _husk(delta: float) -> void:
    var p = _player()
    var dx := 9999.0
    var dy := 9999.0
    if p != null:
        dx = p.global_position.x - global_position.x
        dy = p.global_position.y - global_position.y
    var near: bool = absf(dx) < 130.0 and absf(dy) < 50.0
    match state:
        S.IDLE:
            velocity.x = 0.0
            _play("idle")
            if st_t > 0.6:
                dir = -dir
                _set_state(S.PATROL)
            elif near:
                _set_state(S.CHASE)
        S.PATROL:
            _play("walk")
            velocity.x = dir * speed
            if is_on_wall() or not _floor_ahead(dir):
                velocity.x = 0.0
                _set_state(S.IDLE)
            if near:
                _set_state(S.CHASE)
        S.CHASE:
            _play("walk")
            if absf(dx) > 4.0:
                dir = 1 if dx > 0.0 else -1
            velocity.x = dir * speed * 1.7
            if not _floor_ahead(dir) or is_on_wall():
                velocity.x = 0.0
            if not near:
                _lose_t += delta
                if _lose_t > 1.5:
                    _lose_t = 0.0
                    _set_state(S.PATROL)
            else:
                _lose_t = 0.0
            if absf(dx) < 24.0 and absf(dy) < 30.0 and attack_cd <= 0.0:
                _set_state(S.ATTACK)
        S.ATTACK:
            if st_t < 0.4:
                velocity.x = 0.0
                if sprite.animation != "attack":
                    sprite.play("attack")
                    sprite.frame = 0
            elif st_t < 0.6:
                velocity.x = dir * 110.0
                if not _hit_done and p != null and absf(dx) < 30.0 and absf(dy) < 30.0:
                    _hit_done = true
                    p.take_damage(dmg, global_position.x)
            else:
                velocity.x = 0.0
            if st_t > 0.75:
                attack_cd = 1.0
                _set_state(S.CHASE)
        S.HURT:
            velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
            if st_t > 0.25:
                _set_state(S.CHASE)
    _gravity_move(delta)

# ---------------------------------------------------------------- archer
func _archer(delta: float) -> void:
    var p = _player()
    var dx := 9999.0
    var dy := 9999.0
    if p != null:
        dx = p.global_position.x - global_position.x
        dy = p.global_position.y - global_position.y
    var in_range: bool = absf(dx) < 210.0 and absf(dy) < 80.0
    match state:
        S.IDLE, S.PATROL:
            _play("idle")
            velocity.x = 0.0
            if in_range:
                _set_state(S.CHASE)
        S.CHASE:
            if absf(dx) > 4.0:
                dir = 1 if dx > 0.0 else -1
            _play("idle")
            velocity.x = 0.0
            if absf(dx) < 70.0 and _floor_ahead(-dir) and not is_on_wall():
                velocity.x = -dir * speed * 1.5
            if not in_range:
                _set_state(S.IDLE)
            elif attack_cd <= 0.0:
                _set_state(S.ATTACK)
        S.ATTACK:
            velocity.x = 0.0
            if st_t < 0.55:
                _play("aim")
            else:
                _play("shoot")
                if not _shot_done and p != null:
                    _shot_done = true
                    var muzzle := global_position + Vector2(dir * 12.0, -15.0)
                    var aim: Vector2 = (p.global_position + Vector2(0, -12) - muzzle).normalized()
                    var pr := Projectile.new()
                    pr.setup("arrow", aim * 170.0, dmg, "enemy")
                    pr.position = muzzle
                    get_parent().add_child(pr)
                    Audio.play_at("shot", muzzle, 0.8)
            if st_t > 0.8:
                attack_cd = 1.8
                _set_state(S.CHASE)
        S.HURT:
            velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
            if st_t > 0.25:
                _set_state(S.CHASE)
    _gravity_move(delta)

# ---------------------------------------------------------------- bat
func _bat(delta: float) -> void:
    var p = _player()
    var to_p := Vector2(9999, 9999)
    if p != null:
        to_p = (p.global_position + Vector2(0, -12)) - global_position
    _phase += delta
    match state:
        S.IDLE:
            # retreat after a strike
            var away := -to_p.normalized() if p != null else Vector2.UP
            velocity = (away + Vector2(0, -0.6)).normalized() * 80.0
            if st_t > 0.7:
                _set_state(S.CHASE)
        S.PATROL:
            var target := home + Vector2(sin(_phase * 1.3) * 44.0, cos(_phase * 2.1) * 14.0)
            velocity = (target - global_position).limit_length(60.0)
            if to_p.length() < 150.0:
                _set_state(S.CHASE)
        S.CHASE:
            var wob := Vector2(-to_p.y, to_p.x).normalized() * sin(_phase * 9.0) * 45.0
            velocity = to_p.normalized() * 105.0 + wob
            if to_p.length() > 240.0 or st_t > 4.0:
                _set_state(S.PATROL)
            if p != null and p.invuln > 0.5:
                _set_state(S.IDLE)
        S.HURT:
            velocity = velocity.move_toward(Vector2.ZERO, 400.0 * delta)
            if st_t > 0.25:
                _set_state(S.CHASE)
    if absf(velocity.x) > 5.0:
        dir = 1 if velocity.x > 0.0 else -1
    move_and_slide()

# ---------------------------------------------------------------- damage
func take_hit(amount: float, from_pos: Vector2, knock: float = 120.0) -> void:
    if state == S.DEAD:
        return
    hp -= amount
    _flash = 0.12
    Audio.play_at("hit", global_position)
    Game.world.spark(global_position + Vector2(0, -12), Color(1, 0.9, 0.6))
    var d := signf(global_position.x - from_pos.x)
    if d == 0.0:
        d = 1.0
    velocity.x = d * knock
    if kind == "bat":
        velocity.y = -40.0
    if hp <= 0.0:
        _die()
    else:
        _set_state(S.HURT)
        if sprite.sprite_frames.has_animation("hurt"):
            sprite.play("hurt")

func _die() -> void:
    state = S.DEAD
    set_physics_process(false)
    Audio.play_at("enemy_die", global_position)
    sprite.modulate = tint
    sprite.play("dead")
    collision_layer = 0
    contact.set_deferred("monitoring", false)
    Game.world.spark(global_position + Vector2(0, -10), Color(0.9, 0.7, 1.0), 16)
    Game.world.spawn_drop(global_position + Vector2(0, -8))
    var tw := create_tween()
    tw.tween_interval(0.5)
    tw.tween_property(sprite, "modulate:a", 0.0, 0.4)
    tw.tween_callback(queue_free)
