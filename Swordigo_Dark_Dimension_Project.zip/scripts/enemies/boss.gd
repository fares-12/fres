extends CharacterBody2D
## Bosses with scripted attack patterns, telegraphs, vulnerability windows and phases.
## colossus (ground slam / rock rain / charge), weaver (blink + fan / shards / sweep), regent (dash / columns / pulse / summon).

const Projectile = preload("res://scripts/combat/projectile.gd")
signal defeated

var boss_id := "colossus"
var zone_cfg: Dictionary = {}
var arena_left := 0.0
var arena_right := 0.0
var floor_y := 0.0
var hp := 40.0
var max_hp := 40.0
var active := false
var dead := false
var vulnerable := false
var vuln_t := 0.0
var phase := 1
var pt := 0.0
var pat_end := 2.0
var queue: Array = []
var last_pat := ""
var charging := false
var charge_dir := 1
var charge_t := 0.0
var charge_speed := 230.0
var slam_air := false
var sweeping := false
var sweep_dir := 1
var shoot_t := 0.0
var hover_y := 0.0
var dir := -1
var dmg := 1
var sprite: AnimatedSprite2D
var contact: Area2D
var _flash := 0.0
var _tele_t := 0.0
var _clock := 0.0

func _ready() -> void:
    add_to_group("enemy")
    add_to_group("boss")
    collision_layer = 4
    collision_mask = 1
    dmg = int(zone_cfg.get("dmg", 1))
    var csz := Vector2(34, 54)
    match boss_id:
        "colossus":
            max_hp = 36.0
            csz = Vector2(38, 56)
        "weaver":
            max_hp = 48.0
            csz = Vector2(28, 44)
            hover_y = floor_y - 62.0
            position.y = hover_y
        "regent":
            max_hp = 70.0
            csz = Vector2(28, 56)
    hp = max_hp
    var cs := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    rs.size = csz
    cs.shape = rs
    cs.position = Vector2(0, -csz.y * 0.5)
    add_child(cs)
    sprite = AnimatedSprite2D.new()
    sprite.sprite_frames = Sprites.frames(boss_id)
    sprite.position = Vector2(0, -32)
    add_child(sprite)
    sprite.play("idle")
    contact = Area2D.new()
    contact.collision_layer = 0
    contact.collision_mask = 2
    var cc := CollisionShape2D.new()
    var cr := RectangleShape2D.new()
    cr.size = csz + Vector2(4, 2)
    cc.shape = cr
    cc.position = Vector2(0, -csz.y * 0.5)
    contact.add_child(cc)
    add_child(contact)

func activate() -> void:
    active = true
    _next_pattern()

# ------------------------------------------------------------------ scheduling
func _at(t: float, c: Callable) -> void:
    queue.append([t, c])

func _tele(dur: float) -> void:
    _tele_t = dur

func _player():
    var p = Game.world.player
    if p == null or not is_instance_valid(p) or p.dead:
        return null
    return p

func _px() -> float:
    var p = _player()
    return p.global_position.x if p != null else global_position.x

func _face_player() -> void:
    dir = 1 if _px() > global_position.x else -1

func _patterns() -> Array:
    match boss_id:
        "colossus":
            return ["slam", "rocks"] if phase == 1 else ["slam", "rocks", "charge", "charge"]
        "weaver":
            return ["blink", "shards"] if phase == 1 else ["blink", "shards", "sweep"]
        _:
            if phase == 1:
                return ["dash", "columns"]
            if phase == 2:
                return ["dash", "columns", "pulse"]
            return ["dash", "columns", "pulse", "summon"]

func _next_pattern() -> void:
    var opts: Array = _patterns().duplicate()
    if opts.size() > 1 and last_pat != "":
        opts.erase(last_pat)
    last_pat = str(opts[randi() % opts.size()])
    pt = 0.0
    queue.clear()
    vulnerable = false
    vuln_t = 0.0
    charging = false
    sweeping = false
    slam_air = false
    call("_pat_" + last_pat)

func _set_vulnerable(dur: float) -> void:
    vulnerable = true
    vuln_t = dur

func _shot(kind: String, from: Vector2, vel: Vector2, delay: float = 0.0) -> Node:
    var pr := Projectile.new()
    pr.setup(kind, Vector2.ZERO if delay > 0.0 else vel, dmg, "enemy")
    pr.position = from
    if delay > 0.0:
        pr.delay = delay
        pr.launch_vel = vel
    get_parent().add_child(pr)
    return pr

func _wave(d: int) -> void:
    var pr := Projectile.new()
    pr.setup("wave", Vector2(d * 130.0, 0.0), dmg, "enemy")
    pr.position = Vector2(global_position.x + d * 22.0, floor_y)
    get_parent().add_child(pr)

func _warn(x: float, life: float) -> void:
    var pr := Projectile.new()
    pr.setup("warn", Vector2.ZERO, 0, "enemy")
    pr.life = life
    pr.position = Vector2(x, floor_y)
    get_parent().add_child(pr)

# ------------------------------------------------------------------ colossus patterns
func _pat_slam() -> void:
    pat_end = 6.0
    _at(0.0, func():
        _face_player()
        _tele(0.5)
        sprite.play("attack"))
    _at(0.5, func():
        velocity = Vector2(signf(_px() - global_position.x) * 110.0, -380.0)
        slam_air = true
        Audio.play("boss_attack"))

func _pat_rocks() -> void:
    pat_end = 3.6
    _at(0.0, func():
        _tele(0.5)
        Audio.play("boss_attack"))
    for i in 6:
        _at(0.5 + i * 0.4, func():
            var x := clampf(_px() + randf_range(-60.0, 60.0), arena_left + 16.0, arena_right - 16.0)
            _warn(x, 0.55)
            _shot("rock", Vector2(x, floor_y - 170.0), Vector2(0.0, 40.0), 0.55))

func _pat_charge() -> void:
    pat_end = 8.0
    _at(0.0, func():
        _face_player()
        _tele(0.8)
        sprite.play("attack")
        Audio.play("boss_appear", 0.8))
    _at(0.8, func():
        charge_dir = 1 if _px() > global_position.x else -1
        dir = charge_dir
        charge_speed = 230.0
        charge_t = 2.5
        charging = true
        Audio.play("boss_attack"))

# ------------------------------------------------------------------ weaver patterns
func _pat_blink() -> void:
    pat_end = 3.0
    _at(0.0, func():
        _tele(0.4)
        create_tween().tween_property(sprite, "modulate:a", 0.1, 0.35))
    _at(0.4, func():
        position.x = randf_range(arena_left + 40.0, arena_right - 40.0)
        hover_y = floor_y - randf_range(56.0, 90.0)
        position.y = hover_y)
    _at(0.7, func():
        create_tween().tween_property(sprite, "modulate:a", 1.0, 0.2)
        _face_player())
    _at(0.9, func():
        Audio.play("boss_attack")
        var p = _player()
        var base := Vector2(dir, 0.3)
        if p != null:
            base = (p.global_position + Vector2(0, -12) - (global_position + Vector2(0, -30))).normalized()
        var n := 5 if phase == 1 else 7
        for k in n:
            var a := base.angle() + (float(k) - float(n - 1) * 0.5) * 0.26
            _shot("orb", global_position + Vector2(0, -30), Vector2(cos(a), sin(a)) * 125.0)
        _set_vulnerable(1.5))

func _pat_shards() -> void:
    pat_end = 3.4
    _at(0.0, func():
        _tele(0.4)
        sprite.play("attack"))
    var count := 3 if phase == 1 else 4
    for i in count:
        _at(0.3 + i * 0.25, func():
            var off := Vector2((float(i) - float(count - 1) * 0.5) * 40.0, -40.0 - randf() * 20.0)
            var p = _player()
            var target := global_position + Vector2(dir * 60.0, 0.0)
            if p != null:
                target = p.global_position + Vector2(0, -12)
            var from := global_position + off
            _shot("orb", from, (target - from).normalized() * 150.0, 0.8))
    _at(2.0, func(): _set_vulnerable(1.3))

func _pat_sweep() -> void:
    pat_end = 4.4
    _at(0.0, func():
        _tele(0.5)
        sweep_dir = 1 if global_position.x < (arena_left + arena_right) * 0.5 else -1)
    _at(0.5, func():
        sweeping = true
        shoot_t = 0.0)
    _at(3.6, func():
        sweeping = false
        _set_vulnerable(1.0))

# ------------------------------------------------------------------ regent patterns
func _pat_dash() -> void:
    pat_end = 8.0
    _at(0.0, func():
        _face_player()
        _tele(0.6)
        sprite.play("attack")
        Audio.play("boss_appear", 0.7))
    _at(0.6, func():
        charge_dir = 1 if _px() > global_position.x else -1
        dir = charge_dir
        charge_speed = 290.0
        charge_t = 0.55
        charging = true
        Audio.play("boss_attack"))

var col_targets: Array = []

func _pat_columns() -> void:
    pat_end = 3.2
    _at(0.0, func(): _tele(0.4))
    _at(0.3, func():
        col_targets.clear()
        var cx := _px()
        col_targets.append(cx)
        if phase >= 2:
            col_targets.append(cx - 52.0)
            col_targets.append(cx + 52.0)
        for x in col_targets:
            _warn(clampf(float(x), arena_left + 12.0, arena_right - 12.0), 0.7))
    _at(1.0, func():
        Audio.play("boom")
        Game.world.shake(4.0, 0.2)
        for x in col_targets:
            _shot("column", Vector2(clampf(float(x), arena_left + 12.0, arena_right - 12.0), floor_y), Vector2.ZERO))
    _at(1.7, func(): _set_vulnerable(1.2))

func _pat_pulse() -> void:
    pat_end = 3.6
    _at(0.0, func():
        _tele(0.5)
        sprite.play("attack"))
    _at(0.5, func():
        Audio.play("boss_attack")
        _wave(1)
        _wave(-1))
    _at(1.2, func():
        _wave(1)
        _wave(-1))
    _at(1.8, func(): _set_vulnerable(1.4))

func _pat_summon() -> void:
    pat_end = 3.6
    _at(0.0, func():
        _tele(0.6)
        Audio.play("boss_appear", 0.8))
    _at(0.7, func():
        Game.world.spawn_enemy("husk", Vector2(arena_left + 30.0, floor_y))
        Game.world.spawn_enemy("husk", Vector2(arena_right - 30.0, floor_y)))
    _at(2.0, func(): _set_vulnerable(1.2))

# ------------------------------------------------------------------ loop
func _physics_process(delta: float) -> void:
    if dead:
        return
    _clock += delta
    _flash = maxf(0.0, _flash - delta)
    _tele_t = maxf(0.0, _tele_t - delta)
    var col := Color(1, 1, 1, sprite.modulate.a)
    if _flash > 0.0:
        col = Color(3, 3, 3, sprite.modulate.a)
    elif _tele_t > 0.0:
        col = Color(1.8, 0.55, 0.55, sprite.modulate.a) if int(_tele_t * 12.0) % 2 == 0 else Color(1, 1, 1, sprite.modulate.a)
    elif vulnerable:
        col = Color(1.35, 1.25, 0.7, sprite.modulate.a)
    sprite.modulate = col
    sprite.flip_h = dir > 0
    if not active:
        if boss_id != "weaver":
            velocity.y = minf(velocity.y + 900.0 * delta, 420.0)
            velocity.x = 0.0
            move_and_slide()
        return
    pt += delta
    if vuln_t > 0.0:
        vuln_t -= delta
        if vuln_t <= 0.0:
            vulnerable = false
    while queue.size() > 0 and float(queue[0][0]) <= pt:
        var it: Array = queue.pop_front()
        (it[1] as Callable).call()
    _move(delta)
    if pt >= pat_end:
        _next_pattern()
    if not vulnerable:
        for b in contact.get_overlapping_bodies():
            if b.is_in_group("player"):
                b.take_damage(dmg, global_position.x)
    if sprite.animation == "attack" and not sprite.is_playing() and not charging and not slam_air:
        sprite.play("idle")

func _move(delta: float) -> void:
    if boss_id == "weaver":
        if sweeping:
            position.x += sweep_dir * 140.0 * delta
            if position.x < arena_left + 30.0:
                sweep_dir = 1
            elif position.x > arena_right - 30.0:
                sweep_dir = -1
            shoot_t -= delta
            if shoot_t <= 0.0:
                shoot_t = 0.4
                _shot("orb", global_position + Vector2(0, -24), Vector2(0.0, 170.0))
        position.y = hover_y + sin(_clock * 3.0) * 4.0
        if not charging and not sweeping:
            _face_player()
        return
    velocity.y = minf(velocity.y + 900.0 * delta, 420.0)
    if charging:
        velocity.x = charge_dir * charge_speed
        charge_t -= delta
        var hit_wall := global_position.x <= arena_left + 24.0 or global_position.x >= arena_right - 24.0 or is_on_wall()
        if boss_id == "colossus":
            if hit_wall:
                charging = false
                velocity.x = 0.0
                Game.world.shake(7.0, 0.3)
                Audio.play("boom")
                Game.world.spark(global_position + Vector2(charge_dir * 20.0, -30.0), Color(0.8, 0.8, 0.8), 14)
                _set_vulnerable(2.2)
                pat_end = pt + 2.4
        elif charge_t <= 0.0 or hit_wall:
            charging = false
            velocity.x = 0.0
            _set_vulnerable(1.5)
            pat_end = pt + 1.7
    else:
        velocity.x = move_toward(velocity.x, 0.0, 700.0 * delta)
    move_and_slide()
    global_position.x = clampf(global_position.x, arena_left + 20.0, arena_right - 20.0)
    if slam_air and is_on_floor() and velocity.y >= 0.0 and pt > 0.7:
        slam_air = false
        Game.world.shake(7.0, 0.3)
        Audio.play("boom")
        _wave(1)
        _wave(-1)
        _set_vulnerable(1.6)
        pat_end = pt + 1.8
    if not charging and not slam_air and not vulnerable:
        _face_player()

# ------------------------------------------------------------------ damage
func take_hit(amount: float, _from_pos: Vector2, _knock: float = 0.0) -> void:
    if dead or not active:
        return
    var mult := 1.0 if vulnerable else 0.35
    hp -= amount * mult
    _flash = 0.1
    Audio.play_at("hit", global_position)
    Game.world.spark(global_position + Vector2(0, -30), Color(1, 0.9, 0.6))
    var ratio := hp / max_hp
    var new_phase := 1
    if boss_id == "regent":
        new_phase = 3 if ratio < 0.33 else (2 if ratio < 0.66 else 1)
    else:
        new_phase = 2 if ratio < 0.5 else 1
    if new_phase != phase:
        phase = new_phase
        Audio.play("boss_appear")
        Game.world.shake(6.0, 0.4)
        Game.world.toast("The %s grows desperate!" % str(Game.lore["bosses"][boss_id]["name"]).capitalize())
    if hp <= 0.0:
        _die()

func _die() -> void:
    dead = true
    active = false
    charging = false
    velocity = Vector2.ZERO
    sprite.modulate = Color(1, 1, 1, 1)
    sprite.play("dead")
    Audio.play("boss_defeat")
    Game.world.shake(10.0, 0.8)
    Game.world.spark(global_position + Vector2(0, -30), Color(1, 0.8, 1), 30)
    collision_layer = 0
    contact.set_deferred("monitoring", false)
    defeated.emit()
    var tw := create_tween()
    tw.tween_interval(2.2)
    tw.tween_property(sprite, "modulate:a", 0.0, 0.8)
    tw.tween_callback(queue_free)
