extends Node
## Audio manager. Separate buses (Music / SFX) controlled from settings,
## pooled one-shot players, rate limiting, positional (2D) variant, music crossfade.

const SFX_NAMES := ["jump", "djump", "land", "sword", "hit", "magic", "magic_hit", "hurt", "enemy_die", "coin", "pickup",
    "chest", "door", "save", "click", "portal", "zone_enter", "death", "shot", "break", "boom",
    "boss_appear", "boss_attack", "boss_defeat"]
const MUSIC_NAMES := ["menu", "z1", "z2", "z3", "z4", "z5", "z6", "combat", "boss"]
const MIN_GAP_MS := 45

var sfx: Dictionary = {}
var music: Dictionary = {}
var _pool: Array = []
var _pool2d: Array = []
var _pool_i := 0
var _pool2d_i := 0
var _last_ms: Dictionary = {}
var _mp: Array = []          # two music players for crossfading
var _active := 0
var _cur_music := ""
var _base_music := ""
var _mode := "normal"        # normal | combat | boss
var _tween: Tween

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    _ensure_bus("Music")
    _ensure_bus("SFX")
    for n in SFX_NAMES:
        var p := "res://assets/audio/sfx/%s.wav" % n
        if ResourceLoader.exists(p):
            sfx[n] = load(p)
        else:
            push_warning("Missing sfx: " + p)
    for n in MUSIC_NAMES:
        var p := "res://assets/audio/music/%s.wav" % n
        if ResourceLoader.exists(p):
            music[n] = load(p)
        else:
            push_warning("Missing music: " + p)
    for i in 10:
        var pl := AudioStreamPlayer.new()
        pl.bus = "SFX"
        add_child(pl)
        _pool.append(pl)
    for i in 6:
        var p2 := AudioStreamPlayer2D.new()
        p2.bus = "SFX"
        p2.max_distance = 520.0
        add_child(p2)
        _pool2d.append(p2)
    for i in 2:
        var m := AudioStreamPlayer.new()
        m.bus = "Music"
        m.volume_db = -60.0
        m.finished.connect(_on_music_finished.bind(i))
        add_child(m)
        _mp.append(m)
    apply_volume()

func _ensure_bus(bus_name: String) -> void:
    if AudioServer.get_bus_index(bus_name) != -1:
        return
    AudioServer.add_bus()
    var idx := AudioServer.get_bus_count() - 1
    AudioServer.set_bus_name(idx, bus_name)
    AudioServer.set_bus_send(idx, "Master")

func _db(v: float) -> float:
    return linear_to_db(clampf(v, 0.0001, 1.0))

func apply_volume() -> void:
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Master"), _db(float(Game.settings["master"])))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Music"), _db(float(Game.settings["music"]) * 0.8))
    AudioServer.set_bus_volume_db(AudioServer.get_bus_index("SFX"), _db(float(Game.settings["sfx"])))

func _allowed(sfx_name: String) -> bool:
    var now := Time.get_ticks_msec()
    if now - int(_last_ms.get(sfx_name, -1000)) < MIN_GAP_MS:
        return false
    _last_ms[sfx_name] = now
    return true

func play(sfx_name: String, vol: float = 1.0, pitch: float = 1.0) -> void:
    if not sfx.has(sfx_name) or not _allowed(sfx_name):
        return
    var pl: AudioStreamPlayer = _pool[_pool_i]
    _pool_i = (_pool_i + 1) % _pool.size()
    pl.stream = sfx[sfx_name]
    pl.pitch_scale = pitch
    pl.volume_db = _db(vol)
    pl.play()

func play_at(sfx_name: String, pos: Vector2, vol: float = 1.0, pitch: float = 1.0) -> void:
    if not sfx.has(sfx_name) or not _allowed(sfx_name + "@"):
        return
    var pl: AudioStreamPlayer2D = _pool2d[_pool2d_i]
    _pool2d_i = (_pool2d_i + 1) % _pool2d.size()
    pl.stream = sfx[sfx_name]
    pl.global_position = pos
    pl.pitch_scale = pitch
    pl.volume_db = _db(vol)
    pl.play()

# --- music -----------------------------------------------------------------
func play_music(music_name: String, fade: float = 1.0) -> void:
    if music_name == _cur_music and (_mp[_active] as AudioStreamPlayer).playing:
        return
    _cur_music = music_name
    var old: AudioStreamPlayer = _mp[_active]
    if not music.has(music_name):
        _fade_out(old, fade)
        return
    _active = 1 - _active
    var nw: AudioStreamPlayer = _mp[_active]
    nw.stream = music[music_name]
    nw.volume_db = -60.0
    nw.play()
    if _tween != null and _tween.is_valid():
        _tween.kill()
    _tween = create_tween().set_parallel(true)
    _tween.tween_property(nw, "volume_db", 0.0, fade)
    if old.playing:
        _tween.tween_property(old, "volume_db", -60.0, fade)
        _tween.chain().tween_callback(old.stop)

func _fade_out(pl: AudioStreamPlayer, fade: float) -> void:
    if not pl.playing:
        return
    var tw := create_tween()
    tw.tween_property(pl, "volume_db", -60.0, fade)
    tw.tween_callback(pl.stop)

func stop_music(fade: float = 0.6) -> void:
    _cur_music = ""
    _base_music = ""
    _mode = "normal"
    for m in _mp:
        _fade_out(m, fade)

## Zone/exploration music (menu uses "menu"). Combat/boss layers override it.
func play_zone_music(music_name: String) -> void:
    _base_music = music_name
    _mode = "normal"
    play_music(music_name)

func set_combat(on: bool) -> void:
    if _mode == "boss":
        return
    var want := "combat" if on else "normal"
    if want == _mode:
        return
    _mode = want
    play_music("combat" if on else _base_music, 0.8)

func start_boss_music() -> void:
    _mode = "boss"
    play_music("boss", 0.6)

func end_boss_music() -> void:
    _mode = "normal"
    play_music(_base_music, 1.2)

func _on_music_finished(idx: int) -> void:
    var m: AudioStreamPlayer = _mp[idx]
    if idx == _active and _cur_music != "" and music.has(_cur_music):
        m.play()
