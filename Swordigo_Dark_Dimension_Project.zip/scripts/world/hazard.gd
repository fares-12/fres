extends Area2D
## Damage zone (spikes). Polls overlapping bodies so it keeps hurting after invulnerability ends.

var box_size := Vector2(16, 8)
var dmg := 1

func _ready() -> void:
    collision_layer = 0
    collision_mask = 2
    var cs := CollisionShape2D.new()
    var sh := RectangleShape2D.new()
    sh.size = box_size
    cs.shape = sh
    add_child(cs)

func _physics_process(_delta: float) -> void:
    for b in get_overlapping_bodies():
        if b.is_in_group("player"):
            b.take_damage(dmg, global_position.x)
