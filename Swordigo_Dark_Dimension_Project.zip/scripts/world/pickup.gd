extends Area2D
## Auto-collected items: coin (soul shard), heart, mana, key, sigil (ability).

var kind := "coin"
var id := ""
var ability := ""
var zone_id := 1
var _t := 0.0
var _base_y := 0.0
var _done := false

func _ready() -> void:
    collision_layer = 0
    collision_mask = 2
    var cs := CollisionShape2D.new()
    var sh := CircleShape2D.new()
    sh.radius = 9.0
    cs.shape = sh
    add_child(cs)
    if kind == "coin":
        var a := AnimatedSprite2D.new()
        a.sprite_frames = Sprites.atlas_frames("coin", 4, 8.0, true)
        add_child(a)
        a.play("coin")
    else:
        var s := Sprite2D.new()
        var tname := kind
        if kind == "sigil":
            tname = "sigil_" + ability
        s.texture = Sprites.tex(tname)
        add_child(s)
    if kind == "key" or kind == "sigil":
        if Game.world != null:
            add_child(Game.world.make_light(Color(1.0, 0.9, 0.6), 1.2, 0.9))
    body_entered.connect(_on_body)
    _base_y = position.y
    _t = randf() * 6.0

func _process(delta: float) -> void:
    _t += delta
    position.y = _base_y + sin(_t * 3.0) * 2.0

func _on_body(b: Node) -> void:
    if _done or not b.is_in_group("player"):
        return
    if kind == "heart" and Game.hp >= Game.max_hp:
        return
    if kind == "mana" and Game.mana >= float(Game.max_mana):
        return
    _done = true
    match kind:
        "coin":
            Game.add_coin()
            Audio.play("coin", 0.8, randf_range(0.95, 1.1))
        "heart":
            Game.hp = mini(Game.max_hp, Game.hp + 1)
            Audio.play("pickup")
        "mana":
            Game.mana = minf(float(Game.max_mana), Game.mana + 1.0)
            Audio.play("pickup")
        "key":
            Game.give_key(zone_id)
            Audio.play("pickup")
            Game.world.toast("Obtained: %s" % str(Game.zone_cfg(zone_id).get("key_name", "Key")))
        "sigil":
            Game.st["abilities"][ability] = true
            Audio.play("chest")
            var info: Dictionary = Game.lore["abilities"][ability]
            Game.world.show_banner(str(info["title"]), str(info["text"]))
    if id != "":
        Game.set_flag(id)
    if kind == "key" or kind == "sigil":
        Game.save_game()
    queue_free()
