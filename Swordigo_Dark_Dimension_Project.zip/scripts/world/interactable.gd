extends Area2D
## Contextual objects activated with the INTERACT button: shrine, chest, tablet, door, portal.

var kind := "shrine"
var id := ""
var zone_id := 1
var box_size := Vector2(36, 32)
var target_zone := 1
var arrive_mode := "start"
var prompt := "USE"
var _sprite: Sprite2D = null

func _ready() -> void:
    collision_layer = 32
    collision_mask = 0
    var cs := CollisionShape2D.new()
    var sh := RectangleShape2D.new()
    sh.size = box_size
    cs.shape = sh
    cs.position = Vector2(0, -box_size.y * 0.5)
    add_child(cs)
    match kind:
        "shrine":
            prompt = "SAVE"
            _sprite = Sprite2D.new()
            _sprite.position = Vector2(0, -16)
            add_child(_sprite)
            var cp: Dictionary = Game.st["checkpoint"]
            set_on(int(cp["zone"]) == zone_id and absf(float(cp["x"]) - global_position.x) < 4.0)
        "chest":
            prompt = "OPEN"
            _sprite = Sprite2D.new()
            _sprite.position = Vector2(0, -8)
            _sprite.texture = Sprites.tex("chest_open" if Game.flag(id) else "chest")
            add_child(_sprite)
        "tablet":
            prompt = "READ"
            var s := Sprite2D.new()
            s.texture = Sprites.tex("tablet")
            s.position = Vector2(0, -12)
            add_child(s)
        "door":
            prompt = "OPEN"
        "portal":
            prompt = "ENTER"
            var a := AnimatedSprite2D.new()
            a.sprite_frames = Sprites.atlas_frames("portal", 4, 8.0, true)
            a.position = Vector2(0, -24)
            add_child(a)
            a.play("portal")
            add_child(Game.world.make_light(Color(0.7, 0.5, 1.0), 2.0, 0.9))

func set_on(on: bool) -> void:
    if kind != "shrine" or _sprite == null:
        return
    _sprite.texture = Sprites.tex("shrine_on" if on else "shrine_off")
    for c in get_children():
        if c is PointLight2D:
            c.queue_free()
    if on:
        add_child(Game.world.make_light(Color(0.5, 0.95, 1.0), 1.8, 0.9))

func interact(_player: Node) -> void:
    match kind:
        "shrine":
            Game.hp = Game.max_hp
            Game.mana = float(Game.max_mana)
            Game.st["checkpoint"] = {"zone": zone_id, "x": global_position.x, "y": global_position.y}
            for s in Game.world.shrines:
                s.set_on(s == self)
            Game.save_game()
            Audio.play("save")
            Game.world.toast("Shrine lit - progress saved")
        "chest":
            if Game.flag(id):
                return
            Game.set_flag(id)
            _sprite.texture = Sprites.tex("chest_open")
            Audio.play("chest")
            var r: int = absi(id.hash()) % 3
            if r == 1 and Game.max_hp < 10:
                Game.max_hp += 1
                Game.hp = Game.max_hp
                Game.world.toast("Heart Container! Max health up")
            elif r == 2 and Game.max_mana < 6:
                Game.max_mana += 1
                Game.mana = float(Game.max_mana)
                Game.world.toast("Mana Crystal! Max mana up")
            else:
                Game.coins += 25
                Game.world.toast("25 soul shards")
            Game.save_game()
        "tablet":
            Game.world.read_tablet(id)
        "door":
            if Game.has_key(zone_id):
                Game.use_key(zone_id)
                Game.set_flag("door:%d" % zone_id)
                Audio.play("door")
                Game.world.open_doors()
                Game.world.toast("The door unseals")
                Game.save_game()
            else:
                Audio.play("click")
                Game.world.toast("Locked. Find the %s." % str(Game.zone_cfg(zone_id).get("key_name", "key")))
        "portal":
            Audio.play("portal")
            Game.go_zone(target_zone, arrive_mode)
