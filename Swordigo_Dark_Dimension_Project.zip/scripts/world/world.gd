extends Node2D
## Builds a zone from data chunks and runs the gameplay session.

const TILE := 16
const H := 18
const OFFSET := 4
const SLICE := 24
const Player = preload("res://scripts/player/player.gd")
const Enemy = preload("res://scripts/enemies/enemy.gd")
const Boss = preload("res://scripts/enemies/boss.gd")
const Pickup = preload("res://scripts/world/pickup.gd")
const Interactable = preload("res://scripts/world/interactable.gd")
const TileLayer = preload("res://scripts/world/tile_layer.gd")
const Hazard = preload("res://scripts/world/hazard.gd")
const CrackWall = preload("res://scripts/world/crack_wall.gd")
const Background = preload("res://scripts/ui/background.gd")
const Hud = preload("res://scripts/ui/hud.gd")
const Touch = preload("res://scripts/ui/touch_controls.gd")
const PauseMenu = preload("res://scripts/ui/pause_menu.gd")
const SettingsPanel = preload("res://scripts/ui/settings_panel.gd")
const TextPages = preload("res://scripts/ui/text_pages.gd")
const UI = preload("res://scripts/ui/ui_util.gd")

var zone_id := 1
var zone: Dictionary = {}
var theme := 1
var grid: Array = []
var cols := 0
var chunk_ranges: Array = []
var ents: Array = []
var door_cells: Array = []
var player = null
var shrines: Array = []
var door_nodes: Array = []
var crack_nodes: Dictionary = {}
var gate_nodes: Array = []
var entities: Node2D
var hud
var touch
var bg
var ui_layer: CanvasLayer
var overlay: Control = null
var light_tex: GradientTexture2D
var tablet_i := 0
var spawn_pos := Vector2.ZERO
var end_pos := Vector2.ZERO
var has_end := false
var boss = null
var boss_pos := Vector2.ZERO
var sigil_pos := Vector2.ZERO
var has_sigil := false
var arena_c0 := 0
var arena_c1 := 0
var boss_started := false
var floor_y := float((OFFSET + 11) * TILE)
var _shake_t := 0.0
var _shake_amp := 0.0
var _combat_t := 0.0
var _scan_t := 0.0
var _ending := false

func _ready() -> void:
    Game.world = self
    zone_id = int(Game.st["zone"])
    zone = Game.zone_cfg(zone_id)
    theme = int(zone.get("theme", 1))
    _make_light_tex()
    _assemble()
    bg = Background.new()
    add_child(bg)
    bg.set_zone(theme)
    var cm := CanvasModulate.new()
    cm.color = Color(str(zone.get("ambient", "#ffffff")))
    add_child(cm)
    entities = Node2D.new()
    add_child(entities)
    _build_tiles()
    _build_solids()
    _build_special_cells()
    _spawn_entities()
    _build_ui()
    _spawn_player()
    Audio.play_zone_music(str(zone.get("music", "z1")))
    if Game.arrive != "checkpoint":
        Audio.play("zone_enter", 0.7)
    hud.show_title(str(zone.get("name", "")), str(zone.get("sub", "")))

func _exit_tree() -> void:
    if Game.world == self:
        Game.world = null
        Game.controls = null

func _make_light_tex() -> void:
    var g := Gradient.new()
    g.set_color(0, Color(1, 1, 1, 1))
    g.set_color(1, Color(1, 1, 1, 0))
    light_tex = GradientTexture2D.new()
    light_tex.gradient = g
    light_tex.fill = GradientTexture2D.FILL_RADIAL
    light_tex.fill_from = Vector2(0.5, 0.5)
    light_tex.fill_to = Vector2(1.0, 0.5)
    light_tex.width = 128
    light_tex.height = 128

func make_light(col: Color, scale_: float, energy: float) -> PointLight2D:
    var l := PointLight2D.new()
    l.texture = light_tex
    l.color = col
    l.energy = energy
    l.texture_scale = scale_
    return l

# ------------------------------------------------------------------ level assembly
func _assemble() -> void:
    grid.clear()
    for r in H:
        grid.append([])
    _add_wall(2)
    for cname in zone["chunks"]:
        var ch: Array = Game.chunks[cname]
        var w: int = str(ch[0]).length()
        var c0: int = grid[0].size()
        chunk_ranges.append({"name": str(cname), "c0": c0, "c1": c0 + w})
        for r in H:
            var line := ""
            var cr := r - OFFSET
            if cr < 0:
                line = "#".repeat(w) if (bool(zone.get("cave", false)) and r < 3) else " ".repeat(w)
            else:
                line = str(ch[cr])
            for i in w:
                grid[r].append(line[i])
    _add_wall(2)
    cols = grid[0].size()
    for rng in chunk_ranges:
        if str(rng["name"]).begins_with("arena"):
            arena_c0 = int(rng["c0"])
            arena_c1 = int(rng["c1"])
    # scan markers
    for r in H:
        for c in cols:
            var ch2: String = grid[r][c]
            if ch2 == "#" or ch2 == "=" or ch2 == "^" or ch2 == " ":
                continue
            if ch2 == "X":
                if Game.flag("x:%d:%d:%d" % [zone_id, c, r]):
                    grid[r][c] = " "
                continue
            if ch2 == "D":
                if Game.flag("door:%d" % zone_id):
                    grid[r][c] = " "
                else:
                    door_cells.append(Vector2i(c, r))
                continue
            ents.append([ch2, c, r])
            grid[r][c] = " "

func _add_wall(n: int) -> void:
    for r in H:
        for i in n:
            grid[r].append("#")

func _char_at(c: int, r: int) -> String:
    if c < 0 or c >= cols:
        return "#"
    if r < 0 or r >= H:
        return " "
    return str(grid[r][c])

func is_solid_px(p: Vector2) -> bool:
    var c := floori(p.x / TILE)
    var r := floori(p.y / TILE)
    if c < 0 or c >= cols:
        return true
    if r < 0 or r >= H:
        return false
    var ch: String = grid[r][c]
    return ch == "#" or ch == "X" or ch == "D" or ch == "="

func _solid_char(ch: String) -> bool:
    return ch == "#"

# ------------------------------------------------------------------ tiles and solids
func _build_tiles() -> void:
    var layers: Array = []
    for i in range(ceili(float(cols) / float(SLICE))):
        var tl := TileLayer.new()
        tl.z_index = -5
        add_child(tl)
        layers.append(tl)
    for r in H:
        for c in cols:
            var ch: String = grid[r][c]
            var tname := ""
            var v := (c * 7 + r * 13) % 2
            var suffix := "" if v == 0 else "2"
            if ch == "#":
                var above := _char_at(c, r - 1)
                if above != "#" and above != "X" and above != "D":
                    tname = "t%d_top%s" % [theme, suffix]
                else:
                    tname = "t%d_fill%s" % [theme, suffix]
            elif ch == "=":
                tname = "t%d_plat" % theme
            elif ch == "^":
                tname = "spikes"
            var layer = layers[floori(float(c) / float(SLICE))]
            if tname != "":
                layer.items.append([Sprites.tex(tname), Vector2(c * TILE, r * TILE)])
            if ch == "#" and _char_at(c, r - 1) == " " and r > OFFSET:
                var hsh: int = absi((c * 73856093) ^ (r * 19349663))
                if hsh % 100 < 24:
                    layer.items.append([Sprites.tex("t%d_decor%d" % [theme, 1 + hsh % 3]), Vector2(c * TILE, (r - 1) * TILE)])
    for l in layers:
        l.queue_redraw()

func _build_solids() -> void:
    var body := StaticBody2D.new()
    body.collision_layer = 1
    body.collision_mask = 0
    add_child(body)
    var used: Array = []
    for r in H:
        var row := []
        row.resize(cols)
        row.fill(false)
        used.append(row)
    for r in H:
        var c := 0
        while c < cols:
            if not used[r][c] and _solid_char(str(grid[r][c])):
                var c1 := c
                while c1 + 1 < cols and not used[r][c1 + 1] and _solid_char(str(grid[r][c1 + 1])):
                    c1 += 1
                var r1 := r
                while r1 + 1 < H and _run_ok(r1 + 1, c, c1, used):
                    r1 += 1
                for rr in range(r, r1 + 1):
                    for cc in range(c, c1 + 1):
                        used[rr][cc] = true
                var cs := CollisionShape2D.new()
                var rs := RectangleShape2D.new()
                rs.size = Vector2((c1 - c + 1) * TILE, (r1 - r + 1) * TILE)
                cs.shape = rs
                cs.position = Vector2((c + (c1 - c + 1) * 0.5) * TILE, (r + (r1 - r + 1) * 0.5) * TILE)
                body.add_child(cs)
                c = c1 + 1
            else:
                c += 1
    # one-way platforms and spikes (horizontal runs)
    var pbody := StaticBody2D.new()
    pbody.collision_layer = 1
    pbody.collision_mask = 0
    add_child(pbody)
    for r in H:
        var c := 0
        while c < cols:
            var ch: String = grid[r][c]
            if ch == "=" or ch == "^":
                var c1 := c
                while c1 + 1 < cols and str(grid[r][c1 + 1]) == ch:
                    c1 += 1
                var n := c1 - c + 1
                if ch == "=":
                    var cs2 := CollisionShape2D.new()
                    var rs2 := RectangleShape2D.new()
                    rs2.size = Vector2(n * TILE, 6)
                    cs2.shape = rs2
                    cs2.position = Vector2((c + n * 0.5) * TILE, r * TILE + 3)
                    cs2.one_way_collision = true
                    pbody.add_child(cs2)
                else:
                    var hz := Hazard.new()
                    hz.box_size = Vector2(n * TILE - 4, 8)
                    hz.dmg = int(zone.get("dmg", 1))
                    hz.position = Vector2((c + n * 0.5) * TILE, (r + 1) * TILE - 5)
                    add_child(hz)
                c = c1 + 1
            else:
                c += 1

func _run_ok(r: int, c0: int, c1: int, used: Array) -> bool:
    for c in range(c0, c1 + 1):
        if used[r][c] or not _solid_char(str(grid[r][c])):
            return false
    return true

func _build_special_cells() -> void:
    for r in H:
        for c in cols:
            if str(grid[r][c]) == "X":
                var cw := CrackWall.new()
                cw.cell_c = c
                cw.cell_r = r
                cw.position = Vector2((c + 0.5) * TILE, (r + 0.5) * TILE)
                var cs := CollisionShape2D.new()
                var rs := RectangleShape2D.new()
                rs.size = Vector2(TILE, TILE)
                cs.shape = rs
                cw.add_child(cs)
                var sp := Sprite2D.new()
                sp.texture = Sprites.tex("t%d_crack" % theme)
                cw.add_child(sp)
                add_child(cw)
                crack_nodes[Vector2i(c, r)] = cw
    if door_cells.size() > 0:
        var minc := 9999
        var maxc := -1
        var minr := 9999
        var maxr := -1
        for dc in door_cells:
            minc = mini(minc, dc.x)
            maxc = maxi(maxc, dc.x)
            minr = mini(minr, dc.y)
            maxr = maxi(maxr, dc.y)
            var db := StaticBody2D.new()
            db.collision_layer = 1
            db.collision_mask = 0
            db.position = Vector2((dc.x + 0.5) * TILE, (dc.y + 0.5) * TILE)
            var cs2 := CollisionShape2D.new()
            var rs2 := RectangleShape2D.new()
            rs2.size = Vector2(TILE, TILE)
            cs2.shape = rs2
            db.add_child(cs2)
            var sp2 := Sprite2D.new()
            sp2.texture = Sprites.tex("door")
            db.add_child(sp2)
            add_child(db)
            door_nodes.append(db)
        var it := Interactable.new()
        it.kind = "door"
        it.zone_id = zone_id
        it.box_size = Vector2(64, (maxr - minr + 1) * TILE)
        it.position = Vector2((minc + maxc + 1) * 0.5 * TILE, (maxr + 1) * TILE)
        add_child(it)

func open_doors() -> void:
    for d in door_nodes:
        if is_instance_valid(d):
            spark(d.position, Color(1, 0.8, 0.4), 10)
            d.queue_free()
    door_nodes.clear()
    for dc in door_cells:
        grid[dc.y][dc.x] = " "
    door_cells.clear()

func break_cracks(c: int, r: int) -> void:
    var stack: Array = [Vector2i(c, r)]
    var any := false
    while stack.size() > 0:
        var p: Vector2i = stack.pop_back()
        if not crack_nodes.has(p):
            continue
        var n = crack_nodes[p]
        crack_nodes.erase(p)
        if is_instance_valid(n):
            spark(n.position, Color(0.8, 0.75, 0.7), 8)
            n.queue_free()
        grid[p.y][p.x] = " "
        Game.set_flag("x:%d:%d:%d" % [zone_id, p.x, p.y])
        any = true
        stack.append(Vector2i(p.x + 1, p.y))
        stack.append(Vector2i(p.x - 1, p.y))
        stack.append(Vector2i(p.x, p.y + 1))
        stack.append(Vector2i(p.x, p.y - 1))
    if any:
        Audio.play("break")
        shake(3.0, 0.2)

# ------------------------------------------------------------------ entities
func _pickup(kind: String, pos: Vector2, id: String, ability: String = "") -> void:
    var p := Pickup.new()
    p.kind = kind
    p.id = id
    p.ability = ability
    p.zone_id = zone_id
    p.position = pos
    entities.add_child(p)

func spawn_enemy(kind: String, foot: Vector2) -> Node:
    var e := Enemy.new()
    e.kind = kind
    e.zone_cfg = zone
    e.position = foot
    entities.add_child(e)
    return e

func spawn_drop(pos: Vector2) -> void:
    var r := randf()
    if r < 0.55:
        _pickup("coin", pos, "")
    elif r < 0.66:
        _pickup("heart", pos, "")
    elif r < 0.77:
        _pickup("mana", pos, "")

func _interactable(kind: String, foot: Vector2, id: String = "", size: Vector2 = Vector2(36, 32)) -> Node:
    var it := Interactable.new()
    it.kind = kind
    it.id = id
    it.zone_id = zone_id
    it.box_size = size
    it.position = foot
    add_child(it)
    return it

func _spawn_entities() -> void:
    var tablets: Array = zone.get("tablets", [])
    for e in ents:
        var ch: String = e[0]
        var c: int = e[1]
        var r: int = e[2]
        var id := "%d:%d:%d" % [zone_id, c, r]
        var foot := Vector2((c + 0.5) * TILE, (r + 1) * TILE)
        var ctr := Vector2((c + 0.5) * TILE, (r + 0.5) * TILE)
        match ch:
            "g":
                spawn_enemy("husk", foot)
            "a":
                spawn_enemy("archer", foot)
            "b":
                spawn_enemy("bat", ctr)
            "o":
                if not Game.flag(id):
                    _pickup("coin", ctr, id)
            "h":
                if not Game.flag(id):
                    _pickup("heart", ctr, id)
            "m":
                if not Game.flag(id):
                    _pickup("mana", ctr, id)
            "K":
                if not Game.flag(id):
                    _pickup("key", ctr, id)
            "c":
                _interactable("chest", foot, id, Vector2(30, 24))
            "S":
                var sh = _interactable("shrine", foot, id, Vector2(34, 32))
                shrines.append(sh)
            "L":
                var tid := str(tablets[tablet_i]) if tablet_i < tablets.size() else ""
                tablet_i += 1
                _interactable("tablet", foot, tid, Vector2(30, 28))
            "M":
                _interactable("tablet", foot, "hint_crack", Vector2(30, 28))
            "t":
                var tp := AnimatedSprite2D.new()
                tp.sprite_frames = Sprites.atlas_frames("torch", 3, 8.0, true)
                tp.position = foot + Vector2(0, -8)
                tp.z_index = -3
                add_child(tp)
                tp.play("torch")
                var tl := make_light(Color(str(zone.get("light", "#ffd9a0"))), 2.2, 0.85)
                tl.position = foot + Vector2(0, -12)
                add_child(tl)
            "y":
                var cr := Sprite2D.new()
                cr.texture = Sprites.tex("t4_decor1")
                cr.modulate = Color(str(zone.get("light", "#9fd8ff")))
                cr.position = foot + Vector2(0, -8)
                cr.z_index = -3
                add_child(cr)
                var cl := make_light(Color(str(zone.get("light", "#9fd8ff"))), 1.8, 0.9)
                cl.position = foot + Vector2(0, -10)
                add_child(cl)
            "P":
                spawn_pos = foot + Vector2(22 if zone_id > 1 else 0, 0)
                if zone_id > 1:
                    var bp = _interactable("portal", foot, "", Vector2(30, 46))
                    bp.target_zone = zone_id - 1
                    bp.arrive_mode = "end"
            "E":
                end_pos = foot + Vector2(-24, 0)
                has_end = true
                var ep = _interactable("portal", foot, "", Vector2(30, 46))
                ep.target_zone = mini(zone_id + 1, Game.MAX_ZONE)
                ep.arrive_mode = "start"
            "B":
                boss_pos = foot
            "U":
                sigil_pos = ctr + Vector2(0, -6)
                has_sigil = true
    _setup_boss()

func _setup_boss() -> void:
    var bid := str(zone.get("boss", ""))
    if bid == "" or arena_c1 == 0:
        return
    if Game.flag("boss_%d" % zone_id):
        _maybe_spawn_sigil()
        return
    boss = Boss.new()
    boss.boss_id = bid
    boss.zone_cfg = zone
    boss.floor_y = floor_y
    boss.arena_left = float((arena_c0 + 3) * TILE)
    boss.arena_right = float((arena_c1 - 1) * TILE)
    boss.position = boss_pos
    boss.defeated.connect(_on_boss_defeated)
    entities.add_child(boss)
    var trig := Area2D.new()
    trig.collision_layer = 0
    trig.collision_mask = 2
    var cs := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    var wpx := float((arena_c1 - arena_c0 - 6) * TILE)
    rs.size = Vector2(wpx, H * TILE)
    cs.shape = rs
    trig.add_child(cs)
    trig.position = Vector2(float(arena_c0 + 5) * TILE + wpx * 0.5, H * TILE * 0.5)
    trig.body_entered.connect(func(b):
        if b.is_in_group("player"):
            _start_boss())
    add_child(trig)

func _maybe_spawn_sigil() -> void:
    var ab := str(zone.get("ability", ""))
    if ab != "" and has_sigil and not Game.has_ability(ab):
        _pickup("sigil", sigil_pos, "sigil:%d" % zone_id, ab)

func _start_boss() -> void:
    if boss_started or boss == null or not is_instance_valid(boss):
        return
    boss_started = true
    var info: Dictionary = Game.lore["bosses"][boss.boss_id]
    Audio.start_boss_music()
    Audio.play("boss_appear")
    hud.boss_name = str(info["name"])
    hud.boss_ratio = 1.0
    hud.show_title(str(info["name"]), str(info["intro"]), 3.2)
    for i in range(7, 15):
        var gnode := StaticBody2D.new()
        gnode.collision_layer = 1
        gnode.collision_mask = 0
        gnode.position = Vector2((arena_c0 + 2 + 0.5) * TILE, (i + 0.5) * TILE)
        var cs := CollisionShape2D.new()
        var rs := RectangleShape2D.new()
        rs.size = Vector2(TILE, TILE)
        cs.shape = rs
        gnode.add_child(cs)
        var sp := Sprite2D.new()
        sp.texture = Sprites.tex("gate")
        gnode.add_child(sp)
        add_child(gnode)
        gate_nodes.append(gnode)
    get_tree().create_timer(2.4).timeout.connect(func():
        if boss != null and is_instance_valid(boss):
            boss.activate())

func _on_boss_defeated() -> void:
    Game.set_flag("boss_%d" % zone_id)
    var info: Dictionary = Game.lore["bosses"][boss.boss_id]
    hud.boss_name = ""
    Audio.end_boss_music()
    for g in gate_nodes:
        if is_instance_valid(g):
            g.queue_free()
    gate_nodes.clear()
    if str(info["outro"]) != "":
        toast(str(info["outro"]))
    Game.save_game()
    if zone_id == Game.MAX_ZONE:
        get_tree().create_timer(3.5).timeout.connect(_final_victory)
    else:
        get_tree().create_timer(1.6).timeout.connect(_maybe_spawn_sigil)

func _final_victory() -> void:
    if _ending:
        return
    _ending = true
    if player != null and is_instance_valid(player):
        player.locked = true
    Game.set_flag("completed")
    Game.save_game()
    Audio.play_music("menu", 2.0)
    var pages: Array = Game.lore["ending"].duplicate()
    pages.append(str(Game.lore["credits"]))
    var tp := TextPages.new()
    ui_layer.add_child(tp)
    tp.start(pages, func():
        Game.change_scene("res://scenes/main_menu.tscn"))

# ------------------------------------------------------------------ player and UI
func _spawn_player() -> void:
    var pos := spawn_pos
    if Game.arrive == "end" and has_end:
        pos = end_pos
    elif Game.arrive == "checkpoint":
        var cp: Dictionary = Game.st["checkpoint"]
        if int(cp["zone"]) == zone_id and float(cp["x"]) >= 0.0:
            pos = Vector2(float(cp["x"]), float(cp["y"]))
    player = Player.new()
    player.position = pos
    player.z_index = 1
    player.gravity_scale = float(zone.get("gravity", 1.0))
    player.pit_y = float(H * TILE) + 70.0
    entities.add_child(player)
    player.camera.limit_left = 0
    player.camera.limit_right = cols * TILE
    player.camera.limit_top = 0
    player.camera.limit_bottom = H * TILE
    player.camera.reset_smoothing()
    player.died.connect(_on_player_died)

func _build_ui() -> void:
    ui_layer = CanvasLayer.new()
    ui_layer.layer = 10
    add_child(ui_layer)
    hud = Hud.new()
    ui_layer.add_child(hud)
    touch = Touch.new()
    ui_layer.add_child(touch)
    Game.controls = touch

func _process(delta: float) -> void:
    if player == null or not is_instance_valid(player):
        return
    bg.set_scroll(player.global_position.x)
    var target = player.interact_target
    touch.set_interact(target != null and not player.dead, str(target.prompt) if target != null else "USE")
    if touch.pressed("pause"):
        open_pause()
    if _shake_t > 0.0:
        _shake_t -= delta
        player.camera.offset = Vector2(0, -22) + Vector2(randf_range(-1, 1), randf_range(-1, 1)) * _shake_amp
        if _shake_t <= 0.0:
            _shake_amp = 0.0
            player.camera.offset = Vector2(0, -22)
    if boss != null and is_instance_valid(boss) and boss_started and not boss.dead:
        hud.boss_ratio = boss.hp / boss.max_hp
    _scan_t -= delta
    if _scan_t <= 0.0:
        _scan_t = 0.3
        _update_combat_music()
    _combat_t = maxf(0.0, _combat_t - delta)

func _update_combat_music() -> void:
    if boss_started:
        return
    var engaged := false
    for e in get_tree().get_nodes_in_group("enemy"):
        if e.is_in_group("boss") or not is_instance_valid(e):
            continue
        if int(e.state) == 2 or int(e.state) == 3:
            if e.global_position.distance_to(player.global_position) < 220.0:
                engaged = true
                break
    if engaged:
        _combat_t = 3.0
    Audio.set_combat(_combat_t > 0.0)

func shake(amp: float, dur: float) -> void:
    _shake_amp = maxf(_shake_amp, amp)
    _shake_t = maxf(_shake_t, dur)

func flash_damage() -> void:
    hud.flash = 1.0

func toast(t: String) -> void:
    hud.toast(t)

func spark(pos: Vector2, color: Color, amount: int = 8) -> void:
    var p := CPUParticles2D.new()
    p.position = pos
    p.one_shot = true
    p.amount = amount
    p.lifetime = 0.45
    p.explosiveness = 1.0
    p.direction = Vector2(0, -1)
    p.spread = 180.0
    p.initial_velocity_min = 40.0
    p.initial_velocity_max = 110.0
    p.gravity = Vector2(0, 260)
    p.scale_amount_min = 1.5
    p.scale_amount_max = 3.0
    p.color = color
    p.z_index = 2
    entities.add_child(p)
    p.emitting = true
    get_tree().create_timer(0.9).timeout.connect(p.queue_free)

# ------------------------------------------------------------------ dialogs / pause / game over
func read_tablet(id: String) -> void:
    var info: Dictionary = {}
    if id == "hint_crack":
        info = Game.lore["hint_crack"]
    elif Game.lore["tablets"].has(id):
        info = Game.lore["tablets"][id]
    else:
        info = {"title": "Worn Stone", "text": "The inscription has worn away."}
    if id != "":
        Game.st["lore"][id] = true
    show_dialog(str(info["title"]), str(info["text"]))

func show_banner(title: String, text: String) -> void:
    show_dialog(title, text)

func show_dialog(title: String, text: String) -> void:
    if overlay != null:
        return
    get_tree().paused = true
    touch.clear_all()
    var c := Control.new()
    c.process_mode = Node.PROCESS_MODE_ALWAYS
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0, 0, 0, 0.6)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
    c.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(center)
    var panel := UI.panel(Vector2(460, 0))
    center.add_child(panel)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 10)
    panel.add_child(box)
    box.add_child(UI.label(title, 22, Color(1.0, 0.9, 0.6)))
    var body := UI.label(text, 17)
    body.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    body.custom_minimum_size = Vector2(420, 0)
    box.add_child(body)
    box.add_child(UI.label("tap to close", 12, Color(0.6, 0.55, 0.8)))
    var t0 := Time.get_ticks_msec()
    c.gui_input.connect(func(e):
        var tap: bool = (e is InputEventMouseButton and e.pressed) or (e is InputEventScreenTouch and e.pressed)
        if tap and Time.get_ticks_msec() - t0 > 400:
            _close_overlay())
    c.mouse_filter = Control.MOUSE_FILTER_STOP
    ui_layer.add_child(c)
    overlay = c

func _close_overlay() -> void:
    if overlay != null and is_instance_valid(overlay):
        overlay.queue_free()
    overlay = null
    get_tree().paused = false
    if touch != null:
        touch.clear_all()

func open_pause() -> void:
    if overlay != null or _ending or (player != null and player.dead):
        return
    get_tree().paused = true
    touch.clear_all()
    var pm := PauseMenu.new()
    ui_layer.add_child(pm)
    overlay = pm
    pm.resume.connect(_close_overlay)
    pm.quit.connect(func():
        Game.hp = maxi(1, Game.hp)
        Game.save_game()
        get_tree().paused = false
        Game.change_scene("res://scenes/main_menu.tscn"))
    pm.settings.connect(func():
        pm.visible = false
        var sp := SettingsPanel.new()
        ui_layer.add_child(sp)
        sp.closed.connect(func(): pm.visible = true))

func _on_player_died() -> void:
    if overlay != null:
        _close_overlay()
    get_tree().paused = true
    var c := Control.new()
    c.process_mode = Node.PROCESS_MODE_ALWAYS
    c.set_anchors_preset(Control.PRESET_FULL_RECT)
    var dim := ColorRect.new()
    dim.color = Color(0.15, 0.0, 0.05, 0.7)
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(dim)
    var center := CenterContainer.new()
    center.set_anchors_preset(Control.PRESET_FULL_RECT)
    c.add_child(center)
    var box := VBoxContainer.new()
    box.add_theme_constant_override("separation", 12)
    center.add_child(box)
    box.add_child(UI.label("YOU FELL", 40, Color(1.0, 0.5, 0.55)))
    box.add_child(UI.label("Your progress is kept. The shrine's light calls you back.", 15))
    var retry := UI.button("Retry", 22)
    retry.pressed.connect(func(): Game.respawn())
    box.add_child(retry)
    var menu := UI.button("Quit to Menu", 18)
    menu.pressed.connect(func():
        Game.hp = Game.max_hp
        Game.mana = float(Game.max_mana)
        Game.save_game()
        Game.change_scene("res://scenes/main_menu.tscn"))
    box.add_child(menu)
    ui_layer.add_child(c)
    overlay = c

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_GO_BACK_REQUEST:
        if overlay != null and overlay is PauseMenu:
            _close_overlay()
        else:
            open_pause()
    elif what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        if touch != null:
            open_pause()
