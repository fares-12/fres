extends StaticBody2D
## Cracked wall cell: destroyed by magic bolts (connected cracked cells break together).

var cell_c := 0
var cell_r := 0

func _ready() -> void:
    add_to_group("crack")
    collision_layer = 1
    collision_mask = 0

func hit() -> void:
    Game.world.break_cracks(cell_c, cell_r)
