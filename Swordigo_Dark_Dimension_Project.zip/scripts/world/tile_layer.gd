extends Node2D
## Draws a slice of static tiles/decor (batched per slice so off-screen slices are culled).

var items: Array = []    # each entry: [Texture2D, Vector2]

func _draw() -> void:
    for it in items:
        draw_texture(it[0], it[1])
