extends CharacterBody2D
## The hero. Reads touch controls (Game.controls) with keyboard as a desktop fallback.

signal died

const Projectile = preload("res://scripts/combat/projectile.gd")

const RUN_SPEED := 125.0
const ACCEL := 1000.0
const AIR_ACCEL := 750.0
const FRICTION := 1300.0
const GRAVITY := 950.0
const JUMP_V := -345.0
const DJUMP_V := -300.0
const MAX_FALL := 440.0
const COYOTE := 0.10
const JUMP_BUFFER := 0.12
const ATTACK_TIME := 0.30
const HIT_START := 0.07
const HIT_END := 0.20
const CAST_TIME := 0.28
const INVULN_TIME := 1.1
const MANA_REGEN := 0.22
const SWORD_DAMAGE := 2

var facing := 1
var gravity_scale := 1.0
var pit_y := 400.0
var coyote := 0.0
var jump_buf := 0.0
var attack_buf := 0.0
var air_jumps := 0
var attack_timer := 0.0
var cast_timer := 0.0
var hurt_timer := 0.0
var invuln := 0.0
var dead := false
var locked := false
var floor_time := 0.0
var safe_pos := Vector2.ZERO
var interact_target = null
var sprite: AnimatedSprite2D
var fx: AnimatedSprite2D
var sword_area: Area2D
var sword_cs: CollisionShape2D
var sensor: Area2D
var camera: Camera2D
var hit_ids: Dictionary = {}
var _prev_keys: Dictionary = {}
var _was_on_floor := false
var _fall_speed := 0.0

func _ready() -> void:
    add_to_group("player")
    collision_layer = 2
    collision_mask = 1
    var cs := CollisionShape2D.new()
    var rs := RectangleShape2D.new()
    rs.size = Vector2(10, 26)
    cs.shape = rs
    cs.position = Vector2(0, -13)
    add_child(cs)
    sprite = AnimatedSprite2D.new()
    sprite.sprite_frames = Sprites.frames("hero")
    sprite.position = Vector2(0, -15)
    add_child(sprite)
    sprite.play("idle")
    fx = AnimatedSprite2D.new()
    fx.sprite_frames = Sprites.atlas_frames("slash", 3, 20.0, false)
    fx.position = Vector2(14, -14)
    fx.visible = false
    add_child(fx)
    sword_area = Area2D.new()
    sword_area.collision_layer = 0
    sword_area.collision_mask = 4
    sword_cs = CollisionShape2D.new()
    var sr := RectangleShape2D.new()
    sr.size = Vector2(26, 24)
    sword_cs.shape = sr
    sword_cs.position = Vector2(18, -14)
    sword_area.add_child(sword_cs)
    add_child(sword_area)
    sensor = Area2D.new()
    sensor.collision_layer = 0
    sensor.collision_mask = 32
    var ss := CollisionShape2D.new()
    var sr2 := RectangleShape2D.new()
    sr2.size = Vector2(16, 28)
    ss.shape = sr2
    ss.position = Vector2(0, -14)
    sensor.add_child(ss)
    add_child(sensor)
    add_child(Game.world.make_light(Color(1.0, 0.92, 0.75), 2.6, 0.75))
    camera = Camera2D.new()
    camera.zoom = Vector2(1.5, 1.5)
    camera.position_smoothing_enabled = true
    camera.position_smoothing_speed = 9.0
    camera.offset = Vector2(0, -22)
    add_child(camera)
    camera.make_current()
    safe_pos = global_position

# ------------------------------------------------------------------ input
func _down(name_: String, keys: Array) -> bool:
    if Game.controls != null and Game.controls.is_down(name_):
        return true
    for k in keys:
        if Input.is_key_pressed(k):
            return true
    return false

func _edge(name_: String, keys: Array) -> bool:
    var p := false
    if Game.controls != null and Game.controls.pressed(name_):
        p = true
    for k in keys:
        var now := Input.is_key_pressed(k)
        if now and not _prev_keys.get(k, false):
            p = true
        _prev_keys[k] = now
    return p

# ------------------------------------------------------------------ main loop
func _physics_process(delta: float) -> void:
    var jump_p := _edge("jump", [KEY_SPACE, KEY_UP, KEY_W])
    var attack_p := _edge("attack", [KEY_J, KEY_X])
    var magic_p := _edge("magic", [KEY_K, KEY_C])
    var interact_p := _edge("interact", [KEY_E, KEY_ENTER])
    var jump_held := _down("jump", [KEY_SPACE, KEY_UP, KEY_W])
    var attack_held := _down("attack", [KEY_J, KEY_X])
    var left := _down("left", [KEY_LEFT, KEY_A])
    var right := _down("right", [KEY_RIGHT, KEY_D])

    if dead:
        velocity.x = move_toward(velocity.x, 0.0, 600.0 * delta)
        velocity.y = minf(velocity.y + GRAVITY * delta, MAX_FALL)
        move_and_slide()
        return

    invuln = maxf(0.0, invuln - delta)
    hurt_timer = maxf(0.0, hurt_timer - delta)
    attack_timer = maxf(0.0, attack_timer - delta)
    cast_timer = maxf(0.0, cast_timer - delta)
    if Game.mana < float(Game.max_mana):
        Game.mana = minf(float(Game.max_mana), Game.mana + MANA_REGEN * delta)

    var on_floor := is_on_floor()
    if on_floor:
        coyote = COYOTE
        air_jumps = 1 if Game.has_ability("double_jump") else 0
        floor_time += delta
        if floor_time > 0.3:
            safe_pos = global_position
        if not _was_on_floor and _fall_speed > 220.0:
            Audio.play("land", 0.7)
    else:
        coyote = maxf(0.0, coyote - delta)
        floor_time = 0.0
    _was_on_floor = on_floor
    _fall_speed = velocity.y

    jump_buf = JUMP_BUFFER if jump_p else maxf(0.0, jump_buf - delta)
    attack_buf = 0.12 if attack_p else maxf(0.0, attack_buf - delta)

    var dir := 0.0
    if not locked and hurt_timer <= 0.0:
        if left:
            dir -= 1.0
        if right:
            dir += 1.0
    if locked:
        jump_buf = 0.0
        attack_buf = 0.0

    if hurt_timer > 0.0:
        velocity.x = move_toward(velocity.x, 0.0, 500.0 * delta)
    else:
        var target := dir * RUN_SPEED
        if attack_timer > 0.0 and on_floor:
            target *= 0.35
        var acc := ACCEL if on_floor else AIR_ACCEL
        if dir == 0.0:
            acc = FRICTION if on_floor else AIR_ACCEL * 0.7
        velocity.x = move_toward(velocity.x, target, acc * delta)
        if dir != 0.0 and attack_timer <= 0.0:
            facing = 1 if dir > 0.0 else -1

    velocity.y = minf(velocity.y + GRAVITY * gravity_scale * delta, MAX_FALL)
    var jscale := sqrt(gravity_scale)
    if jump_buf > 0.0 and hurt_timer <= 0.0:
        if coyote > 0.0:
            velocity.y = JUMP_V * jscale
            coyote = 0.0
            jump_buf = 0.0
            Audio.play("jump")
        elif air_jumps > 0:
            velocity.y = DJUMP_V * jscale
            air_jumps -= 1
            jump_buf = 0.0
            Audio.play("djump")
            Game.world.spark(global_position + Vector2(0, -4), Color(0.6, 1.0, 0.7))
    if velocity.y < -140.0 * jscale and not jump_held:
        velocity.y = -140.0 * jscale

    if hurt_timer <= 0.0 and not locked:
        if (attack_buf > 0.0 or attack_held) and attack_timer <= 0.0 and cast_timer <= 0.0:
            _start_attack()
        elif magic_p and cast_timer <= 0.0 and attack_timer <= 0.0:
            _cast()
    _sword_hits()

    move_and_slide()

    if global_position.y > pit_y:
        _fall_out()
    _update_interact(interact_p)
    _update_anim()

func _start_attack() -> void:
    attack_timer = ATTACK_TIME
    attack_buf = 0.0
    hit_ids.clear()
    sword_cs.position.x = 18.0 * facing
    fx.position.x = 14.0 * facing
    fx.flip_h = facing < 0
    fx.visible = true
    fx.play("slash")
    fx.frame = 0
    sprite.play("attack")
    sprite.frame = 0
    Audio.play("sword", 1.0, randf_range(0.95, 1.08))

func _sword_hits() -> void:
    if attack_timer <= 0.0:
        fx.visible = false
        return
    var t := ATTACK_TIME - attack_timer
    if t < HIT_START or t > HIT_END:
        return
    for b in sword_area.get_overlapping_bodies():
        if b.is_in_group("enemy") and not hit_ids.has(b.get_instance_id()):
            hit_ids[b.get_instance_id()] = true
            b.take_hit(SWORD_DAMAGE, global_position, 130.0)
            Game.world.shake(2.0, 0.08)

func _cast() -> void:
    if Game.mana < 1.0:
        Audio.play("click")
        Game.world.toast("Not enough mana")
        return
    Game.mana -= 1.0
    cast_timer = CAST_TIME
    sprite.play("cast")
    sprite.frame = 0
    Audio.play("magic")
    var p := Projectile.new()
    var ember := Game.has_ability("ember")
    p.setup("bolt", Vector2(260.0 * facing, 0.0), 4 if ember else 2, "player")
    p.pierce = ember
    p.position = global_position + Vector2(14.0 * facing, -14.0)
    get_parent().add_child(p)

func take_damage(amount: int, from_x: float) -> void:
    if dead or invuln > 0.0:
        return
    Game.hp -= amount
    invuln = INVULN_TIME
    hurt_timer = 0.28
    attack_timer = 0.0
    cast_timer = 0.0
    fx.visible = false
    var d := signf(global_position.x - from_x)
    if d == 0.0:
        d = -float(facing)
    velocity = Vector2(d * 140.0, -170.0)
    Audio.play("hurt")
    Game.world.shake(5.0, 0.2)
    Game.world.flash_damage()
    if Game.hp <= 0:
        _die()

func _fall_out() -> void:
    Audio.play("hurt")
    Game.hp -= 1
    Game.world.flash_damage()
    if Game.hp <= 0:
        _die()
        return
    global_position = safe_pos + Vector2(-facing * 6.0, -2.0)
    velocity = Vector2.ZERO
    invuln = INVULN_TIME

func _die() -> void:
    if dead:
        return
    dead = true
    Game.hp = 0
    sprite.modulate.a = 1.0
    sprite.play("dead")
    velocity = Vector2(velocity.x, -120.0)
    Audio.play("death")
    get_tree().create_timer(1.1).timeout.connect(func(): died.emit())

func _update_interact(pressed_: bool) -> void:
    var best = null
    var best_d := 9999.0
    for a in sensor.get_overlapping_areas():
        if a.has_method("interact"):
            var d := a.global_position.distance_to(global_position)
            if d < best_d:
                best_d = d
                best = a
    interact_target = best
    if pressed_ and best != null and not locked:
        best.interact(self)

func _update_anim() -> void:
    if invuln > 0.0:
        sprite.modulate.a = 0.4 if int(invuln * 20.0) % 2 == 0 else 1.0
    else:
        sprite.modulate.a = 1.0
    var want := "idle"
    if hurt_timer > 0.0:
        want = "hurt"
    elif cast_timer > 0.0:
        want = "cast"
    elif attack_timer > 0.0:
        want = "attack"
    elif not is_on_floor():
        want = "jump" if velocity.y < 0.0 else "fall"
    elif absf(velocity.x) > 10.0:
        want = "run"
    if sprite.animation != want:
        sprite.play(want)
    sprite.flip_h = facing < 0
