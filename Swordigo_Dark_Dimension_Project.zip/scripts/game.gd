extends Node
## Global game state: settings, save/load (JSON in user://), data tables, scene fading.

signal settings_changed

const SAVE_PATH := "user://save.json"
const SETTINGS_PATH := "user://settings.json"
const SAVE_VERSION := 1
const MAX_ZONE := 6
const DEFAULT_SETTINGS := {"master": 1.0, "music": 0.7, "sfx": 0.9, "btn_scale": 1.0, "btn_alpha": 0.55}

var settings: Dictionary = DEFAULT_SETTINGS.duplicate()
var st: Dictionary = {}
var zones: Dictionary = {}
var chunks: Dictionary = {}
var lore: Dictionary = {}
var controls = null
var world = null
var arrive := "start"        # start | end | checkpoint
var load_message := ""
var _fade: ColorRect
var _changing := false
var _play_start_ms := 0

var hp: int:
    get:
        return int(st["hp"])
    set(v):
        st["hp"] = v
var max_hp: int:
    get:
        return int(st["max_hp"])
    set(v):
        st["max_hp"] = v
var mana: float:
    get:
        return float(st["mana"])
    set(v):
        st["mana"] = v
var max_mana: int:
    get:
        return int(st["max_mana"])
    set(v):
        st["max_mana"] = v
var coins: int:
    get:
        return int(st["coins"])
    set(v):
        st["coins"] = v

func _ready() -> void:
    process_mode = Node.PROCESS_MODE_ALWAYS
    zones = _read_json("res://data/zones.json")
    chunks = _read_json("res://data/chunks.json")
    lore = _read_json("res://data/lore.json")
    load_settings()
    st = _default_state()
    var cl := CanvasLayer.new()
    cl.layer = 100
    add_child(cl)
    _fade = ColorRect.new()
    _fade.color = Color(0, 0, 0, 0)
    _fade.set_anchors_preset(Control.PRESET_FULL_RECT)
    _fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
    cl.add_child(_fade)
    _play_start_ms = Time.get_ticks_msec()

func _read_json(path: String) -> Dictionary:
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        push_error("Missing data file: " + path)
        return {}
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        push_error("Bad JSON: " + path)
        return {}
    return parsed

func _notification(what: int) -> void:
    if what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
        save_settings()
        AudioServer.set_bus_mute(0, true)
    elif what == NOTIFICATION_APPLICATION_RESUMED or what == NOTIFICATION_APPLICATION_FOCUS_IN:
        AudioServer.set_bus_mute(0, false)
    elif what == NOTIFICATION_WM_CLOSE_REQUEST:
        save_settings()

# ------------------------------------------------------------------ state
func _default_state() -> Dictionary:
    return {
        "zone": 1, "hp": 5, "max_hp": 5, "mana": 3.0, "max_mana": 3, "coins": 0,
        "abilities": {}, "keyring": {}, "flags": {}, "lore": {},
        "checkpoint": {"zone": 1, "x": -1.0, "y": -1.0},
        "play_time": 0.0,
    }

func new_game() -> void:
    st = _default_state()
    arrive = "start"
    _play_start_ms = Time.get_ticks_msec()

func has_ability(a: String) -> bool:
    return st["abilities"].has(a)

func flag(id: String) -> bool:
    return st["flags"].has(id)

func set_flag(id: String) -> void:
    st["flags"][id] = true

func has_key(zone: int) -> bool:
    return st["keyring"].has(str(zone))

func give_key(zone: int) -> void:
    st["keyring"][str(zone)] = true

func use_key(zone: int) -> void:
    st["keyring"].erase(str(zone))

func add_coin() -> void:
    coins += 1
    if coins % 20 == 0 and hp < max_hp:
        hp += 1
        if world != null:
            world.toast("Soul shards mend your wounds (+1 heart)")

func zone_cfg(zone: int) -> Dictionary:
    return zones.get(str(zone), {})

# ------------------------------------------------------------------ scenes
func go_zone(zone: int, arrive_mode: String) -> void:
    st["zone"] = zone
    arrive = arrive_mode
    if arrive_mode == "start":
        st["checkpoint"] = {"zone": zone, "x": -1.0, "y": -1.0}
    save_game()
    change_scene("res://scenes/world.tscn")

func respawn() -> void:
    hp = max_hp
    mana = float(max_mana)
    var cp: Dictionary = st["checkpoint"]
    st["zone"] = int(cp["zone"])
    arrive = "checkpoint"
    change_scene("res://scenes/world.tscn")

func continue_game() -> bool:
    if not load_game():
        return false
    var cp: Dictionary = st["checkpoint"]
    st["zone"] = int(cp["zone"])
    arrive = "checkpoint"
    change_scene("res://scenes/world.tscn")
    return true

func change_scene(path: String, dur: float = 0.35) -> void:
    if _changing:
        return
    _changing = true
    var tw := create_tween()
    tw.tween_property(_fade, "color:a", 1.0, dur)
    await tw.finished
    get_tree().paused = false
    get_tree().change_scene_to_file(path)
    await get_tree().process_frame
    await get_tree().process_frame
    var tw2 := create_tween()
    tw2.tween_property(_fade, "color:a", 0.0, dur)
    await tw2.finished
    _changing = false

# ------------------------------------------------------------------ save / load
func _num(v, default_value: float) -> float:
    if typeof(v) == TYPE_INT or typeof(v) == TYPE_FLOAT:
        return float(v)
    return default_value

func _sanitize(raw) -> Dictionary:
    if typeof(raw) != TYPE_DICTIONARY:
        return {}
    var s = raw.get("state", null)
    if typeof(s) != TYPE_DICTIONARY:
        return {}
    var out := _default_state()
    var z = s.get("zone", 1)
    if typeof(z) != TYPE_INT and typeof(z) != TYPE_FLOAT:
        return {}
    var zi := int(z)
    if zi < 1 or zi > MAX_ZONE:
        return {}
    out["zone"] = zi
    out["max_hp"] = clampi(int(_num(s.get("max_hp", 5), 5.0)), 3, 10)
    out["hp"] = clampi(int(_num(s.get("hp", 5), 5.0)), 1, int(out["max_hp"]))
    out["max_mana"] = clampi(int(_num(s.get("max_mana", 3), 3.0)), 2, 6)
    out["mana"] = clampf(_num(s.get("mana", 3.0), 3.0), 0.0, float(out["max_mana"]))
    out["coins"] = maxi(0, int(_num(s.get("coins", 0), 0.0)))
    out["play_time"] = maxf(0.0, _num(s.get("play_time", 0.0), 0.0))
    for key in ["abilities", "keyring", "flags", "lore"]:
        var d = s.get(key, {})
        if typeof(d) == TYPE_DICTIONARY:
            var clean := {}
            for k in d:
                if typeof(k) == TYPE_STRING and d[k] == true:
                    clean[k] = true
            out[key] = clean
    var cp = s.get("checkpoint", {})
    if typeof(cp) == TYPE_DICTIONARY:
        out["checkpoint"] = {
            "zone": clampi(int(_num(cp.get("zone", zi), float(zi))), 1, MAX_ZONE),
            "x": _num(cp.get("x", -1.0), -1.0),
            "y": _num(cp.get("y", -1.0), -1.0)}
    return out

func _parse_save() -> Dictionary:
    if not FileAccess.file_exists(SAVE_PATH):
        return {}
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if f == null:
        return {}
    var txt := f.get_as_text()
    f.close()
    return _sanitize(JSON.parse_string(txt))

## True if a valid save exists. A damaged save is moved aside (never deleted) and reported via load_message.
func peek_save() -> bool:
    if not FileAccess.file_exists(SAVE_PATH):
        return false
    if not _parse_save().is_empty():
        return true
    var d := DirAccess.open("user://")
    if d != null:
        d.rename("save.json", "save_damaged.json")
    load_message = "Your save file was damaged. A copy was kept as save_damaged.json. Please start a new game."
    return false

func load_game() -> bool:
    if not peek_save():
        return false
    st = _parse_save()
    _play_start_ms = Time.get_ticks_msec()
    return true

func save_game() -> bool:
    st["play_time"] = float(st["play_time"]) + float(Time.get_ticks_msec() - _play_start_ms) / 1000.0
    _play_start_ms = Time.get_ticks_msec()
    var f := FileAccess.open(SAVE_PATH + ".tmp", FileAccess.WRITE)
    if f == null:
        push_warning("Cannot write save file")
        return false
    f.store_string(JSON.stringify({"version": SAVE_VERSION, "state": st}))
    f.close()
    var d := DirAccess.open("user://")
    if d == null:
        return false
    if d.file_exists("save.json"):
        d.remove("save.json")
    return d.rename("save.json.tmp", "save.json") == OK

# ------------------------------------------------------------------ settings
func load_settings() -> void:
    settings = DEFAULT_SETTINGS.duplicate()
    if not FileAccess.file_exists(SETTINGS_PATH):
        return
    var f := FileAccess.open(SETTINGS_PATH, FileAccess.READ)
    if f == null:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    var limits := {"master": [0.0, 1.0], "music": [0.0, 1.0], "sfx": [0.0, 1.0], "btn_scale": [0.7, 1.5], "btn_alpha": [0.2, 1.0]}
    for k in limits:
        var v = parsed.get(k, null)
        if typeof(v) == TYPE_FLOAT or typeof(v) == TYPE_INT:
            settings[k] = clampf(float(v), float(limits[k][0]), float(limits[k][1]))

func save_settings() -> void:
    var f := FileAccess.open(SETTINGS_PATH, FileAccess.WRITE)
    if f != null:
        f.store_string(JSON.stringify(settings))

func reset_settings() -> void:
    settings = DEFAULT_SETTINGS.duplicate()
    save_settings()
    settings_changed.emit()
