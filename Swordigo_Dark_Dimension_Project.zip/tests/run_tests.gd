extends SceneTree
## Headless test runner:  godot --headless -s res://tests/run_tests.gd
## Checks data files, assets, script compilation and save-file validation.

var fails := 0

func check(cond: bool, msg: String) -> void:
    if cond:
        print("PASS  ", msg)
    else:
        print("FAIL  ", msg)
        fails += 1

func read_json(path: String):
    var f := FileAccess.open(path, FileAccess.READ)
    if f == null:
        return null
    return JSON.parse_string(f.get_as_text())

func _initialize() -> void:
    _test_data()
    _test_assets()
    _test_scripts()
    _test_save_validation()
    print("RESULT: ", "OK" if fails == 0 else "FAILED", " (", fails, " failures)")
    quit(1 if fails > 0 else 0)

func _test_data() -> void:
    var chunks = read_json("res://data/chunks.json")
    var zones = read_json("res://data/zones.json")
    var lore = read_json("res://data/lore.json")
    check(typeof(chunks) == TYPE_DICTIONARY and chunks.size() >= 15, "chunks.json loads")
    check(typeof(zones) == TYPE_DICTIONARY and zones.size() == 6, "zones.json has 6 zones")
    check(typeof(lore) == TYPE_DICTIONARY and lore.has("intro") and lore.has("ending"), "lore.json loads")
    if typeof(chunks) != TYPE_DICTIONARY or typeof(zones) != TYPE_DICTIONARY:
        return
    for n in chunks:
        var rows: Array = chunks[n]
        var w: int = str(rows[0]).length()
        var ok := rows.size() == 14
        for r in rows:
            if str(r).length() != w:
                ok = false
        check(ok, "chunk %s is 14 rows with equal widths" % n)
    for z in zones:
        for c in zones[z]["chunks"]:
            check(chunks.has(c), "zone %s chunk %s exists" % [z, c])

func _test_assets() -> void:
    var atlas = read_json("res://data/atlas.json")
    var tex: Texture2D = load("res://assets/sprites/atlas.png")
    check(tex != null, "atlas.png loads")
    if tex != null and typeof(atlas) == TYPE_DICTIONARY:
        var inside := true
        for k in atlas:
            var r: Array = atlas[k]
            if r[0] + r[2] > tex.get_width() or r[1] + r[3] > tex.get_height():
                inside = false
        check(inside, "all atlas rects are inside atlas.png")
    var sheets = read_json("res://data/sprites.json")
    if typeof(sheets) == TYPE_DICTIONARY:
        for s in sheets:
            var t: Texture2D = load(sheets[s]["file"])
            check(t != null, "sprite sheet %s loads" % s)
    for n in ["jump", "land", "sword", "hit", "magic", "magic_hit", "hurt", "enemy_die", "chest", "pickup", "door",
            "boss_appear", "boss_attack", "boss_defeat", "zone_enter"]:
        var st = load("res://assets/audio/sfx/%s.wav" % n)
        check(st != null and st.get_length() > 0.03, "sfx %s loads and is not empty" % n)
    for m in ["menu", "z1", "z2", "z3", "z4", "z5", "z6", "combat", "boss"]:
        var ms = load("res://assets/audio/music/%s.wav" % m)
        check(ms != null and ms.get_length() > 10.0, "music %s loads (>10s)" % m)
    for z in range(1, 7):
        for i in 3:
            check(load("res://assets/backgrounds/bg_z%d_%d.png" % [z, i]) != null, "background z%d layer %d loads" % [z, i])

func _test_scripts() -> void:
    var paths := ["res://scripts/game.gd", "res://scripts/sprites.gd", "res://scripts/audio.gd",
        "res://scripts/player/player.gd", "res://scripts/enemies/enemy.gd", "res://scripts/enemies/boss.gd",
        "res://scripts/combat/projectile.gd", "res://scripts/world/world.gd", "res://scripts/world/pickup.gd",
        "res://scripts/world/interactable.gd", "res://scripts/world/hazard.gd", "res://scripts/world/crack_wall.gd",
        "res://scripts/world/tile_layer.gd", "res://scripts/ui/main_menu.gd", "res://scripts/ui/hud.gd",
        "res://scripts/ui/touch_controls.gd", "res://scripts/ui/pause_menu.gd", "res://scripts/ui/settings_panel.gd",
        "res://scripts/ui/text_pages.gd", "res://scripts/ui/background.gd", "res://scripts/ui/ui_util.gd"]
    for p in paths:
        var s = load(p)
        check(s != null and s is GDScript and s.can_instantiate(), "script compiles: " + p)
    check(load("res://scenes/main_menu.tscn") != null, "main_menu.tscn loads")
    check(load("res://scenes/world.tscn") != null, "world.tscn loads")

func _test_save_validation() -> void:
    var g = load("res://scripts/game.gd").new()
    check(g._sanitize(null).is_empty(), "null save rejected")
    check(g._sanitize("garbage").is_empty(), "string save rejected")
    check(g._sanitize({"state": {"zone": 99}}).is_empty(), "out-of-range zone rejected")
    var good: Dictionary = g._sanitize({"version": 1, "state": {"zone": 3, "hp": 99, "max_hp": 6, "coins": 12,
        "abilities": {"double_jump": true, "bad": 5}, "checkpoint": {"zone": 3, "x": 100.0, "y": 200.0}}})
    check(not good.is_empty(), "valid save accepted")
    check(good["hp"] == 6 and good["zone"] == 3 and good["coins"] == 12, "values clamped and kept")
    check(good["abilities"].has("double_jump") and not good["abilities"].has("bad"), "ability map sanitized")
    g.free()
