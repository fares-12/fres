# INTERNAL STORY BIBLE — SPOILERS (do not read if you want to be surprised)

## World
Vael was a kingdom of lantern-makers. King Orrin's daughter Lyra was dying of "the Fading".
The Order of Lantern-Makers forged the Seal of Eternity to freeze the instant of her last breath — and with it the whole kingdom, in one endless dusk.
The Seal could not hold a living child's spark, so the Order built a vessel: a Lantern that carries Lyra's spark. That vessel is the hero. It does not age, sleep or hunger.
Orrin could not let go. He hollowed himself out to guard the Seal and became the Hollow Regent.

## The dark
The "darkness" is not evil. It is time itself, pressing on the Seal. Husks are citizens frozen in place; shades are Order guards; bats are unspent hours.

## Why the Seal cracks now
The flame in the hero's chest has begun to wake and wants a morning. That is what "woke you" in the intro means.

## Zone beats
1 Whisperwood: the sky stopped; lantern-makers' regret.  
2 Sunken Ruins: the Order's oath; the Warden obeys an order nobody remembers (Gale Sigil: "the wind remembers you").  
3 Hollow Depths: hints that "it" does not age, sleep or hunger; the Seal took one moment.  
4 Prism Rift: the Weaver stitched hours to keep the king's grief warm; "the thread you carry is older than the Seal" (Ember Sigil).  
5 Ashen Bastion: Orrin counted breaths beside a small bed; "whoever bears the flame must never be told".  
6 Eternal Spire: the last moment; the Regent says "You walk like her... I cannot lose her twice."

## Ending
The Regent falls; Orrin is only an old man by an empty bed. He lets go. The Seal opens, dawn arrives, Husks rest. The Lantern was meant to carry one light until someone was brave enough to release it; the hero walks into the first morning in a hundred years. Epilogue hook: another bell rings far to the east (optional sequel).
